var Xt=Object.create;var ft=Object.defineProperty;var Kt=Object.getOwnPropertyDescriptor;var Zt=Object.getOwnPropertyNames;var en=Object.getPrototypeOf,tn=Object.prototype.hasOwnProperty;var nn=(a,u)=>()=>{try{return u||a((u={exports:{}}).exports,u),u.exports}catch(S){throw u=0,S}};var rn=(a,u,S,N)=>{if(u&&typeof u=="object"||typeof u=="function")for(let I of Zt(u))!tn.call(a,I)&&I!==S&&ft(a,I,{get:()=>u[I],enumerable:!(N=Kt(u,I))||N.enumerable});return a};var sn=(a,u,S)=>(S=a!=null?Xt(en(a)):{},rn(u||!a||!a.__esModule?ft(S,"default",{value:a,enumerable:!0}):S,a));var dt=nn((An,Ge)=>{(a=>{"use strict";var u=Object.defineProperty,S=Object.getOwnPropertyDescriptor,N=Object.getOwnPropertyNames,I=Object.prototype.hasOwnProperty,Y=(e,t)=>{for(var r in t)u(e,r,{get:t[r],enumerable:!0})},le=(e,t,r,c)=>{if(t&&typeof t=="object"||typeof t=="function")for(let g of N(t))!I.call(e,g)&&g!==r&&u(e,g,{get:()=>t[g],enumerable:!(c=S(t,g))||c.enumerable});return e},ne=e=>le(u({},"__esModule",{value:!0}),e),q=(e,t,r)=>new Promise((c,g)=>{var w=i=>{try{E(r.next(i))}catch(x){g(x)}},h=i=>{try{E(r.throw(i))}catch(x){g(x)}},E=i=>i.done?c(i.value):Promise.resolve(i.value).then(w,h);E((r=r.apply(e,t)).next())}),Z={};Y(Z,{analyzeMetafile:()=>Vt,analyzeMetafileSync:()=>zt,build:()=>It,buildSync:()=>Bt,context:()=>Mt,default:()=>Yt,formatMessages:()=>Ft,formatMessagesSync:()=>Wt,initialize:()=>Jt,stop:()=>Gt,transform:()=>Nt,transformSync:()=>Lt,version:()=>Dt}),a.exports=ne(Z);function te(e){let t=c=>{if(c===null)r.write8(0);else if(typeof c=="boolean")r.write8(1),r.write8(+c);else if(typeof c=="number")r.write8(2),r.write32(c|0);else if(typeof c=="string")r.write8(3),r.write(fe(c));else if(c instanceof Uint8Array)r.write8(4),r.write(c);else if(c instanceof Array){r.write8(5),r.write32(c.length);for(let g of c)t(g)}else{let g=Object.keys(c);r.write8(6),r.write32(g.length);for(let w of g)r.write(fe(w)),t(c[w])}},r=new Te;return r.write32(0),r.write32(e.id<<1|+!e.isRequest),t(e.value),ze(r.buf,r.len-4,0),r.buf.subarray(0,r.len)}function ve(e){let t=()=>{switch(r.read8()){case 0:return null;case 1:return!!r.read8();case 2:return r.read32();case 3:return xe(r.read());case 4:return r.read();case 5:{let h=r.read32(),E=[];for(let i=0;i<h;i++)E.push(t());return E}case 6:{let h=r.read32(),E={};for(let i=0;i<h;i++)E[xe(r.read())]=t();return E}default:throw new Error("Invalid packet")}},r=new Te(e),c=r.read32(),g=(c&1)===0;c>>>=1;let w=t();if(r.ptr!==e.length)throw new Error("Invalid packet");return{id:c,isRequest:g,value:w}}var Te=class{constructor(e=new Uint8Array(1024)){this.buf=e,this.len=0,this.ptr=0}_write(e){if(this.len+e>this.buf.length){let t=new Uint8Array((this.len+e)*2);t.set(this.buf),this.buf=t}return this.len+=e,this.len-e}write8(e){let t=this._write(1);this.buf[t]=e}write32(e){let t=this._write(4);ze(this.buf,e,t)}write(e){let t=this._write(4+e.length);ze(this.buf,e.length,t),this.buf.set(e,t+4)}_read(e){if(this.ptr+e>this.buf.length)throw new Error("Invalid packet");return this.ptr+=e,this.ptr-e}read8(){return this.buf[this._read(1)]}read32(){return Ke(this.buf,this._read(4))}read(){let e=this.read32(),t=new Uint8Array(e),r=this._read(t.length);return t.set(this.buf.subarray(r,r+e)),t}},fe,xe,We;if(typeof TextEncoder<"u"&&typeof TextDecoder<"u"){let e=new TextEncoder,t=new TextDecoder;fe=r=>e.encode(r),xe=r=>t.decode(r),We='new TextEncoder().encode("")'}else if(typeof Buffer<"u")fe=e=>Buffer.from(e),xe=e=>{let{buffer:t,byteOffset:r,byteLength:c}=e;return Buffer.from(t,r,c).toString()},We='Buffer.from("")';else throw new Error("No UTF-8 codec found");if(!(fe("")instanceof Uint8Array))throw new Error(`Invariant violation: "${We} instanceof Uint8Array" is incorrectly false

This indicates that your JavaScript environment is broken. You cannot use
esbuild in this environment because esbuild relies on this invariant. This
is not a problem with esbuild. You need to fix your environment instead.
`);function Ke(e,t){return(e[t++]|e[t++]<<8|e[t++]<<16|e[t++]<<24)>>>0}function ze(e,t,r){e[r++]=t,e[r++]=t>>8,e[r++]=t>>16,e[r++]=t>>24}var he=String.fromCharCode;function ae(e,t,r){let c=e[t],g=1,w=0;for(let h=0;h<t;h++)e[h]===10?(g++,w=0):w++;throw new SyntaxError(r||(t===e.length?"Unexpected end of input while parsing JSON":c>=32&&c<=126?`Unexpected character ${he(c)} in JSON at position ${t} (line ${g}, column ${w})`:`Unexpected byte 0x${c.toString(16)} in JSON at position ${t} (line ${g}, column ${w})`))}function vt(e){if(!(e instanceof Uint8Array))throw new Error("JSON input must be a Uint8Array");let t=[],r=[],c=[],g=e.length,w=null,h=0,E,i=0;for(;i<g;){let x=e[i++];if(x<=32)continue;let _;switch(h===2&&w===null&&x!==34&&x!==125&&ae(e,--i),x){case 116:{(e[i++]!==114||e[i++]!==117||e[i++]!==101)&&ae(e,--i),_=!0;break}case 102:{(e[i++]!==97||e[i++]!==108||e[i++]!==115||e[i++]!==101)&&ae(e,--i),_=!1;break}case 110:{(e[i++]!==117||e[i++]!==108||e[i++]!==108)&&ae(e,--i),_=null;break}case 45:case 46:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:{let T=i;for(_=he(x),x=e[i];;){switch(x){case 43:case 45:case 46:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:case 101:case 69:{_+=he(x),x=e[++i];continue}}break}_=+_,isNaN(_)&&ae(e,--T,"Invalid number");break}case 34:{for(_="";i>=g&&ae(e,g),x=e[i++],x!==34;)if(x===92)switch(e[i++]){case 34:_+='"';break;case 47:_+="/";break;case 92:_+="\\";break;case 98:_+="\b";break;case 102:_+="\f";break;case 110:_+=`
`;break;case 114:_+="\r";break;case 116:_+="	";break;case 117:{let T=0;for(let L=0;L<4;L++)x=e[i++],T<<=4,x>=48&&x<=57?T|=x-48:x>=97&&x<=102?T|=x+-87:x>=65&&x<=70?T|=x+-55:ae(e,--i);_+=he(T);break}default:ae(e,--i);break}else if(x<=127)_+=he(x);else if((x&224)===192)_+=he((x&31)<<6|e[i++]&63);else if((x&240)===224)_+=he((x&15)<<12|(e[i++]&63)<<6|e[i++]&63);else if((x&248)==240){let T=(x&7)<<18|(e[i++]&63)<<12|(e[i++]&63)<<6|e[i++]&63;T>65535&&(T-=65536,_+=he(T>>10&1023|55296),T=56320|T&1023),_+=he(T)}_[0];break}case 91:{_=[],t.push(w),r.push(E),c.push(h),w=null,E=_,h=1;continue}case 123:{_={},t.push(w),r.push(E),c.push(h),w=null,E=_,h=2;continue}case 93:{h!==1&&ae(e,--i),_=E,w=t.pop(),E=r.pop(),h=c.pop();break}case 125:{h!==2&&ae(e,--i),_=E,w=t.pop(),E=r.pop(),h=c.pop();break}default:ae(e,--i)}for(x=e[i];x<=32;)x=e[++i];switch(h){case 0:{if(i===g)return _;break}case 1:{if(E.push(_),x===44){i++;continue}if(x===93)continue;break}case 2:{if(w===null){if(w=_,x===58){i++;continue}}else{if(E[w]=_,w=null,x===44){i++;continue}if(x===125)continue}break}}break}ae(e,i)}var ee=JSON.stringify,Ze="warning",et="silent";function je(e,t){let r=[];for(let c of e){if(se(c,t),c.indexOf(",")>=0)throw new Error(`Invalid ${t}: ${c}`);r.push(c)}return r.join(",")}var Re=()=>null,H=e=>typeof e=="boolean"?null:"a boolean",R=e=>typeof e=="string"?null:"a string",De=e=>e instanceof RegExp?null:"a RegExp object",ke=e=>typeof e=="number"&&e===(e|0)?null:"an integer",xt=e=>typeof e=="number"&&e===(e|0)&&e>=0&&e<=65535?null:"a valid port number",tt=e=>typeof e=="function"?null:"a function",me=e=>Array.isArray(e)?null:"an array",re=e=>Array.isArray(e)&&e.every(t=>typeof t=="string")?null:"an array of strings",oe=e=>typeof e=="object"&&e!==null&&!Array.isArray(e)?null:"an object",kt=e=>typeof e=="object"&&e!==null?null:"an array or an object",Et=e=>e instanceof WebAssembly.Module?null:"a WebAssembly.Module",nt=e=>typeof e=="object"&&!Array.isArray(e)?null:"an object or null",rt=e=>typeof e=="string"||typeof e=="boolean"?null:"a string or a boolean",_t=e=>typeof e=="string"||typeof e=="object"&&e!==null&&!Array.isArray(e)?null:"a string or an object",st=e=>typeof e=="string"||Array.isArray(e)&&e.every(t=>typeof t=="string")?null:"a string or an array of strings",it=e=>typeof e=="string"||e instanceof Uint8Array?null:"a string or a Uint8Array",jt=e=>typeof e=="string"||e instanceof URL?null:"a string or a URL";function s(e,t,r,c){let g=e[r];if(t[r+""]=!0,g===void 0)return;let w=c(g);if(w!==null)throw new Error(`${ee(r)} must be ${w}`);return g}function X(e,t,r){for(let c in e)if(!(c in t))throw new Error(`Invalid option ${r}: ${ee(c)}`)}function St(e){let t=Object.create(null),r=s(e,t,"wasmURL",jt),c=s(e,t,"wasmModule",Et),g=s(e,t,"worker",H);return X(e,t,"in initialize() call"),{wasmURL:r,wasmModule:c,worker:g}}function lt(e){let t;if(e!==void 0){t=Object.create(null);for(let r in e){let c=e[r];if(typeof c=="string"||c===!1)t[r]=c;else throw new Error(`Expected ${ee(r)} in mangle cache to map to either a string or false`)}}return t}function Ie(e,t,r,c,g){let w=s(t,r,"color",H),h=s(t,r,"logLevel",R),E=s(t,r,"logLimit",ke),i=s(t,r,"logStyle",R);w!==void 0?e.push(`--color=${w}`):c&&e.push("--color=true"),e.push(`--log-level=${h||g}`),e.push(`--log-limit=${E||0}`),i&&e.push(`--log-style=${i}`)}function se(e,t,r){if(typeof e!="string")throw new Error(`Expected value for ${t}${r!==void 0?" "+ee(r):""} to be a string, got ${typeof e} instead`);return e}function ot(e,t,r){let c=s(t,r,"legalComments",R),g=s(t,r,"sourceRoot",R),w=s(t,r,"sourcesContent",H),h=s(t,r,"target",st),E=s(t,r,"format",R),i=s(t,r,"globalName",R),x=s(t,r,"mangleProps",De),_=s(t,r,"reserveProps",De),T=s(t,r,"mangleQuoted",H),L=s(t,r,"minify",H),F=s(t,r,"minifySyntax",H),z=s(t,r,"minifyWhitespace",H),G=s(t,r,"minifyIdentifiers",H),U=s(t,r,"lineLimit",ke),Q=s(t,r,"drop",re),A=s(t,r,"dropLabels",re),C=s(t,r,"charset",R),b=s(t,r,"treeShaking",H),p=s(t,r,"ignoreAnnotations",H),l=s(t,r,"jsx",R),d=s(t,r,"jsxFactory",R),m=s(t,r,"jsxFragment",R),v=s(t,r,"jsxImportSource",R),$=s(t,r,"jsxDev",H),f=s(t,r,"jsxSideEffects",H),y=s(t,r,"define",oe),j=s(t,r,"logOverride",oe),M=s(t,r,"supported",oe),n=s(t,r,"pure",re),o=s(t,r,"keepNames",H),k=s(t,r,"platform",R),O=s(t,r,"tsconfigRaw",_t),V=s(t,r,"absPaths",re);if(c&&e.push(`--legal-comments=${c}`),g!==void 0&&e.push(`--source-root=${g}`),w!==void 0&&e.push(`--sources-content=${w}`),h&&e.push(`--target=${je(Array.isArray(h)?h:[h],"target")}`),E&&e.push(`--format=${E}`),i&&e.push(`--global-name=${i}`),k&&e.push(`--platform=${k}`),O&&e.push(`--tsconfig-raw=${typeof O=="string"?O:JSON.stringify(O)}`),L&&e.push("--minify"),F&&e.push("--minify-syntax"),z&&e.push("--minify-whitespace"),G&&e.push("--minify-identifiers"),U&&e.push(`--line-limit=${U}`),C&&e.push(`--charset=${C}`),b!==void 0&&e.push(`--tree-shaking=${b}`),p&&e.push("--ignore-annotations"),Q)for(let P of Q)e.push(`--drop:${se(P,"drop")}`);if(A&&e.push(`--drop-labels=${je(A,"drop label")}`),V&&e.push(`--abs-paths=${je(V,"abs paths")}`),x&&e.push(`--mangle-props=${Fe(x)}`),_&&e.push(`--reserve-props=${Fe(_)}`),T!==void 0&&e.push(`--mangle-quoted=${T}`),l&&e.push(`--jsx=${l}`),d&&e.push(`--jsx-factory=${d}`),m&&e.push(`--jsx-fragment=${m}`),v&&e.push(`--jsx-import-source=${v}`),$&&e.push("--jsx-dev"),f&&e.push("--jsx-side-effects"),y)for(let P in y){if(P.indexOf("=")>=0)throw new Error(`Invalid define: ${P}`);e.push(`--define:${P}=${se(y[P],"define",P)}`)}if(j)for(let P in j){if(P.indexOf("=")>=0)throw new Error(`Invalid log override: ${P}`);e.push(`--log-override:${P}=${se(j[P],"log override",P)}`)}if(M)for(let P in M){if(P.indexOf("=")>=0)throw new Error(`Invalid supported: ${P}`);let J=M[P];if(typeof J!="boolean")throw new Error(`Expected value for supported ${ee(P)} to be a boolean, got ${typeof J} instead`);e.push(`--supported:${P}=${J}`)}if(n)for(let P of n)e.push(`--pure:${se(P,"pure")}`);o&&e.push("--keep-names")}function $t(e,t,r,c,g){var w;let h=[],E=[],i=Object.create(null),x=null,_=null;Ie(h,t,i,r,c),ot(h,t,i);let T=s(t,i,"sourcemap",rt),L=s(t,i,"bundle",H),F=s(t,i,"splitting",H),z=s(t,i,"preserveSymlinks",H),G=s(t,i,"metafile",H),U=s(t,i,"outfile",R),Q=s(t,i,"outdir",R),A=s(t,i,"outbase",R),C=s(t,i,"tsconfig",R),b=s(t,i,"resolveExtensions",re),p=s(t,i,"nodePaths",re),l=s(t,i,"mainFields",re),d=s(t,i,"conditions",re),m=s(t,i,"external",re),v=s(t,i,"packages",R),$=s(t,i,"alias",oe),f=s(t,i,"loader",oe),y=s(t,i,"outExtension",oe),j=s(t,i,"publicPath",R),M=s(t,i,"entryNames",R),n=s(t,i,"chunkNames",R),o=s(t,i,"assetNames",R),k=s(t,i,"inject",re),O=s(t,i,"banner",oe),V=s(t,i,"footer",oe),P=s(t,i,"entryPoints",kt),J=s(t,i,"absWorkingDir",R),W=s(t,i,"stdin",oe),B=(w=s(t,i,"write",H))!=null?w:g,ie=s(t,i,"allowOverwrite",H),K=s(t,i,"mangleCache",oe);if(i.plugins=!0,X(t,i,`in ${e}() call`),T&&h.push(`--sourcemap${T===!0?"":`=${T}`}`),L&&h.push("--bundle"),ie&&h.push("--allow-overwrite"),F&&h.push("--splitting"),z&&h.push("--preserve-symlinks"),G&&h.push("--metafile"),U&&h.push(`--outfile=${U}`),Q&&h.push(`--outdir=${Q}`),A&&h.push(`--outbase=${A}`),C&&h.push(`--tsconfig=${C}`),v&&h.push(`--packages=${v}`),b&&h.push(`--resolve-extensions=${je(b,"resolve extension")}`),j&&h.push(`--public-path=${j}`),M&&h.push(`--entry-names=${M}`),n&&h.push(`--chunk-names=${n}`),o&&h.push(`--asset-names=${o}`),l&&h.push(`--main-fields=${je(l,"main field")}`),d&&h.push(`--conditions=${je(d,"condition")}`),m)for(let D of m)h.push(`--external:${se(D,"external")}`);if($)for(let D in $){if(D.indexOf("=")>=0)throw new Error(`Invalid package name in alias: ${D}`);h.push(`--alias:${D}=${se($[D],"alias",D)}`)}if(O)for(let D in O){if(D.indexOf("=")>=0)throw new Error(`Invalid banner file type: ${D}`);h.push(`--banner:${D}=${se(O[D],"banner",D)}`)}if(V)for(let D in V){if(D.indexOf("=")>=0)throw new Error(`Invalid footer file type: ${D}`);h.push(`--footer:${D}=${se(V[D],"footer",D)}`)}if(k)for(let D of k)h.push(`--inject:${se(D,"inject")}`);if(f)for(let D in f){if(D.indexOf("=")>=0)throw new Error(`Invalid loader extension: ${D}`);h.push(`--loader:${D}=${se(f[D],"loader",D)}`)}if(y)for(let D in y){if(D.indexOf("=")>=0)throw new Error(`Invalid out extension: ${D}`);h.push(`--out-extension:${D}=${se(y[D],"out extension",D)}`)}if(P)if(Array.isArray(P))for(let D=0,we=P.length;D<we;D++){let ce=P[D];if(typeof ce=="object"&&ce!==null){let de=Object.create(null),ye=s(ce,de,"in",R),ue=s(ce,de,"out",R);if(X(ce,de,"in entry point at index "+D),ye===void 0)throw new Error('Missing property "in" for entry point at index '+D);if(ue===void 0)throw new Error('Missing property "out" for entry point at index '+D);E.push([ue,ye])}else E.push(["",se(ce,"entry point at index "+D)])}else for(let D in P)E.push([D,se(P[D],"entry point",D)]);if(W){let D=Object.create(null),we=s(W,D,"contents",it),ce=s(W,D,"resolveDir",R),de=s(W,D,"sourcefile",R),ye=s(W,D,"loader",R);X(W,D,'in "stdin" object'),de&&h.push(`--sourcefile=${de}`),ye&&h.push(`--loader=${ye}`),ce&&(_=ce),typeof we=="string"?x=fe(we):we instanceof Uint8Array&&(x=we)}let ge=[];if(p)for(let D of p)D+="",ge.push(D);return{entries:E,flags:h,write:B,stdinContents:x,stdinResolveDir:_,absWorkingDir:J,nodePaths:ge,mangleCache:lt(K)}}function Pt(e,t,r,c){let g=[],w=Object.create(null);Ie(g,t,w,r,c),ot(g,t,w);let h=s(t,w,"sourcemap",rt),E=s(t,w,"sourcefile",R),i=s(t,w,"loader",R),x=s(t,w,"banner",R),_=s(t,w,"footer",R),T=s(t,w,"mangleCache",oe);return X(t,w,`in ${e}() call`),h&&g.push(`--sourcemap=${h===!0?"external":h}`),E&&g.push(`--sourcefile=${E}`),i&&g.push(`--loader=${i}`),x&&g.push(`--banner=${x}`),_&&g.push(`--footer=${_}`),{flags:g,mangleCache:lt(T)}}function Tt(e){let t={},r={didClose:!1,reason:""},c={},g=0,w=0,h=new Uint8Array(16*1024),E=0,i=C=>{let b=E+C.length;if(b>h.length){let l=new Uint8Array(b*2);l.set(h),h=l}h.set(C,E),E+=C.length;let p=0;for(;p+4<=E;){let l=Ke(h,p);if(p+4+l>E)break;p+=4,z(h.subarray(p,p+l)),p+=l}p>0&&(h.copyWithin(0,p,E),E-=p)},x=C=>{r.didClose=!0,C&&(r.reason=": "+(C.message||C));let b="The service was stopped"+r.reason;for(let p in c)c[p](b,null);c={}},_=(C,b,p)=>{if(r.didClose)return p("The service is no longer running"+r.reason,null);let l=g++;c[l]=(d,m)=>{try{p(d,m)}finally{C&&C.unref()}},C&&C.ref(),e.writeToStdin(te({id:l,isRequest:!0,value:b}))},T=(C,b)=>{if(r.didClose)throw new Error("The service is no longer running"+r.reason);e.writeToStdin(te({id:C,isRequest:!1,value:b}))},L=(C,b)=>q(null,null,function*(){try{if(b.command==="ping"){T(C,{});return}if(typeof b.key=="number"){let p=t[b.key];if(!p)return;let l=p[b.command];if(l){yield l(C,b);return}}throw new Error("Invalid command: "+b.command)}catch(p){let l=[Ee(p,e,null,void 0,"")];try{T(C,{errors:l})}catch{}}}),F=!0,z=C=>{if(F){F=!1;let p=String.fromCharCode(...C);if(p!=="0.28.2")throw new Error(`Cannot start service: Host version "0.28.2" does not match binary version ${ee(p)}`);return}let b=ve(C);if(b.isRequest)L(b.id,b.value);else{let p=c[b.id];delete c[b.id],b.value.error?p(b.value.error,{}):p(null,b.value)}};return{readFromStdout:i,afterClose:x,service:{buildOrContext:({callName:C,refs:b,options:p,isTTY:l,defaultWD:d,callback:m})=>{let v=0,$=w++,f={},y={ref(){++v===1&&b&&b.ref()},unref(){--v===0&&(delete t[$],b&&b.unref())}};t[$]=f,y.ref(),Ot(C,$,_,T,y,e,f,p,l,d,(j,M)=>{try{m(j,M)}finally{y.unref()}})},transform:({callName:C,refs:b,input:p,options:l,isTTY:d,fs:m,callback:v})=>{let $=at(),f=y=>{try{if(typeof p!="string"&&!(p instanceof Uint8Array))throw new Error('The input to "transform" must be a string or a Uint8Array');let{flags:j,mangleCache:M}=Pt(C,l,d,et),n={command:"transform",flags:j,inputFS:y!==null,input:y!==null?fe(y):typeof p=="string"?fe(p):p};M&&(n.mangleCache=M),_(b,n,(o,k)=>{if(o)return v(new Error(o),null);let O=Se(k.errors,$),V=Se(k.warnings,$),P=1,J=()=>{if(--P===0){let W={warnings:V,code:k.code,map:k.map,mangleCache:void 0,legalComments:void 0};"legalComments"in k&&(W.legalComments=k?.legalComments),k.mangleCache&&(W.mangleCache=k?.mangleCache),v(null,W)}};if(O.length>0)return v(Oe("Transform failed",O,V),null);k.codeFS&&(P++,m.readFile(k.code,(W,B)=>{W!==null?v(W,null):(k.code=B,J())})),k.mapFS&&(P++,m.readFile(k.map,(W,B)=>{W!==null?v(W,null):(k.map=B,J())})),J()})}catch(j){let M=[];try{Ie(M,l,{},d,et)}catch{}let n=Ee(j,e,$,void 0,"");_(b,{command:"error",flags:M,error:n},()=>{n.detail=$.load(n.detail),v(Oe("Transform failed",[n],[]),null)})}};if((typeof p=="string"||p instanceof Uint8Array)&&p.length>1024*1024){let y=f;f=()=>m.writeFile(p,y)}f(null)},formatMessages:({callName:C,refs:b,messages:p,options:l,callback:d})=>{if(!l)throw new Error(`Missing second argument in ${C}() call`);let m={},v=s(l,m,"kind",R),$=s(l,m,"color",H),f=s(l,m,"terminalWidth",ke),y=s(l,m,"logStyle",R);if(X(l,m,`in ${C}() call`),v===void 0)throw new Error(`Missing "kind" in ${C}() call`);if(v!=="error"&&v!=="warning")throw new Error(`Expected "kind" to be "error" or "warning" in ${C}() call`);let j={command:"format-msgs",messages:pe(p,"messages",null,"",f),isWarning:v==="warning"};$!==void 0&&(j.color=$),f!==void 0&&(j.terminalWidth=f),y!==void 0&&(j.logStyle=y),_(b,j,(M,n)=>{if(M)return d(new Error(M),null);d(null,n.messages)})},analyzeMetafile:({callName:C,refs:b,metafile:p,options:l,callback:d})=>{l===void 0&&(l={});let m={},v=s(l,m,"color",H),$=s(l,m,"verbose",H);X(l,m,`in ${C}() call`);let f={command:"analyze-metafile",metafile:p};v!==void 0&&(f.color=v),$!==void 0&&(f.verbose=$),_(b,f,(y,j)=>{if(y)return d(new Error(y),null);d(null,j.result)})}}}}function Ot(e,t,r,c,g,w,h,E,i,x,_){let T=at(),L=e==="context",F=(U,Q)=>{let A=[];try{Ie(A,E,{},i,Ze)}catch{}let C=Ee(U,w,T,void 0,Q);r(g,{command:"error",flags:A,error:C},()=>{C.detail=T.load(C.detail),_(Oe(L?"Context failed":"Build failed",[C],[]),null)})},z;if(typeof E=="object"){let U=E.plugins;if(U!==void 0){if(!Array.isArray(U))return F(new Error('"plugins" must be an array'),"");z=U}}if(z&&z.length>0){if(w.isSync)return F(new Error("Cannot use plugins in synchronous API calls"),"");Ct(t,r,c,g,w,h,E,z,T).then(U=>{if(!U.ok)return F(U.error,U.pluginName);try{G(U.requestPlugins,U.runOnEndCallbacks,U.scheduleOnDisposeCallbacks)}catch(Q){F(Q,"")}},U=>F(U,""));return}try{G(null,(U,Q)=>Q([],[]),()=>{})}catch(U){F(U,"")}function G(U,Q,A){let C=w.hasFS,{entries:b,flags:p,write:l,stdinContents:d,stdinResolveDir:m,absWorkingDir:v,nodePaths:$,mangleCache:f}=$t(e,E,i,Ze,C);if(l&&!w.hasFS)throw new Error('The "write" option is unavailable in this environment');let y={command:"build",key:t,entries:b,flags:p,write:l,stdinContents:d,stdinResolveDir:m,absWorkingDir:v||x,nodePaths:$,context:L};U&&(y.plugins=U),f&&(y.mangleCache=f);let j=(o,k)=>{let O={errors:Se(o.errors,T),warnings:Se(o.warnings,T),outputFiles:void 0,metafile:void 0,mangleCache:void 0},V=O.errors.slice(),P=O.warnings.slice();o.outputFiles&&(O.outputFiles=o.outputFiles.map(Ut)),o.metafile&&o.metafile.length&&(O.metafile=Rt(o.metafile)),o.mangleCache&&(O.mangleCache=o.mangleCache),o.writeToStdout!==void 0&&console.log(xe(o.writeToStdout).replace(/\n$/,"")),Q(O,(J,W)=>{if(V.length>0||J.length>0){let B=Oe("Build failed",V.concat(J),P.concat(W));return k(B,null,J,W)}k(null,O,J,W)})},M,n;L&&(h["on-end"]=(o,k)=>new Promise(O=>{j(k,(V,P,J,W)=>{let B={errors:J,warnings:W};n&&n(V,P),M=void 0,n=void 0,c(o,B),O()})})),r(g,y,(o,k)=>{if(o)return _(new Error(o),null);if(!L)return j(k,(P,J)=>(A(),_(P,J)));if(k.errors.length>0)return _(Oe("Context failed",k.errors,k.warnings),null);let O=!1,V={rebuild:()=>(M||(M=new Promise((P,J)=>{let W;n=(ie,K)=>{W||(W=()=>ie?J(ie):P(K))};let B=()=>{r(g,{command:"rebuild",key:t},(K,ge)=>{K?J(new Error(K)):W?W():B()})};B()})),M),watch:(P={})=>new Promise((J,W)=>{if(!w.hasFS)throw new Error('Cannot use the "watch" API in this environment');let B={},ie=s(P,B,"delay",ke);X(P,B,"in watch() call");let K={command:"watch",key:t};ie&&(K.delay=ie),r(g,K,ge=>{ge?W(new Error(ge)):J(void 0)})}),serve:(P={})=>new Promise((J,W)=>{if(!w.hasFS)throw new Error('Cannot use the "serve" API in this environment');let B={},ie=s(P,B,"port",xt),K=s(P,B,"host",R),ge=s(P,B,"servedir",R),D=s(P,B,"keyfile",R),we=s(P,B,"certfile",R),ce=s(P,B,"fallback",R),de=s(P,B,"cors",oe),ye=s(P,B,"onRequest",tt);X(P,B,"in serve() call");let ue={command:"serve",key:t,onRequest:!!ye};if(ie!==void 0&&(ue.port=ie),K!==void 0&&(ue.host=K),ge!==void 0&&(ue.servedir=ge),D!==void 0&&(ue.keyfile=D),we!==void 0&&(ue.certfile=we),ce!==void 0&&(ue.fallback=ce),de){let Ae={},$e=s(de,Ae,"origin",st);X(de,Ae,'on "cors" object'),Array.isArray($e)?ue.corsOrigin=$e:$e!==void 0&&(ue.corsOrigin=[$e])}r(g,ue,(Ae,$e)=>{if(Ae)return W(new Error(Ae));ye&&(h["serve-request"]=(Ht,Qt)=>{ye(Qt.args),c(Ht,{})}),J($e)})}),cancel:()=>new Promise(P=>{if(O)return P();r(g,{command:"cancel",key:t},()=>{P()})}),dispose:()=>new Promise(P=>{if(O)return P();O=!0,r(g,{command:"dispose",key:t},()=>{P(),A(),g.unref()})})};g.ref(),_(null,V)})}}var Ct=(e,t,r,c,g,w,h,E,i)=>q(null,null,function*(){let x=[],_=[],T={},L={},F=[],z=0,G=0,U=[],Q=!1;E=[...E];for(let b of E){let p={};if(typeof b!="object")throw new Error(`Plugin at index ${G} must be an object`);let l=s(b,p,"name",R);if(typeof l!="string"||l==="")throw new Error(`Plugin at index ${G} is missing a name`);try{let d=s(b,p,"setup",tt);if(typeof d!="function")throw new Error("Plugin is missing a setup function");X(b,p,`on plugin ${ee(l)}`);let m={name:l,onStart:!1,onEnd:!1,onResolve:[],onLoad:[]};G++;let $=d({initialOptions:h,resolve:(f,y={})=>{if(!Q)throw new Error('Cannot call "resolve" before plugin setup has completed');if(typeof f!="string")throw new Error("The path to resolve must be a string");let j=Object.create(null),M=s(y,j,"pluginName",R),n=s(y,j,"importer",R),o=s(y,j,"namespace",R),k=s(y,j,"resolveDir",R),O=s(y,j,"kind",R),V=s(y,j,"pluginData",Re),P=s(y,j,"with",oe);return X(y,j,"in resolve() call"),new Promise((J,W)=>{let B={command:"resolve",path:f,key:e,pluginName:l};if(M!=null&&(B.pluginName=M),n!=null&&(B.importer=n),o!=null&&(B.namespace=o),k!=null&&(B.resolveDir=k),O!=null)B.kind=O;else throw new Error('Must specify "kind" when calling "resolve"');V!=null&&(B.pluginData=i.store(V)),P!=null&&(B.with=At(P,"with")),t(c,B,(ie,K)=>{ie!==null?W(new Error(ie)):J({errors:Se(K.errors,i),warnings:Se(K.warnings,i),path:K.path,external:K.external,sideEffects:K.sideEffects,namespace:K.namespace,suffix:K.suffix,pluginData:i.load(K.pluginData)})})})},onStart(f){let y='This error came from the "onStart" callback registered here:',j=Me(new Error(y),g,"onStart");x.push({name:l,callback:f,note:j}),m.onStart=!0},onEnd(f){let y='This error came from the "onEnd" callback registered here:',j=Me(new Error(y),g,"onEnd");_.push({name:l,callback:f,note:j}),m.onEnd=!0},onResolve(f,y){let j='This error came from the "onResolve" callback registered here:',M=Me(new Error(j),g,"onResolve"),n={},o=s(f,n,"filter",De),k=s(f,n,"namespace",R);if(X(f,n,`in onResolve() call for plugin ${ee(l)}`),o==null)throw new Error("onResolve() call is missing a filter");let O=z++;T[O]={name:l,callback:y,note:M},m.onResolve.push({id:O,filter:Fe(o),namespace:k||""})},onLoad(f,y){let j='This error came from the "onLoad" callback registered here:',M=Me(new Error(j),g,"onLoad"),n={},o=s(f,n,"filter",De),k=s(f,n,"namespace",R);if(X(f,n,`in onLoad() call for plugin ${ee(l)}`),o==null)throw new Error("onLoad() call is missing a filter");let O=z++;L[O]={name:l,callback:y,note:M},m.onLoad.push({id:O,filter:Fe(o),namespace:k||""})},onDispose(f){F.push(f)},esbuild:g.esbuild});$&&(yield $),U.push(m)}catch(d){return{ok:!1,error:d,pluginName:l}}}w["on-start"]=(b,p)=>q(null,null,function*(){i.clear();let l={errors:[],warnings:[]};yield Promise.all(x.map(d=>q(null,[d],function*({name:m,callback:v,note:$}){try{let f=yield v();if(f!=null){if(typeof f!="object")throw new Error(`Expected onStart() callback in plugin ${ee(m)} to return an object`);let y={},j=s(f,y,"errors",me),M=s(f,y,"warnings",me);X(f,y,`from onStart() callback in plugin ${ee(m)}`),j!=null&&l.errors.push(...pe(j,"errors",i,m,void 0)),M!=null&&l.warnings.push(...pe(M,"warnings",i,m,void 0))}}catch(f){l.errors.push(Ee(f,g,i,$&&$(),m))}}))),r(b,l)}),w["on-resolve"]=(b,p)=>q(null,null,function*(){let l={},d="",m,v;for(let $ of p.ids)try{({name:d,callback:m,note:v}=T[$]);let f=yield m({path:p.path,importer:p.importer,namespace:p.namespace,resolveDir:p.resolveDir,kind:p.kind,pluginData:i.load(p.pluginData),with:p.with});if(f!=null){if(typeof f!="object")throw new Error(`Expected onResolve() callback in plugin ${ee(d)} to return an object`);let y={},j=s(f,y,"pluginName",R),M=s(f,y,"path",R),n=s(f,y,"namespace",R),o=s(f,y,"suffix",R),k=s(f,y,"external",H),O=s(f,y,"sideEffects",H),V=s(f,y,"pluginData",Re),P=s(f,y,"errors",me),J=s(f,y,"warnings",me),W=s(f,y,"watchFiles",re),B=s(f,y,"watchDirs",re);X(f,y,`from onResolve() callback in plugin ${ee(d)}`),l.id=$,j!=null&&(l.pluginName=j),M!=null&&(l.path=M),n!=null&&(l.namespace=n),o!=null&&(l.suffix=o),k!=null&&(l.external=k),O!=null&&(l.sideEffects=O),V!=null&&(l.pluginData=i.store(V)),P!=null&&(l.errors=pe(P,"errors",i,d,void 0)),J!=null&&(l.warnings=pe(J,"warnings",i,d,void 0)),W!=null&&(l.watchFiles=Ne(W,"watchFiles")),B!=null&&(l.watchDirs=Ne(B,"watchDirs"));break}}catch(f){l={id:$,errors:[Ee(f,g,i,v&&v(),d)]};break}r(b,l)}),w["on-load"]=(b,p)=>q(null,null,function*(){let l={},d="",m,v;for(let $ of p.ids)try{({name:d,callback:m,note:v}=L[$]);let f=yield m({path:p.path,namespace:p.namespace,suffix:p.suffix,pluginData:i.load(p.pluginData),with:p.with});if(f!=null){if(typeof f!="object")throw new Error(`Expected onLoad() callback in plugin ${ee(d)} to return an object`);let y={},j=s(f,y,"pluginName",R),M=s(f,y,"contents",it),n=s(f,y,"resolveDir",R),o=s(f,y,"pluginData",Re),k=s(f,y,"loader",R),O=s(f,y,"errors",me),V=s(f,y,"warnings",me),P=s(f,y,"watchFiles",re),J=s(f,y,"watchDirs",re);X(f,y,`from onLoad() callback in plugin ${ee(d)}`),l.id=$,j!=null&&(l.pluginName=j),M instanceof Uint8Array?l.contents=M:M!=null&&(l.contents=fe(M)),n!=null&&(l.resolveDir=n),o!=null&&(l.pluginData=i.store(o)),k!=null&&(l.loader=k),O!=null&&(l.errors=pe(O,"errors",i,d,void 0)),V!=null&&(l.warnings=pe(V,"warnings",i,d,void 0)),P!=null&&(l.watchFiles=Ne(P,"watchFiles")),J!=null&&(l.watchDirs=Ne(J,"watchDirs"));break}}catch(f){l={id:$,errors:[Ee(f,g,i,v&&v(),d)]};break}r(b,l)});let A=(b,p)=>p([],[]);_.length>0&&(A=(b,p)=>{q(null,null,function*(){let l=[],d=[];for(let{name:m,callback:v,note:$}of _){let f,y;try{let j=yield v(b);if(j!=null){if(typeof j!="object")throw new Error(`Expected onEnd() callback in plugin ${ee(m)} to return an object`);let M={},n=s(j,M,"errors",me),o=s(j,M,"warnings",me);X(j,M,`from onEnd() callback in plugin ${ee(m)}`),n!=null&&(f=pe(n,"errors",i,m,void 0)),o!=null&&(y=pe(o,"warnings",i,m,void 0))}}catch(j){f=[Ee(j,g,i,$&&$(),m)]}if(f){l.push(...f);try{b.errors.push(...f)}catch{}}if(y){d.push(...y);try{b.warnings.push(...y)}catch{}}}p(l,d)})});let C=()=>{for(let b of F)setTimeout(()=>b(),0)};return Q=!0,{ok:!0,requestPlugins:U,runOnEndCallbacks:A,scheduleOnDisposeCallbacks:C}});function at(){let e=new Map,t=0;return{clear(){e.clear()},load(r){return e.get(r)},store(r){if(r===void 0)return-1;let c=t++;return e.set(c,r),c}}}function Me(e,t,r){let c,g=!1;return()=>{if(g)return c;g=!0;try{let w=(e.stack+"").split(`
`);w.splice(1,1);let h=ct(t,w,r);if(h)return c={text:e.message,location:h},c}catch{}}}function Ee(e,t,r,c,g){let w="Internal error",h=null;try{w=(e&&e.message||e)+""}catch{}try{h=ct(t,(e.stack+"").split(`
`),"")}catch{}return{id:"",pluginName:g,text:w,location:h,notes:c?[c]:[],detail:r?r.store(e):-1}}function ct(e,t,r){let c="    at ";if(e.readFileSync&&!t[0].startsWith(c)&&t[1].startsWith(c))for(let g=1;g<t.length;g++){let w=t[g];if(w.startsWith(c))for(w=w.slice(c.length);;){let h=/^(?:new |async )?\S+ \((.*)\)$/.exec(w);if(h){w=h[1];continue}if(h=/^eval at \S+ \((.*)\)(?:, \S+:\d+:\d+)?$/.exec(w),h){w=h[1];continue}if(h=/^(\S+):(\d+):(\d+)$/.exec(w),h){let E;try{E=e.readFileSync(h[1],"utf8")}catch{break}let i=E.split(/\r\n|\r|\n|\u2028|\u2029/)[+h[2]-1]||"",x=+h[3]-1,_=i.slice(x,x+r.length)===r?r.length:0;return{file:h[1],namespace:"file",line:+h[2],column:fe(i.slice(0,x)).length,length:fe(i.slice(x,x+_)).length,lineText:i+`
`+t.slice(1).join(`
`),suggestion:""}}break}}return null}function Oe(e,t,r){let c=5;e+=t.length<1?"":` with ${t.length} error${t.length<2?"":"s"}:`+t.slice(0,c+1).map((w,h)=>{if(h===c)return`
...`;if(!w.location)return`
error: ${w.text}`;let{file:E,line:i,column:x}=w.location,_=w.pluginName?`[plugin: ${w.pluginName}] `:"";return`
${E}:${i}:${x}: ERROR: ${_}${w.text}`}).join("");let g=new Error(e);for(let[w,h]of[["errors",t],["warnings",r]])Object.defineProperty(g,w,{configurable:!0,enumerable:!0,get:()=>h,set:E=>Object.defineProperty(g,w,{configurable:!0,enumerable:!0,value:E})});return g}function Se(e,t){for(let r of e)r.detail=t.load(r.detail);return e}function ut(e,t,r){if(e==null)return null;let c={},g=s(e,c,"file",R),w=s(e,c,"namespace",R),h=s(e,c,"line",ke),E=s(e,c,"column",ke),i=s(e,c,"length",ke),x=s(e,c,"lineText",R),_=s(e,c,"suggestion",R);if(X(e,c,t),x){let T=x.slice(0,(E&&E>0?E:0)+(i&&i>0?i:0)+(r&&r>0?r:80));!/[\x7F-\uFFFF]/.test(T)&&!/\n/.test(x)&&(x=T)}return{file:g||"",namespace:w||"",line:h||0,column:E||0,length:i||0,lineText:x||"",suggestion:_||""}}function pe(e,t,r,c,g){let w=[],h=0;for(let E of e){let i={},x=s(E,i,"id",R),_=s(E,i,"pluginName",R),T=s(E,i,"text",R),L=s(E,i,"location",nt),F=s(E,i,"notes",me),z=s(E,i,"detail",Re),G=`in element ${h} of "${t}"`;X(E,i,G);let U=[];if(F)for(let Q of F){let A={},C=s(Q,A,"text",R),b=s(Q,A,"location",nt);X(Q,A,G),U.push({text:C||"",location:ut(b,G,g)})}w.push({id:x||"",pluginName:_||c,text:T||"",location:ut(L,G,g),notes:U,detail:r?r.store(z):-1}),h++}return w}function Ne(e,t){let r=[];for(let c of e){if(typeof c!="string")throw new Error(`${ee(t)} must be an array of strings`);r.push(c)}return r}function At(e,t){let r=Object.create(null);for(let c in e){let g=e[c];if(typeof g!="string")throw new Error(`key ${ee(c)} in object ${ee(t)} must be a string`);r[c]=g}return r}function Ut({path:e,contents:t,hash:r}){let c=null;return{path:e,contents:t,hash:r,get text(){let g=this.contents;return(c===null||g!==t)&&(t=g,c=xe(g)),c}}}function Fe(e){let t=e.source;return e.flags&&(t=`(?${e.flags})${t}`),t}function Rt(e){let t;try{t=xe(e)}catch{return vt(e)}return JSON.parse(t)}var Dt="0.28.2",It=e=>Ce().build(e),Mt=e=>Ce().context(e),Nt=(e,t)=>Ce().transform(e,t),Ft=(e,t)=>Ce().formatMessages(e,t),Vt=(e,t)=>Ce().analyzeMetafile(e,t),Bt=()=>{throw new Error('The "buildSync" API only works in node')},Lt=()=>{throw new Error('The "transformSync" API only works in node')},Wt=()=>{throw new Error('The "formatMessagesSync" API only works in node')},zt=()=>{throw new Error('The "analyzeMetafileSync" API only works in node')},Gt=()=>(Ve&&Ve(),Promise.resolve()),_e,Ve,Be,Ce=()=>{if(Be)return Be;throw _e?new Error('You need to wait for the promise returned from "initialize" to be resolved before calling this'):new Error('You need to call "initialize" before calling this')},Jt=e=>{e=St(e||{});let t=e.wasmURL,r=e.wasmModule,c=e.worker!==!1;if(!t&&!r)throw new Error('Must provide either the "wasmURL" option or the "wasmModule" option');if(_e)throw new Error('Cannot call "initialize" more than once');return _e=qt(t||"",r,c),_e.catch(()=>{_e=void 0}),_e},qt=(e,t,r)=>q(null,null,function*(){let c,g,w=new Promise(T=>g=T);if(r){let T=new Blob([`onmessage=((postMessage) => {
      // Copyright 2018 The Go Authors. All rights reserved.
      // Use of this source code is governed by a BSD-style
      // license that can be found in the LICENSE file.
      var __async = (__this, __arguments, generator) => {
        return new Promise((resolve, reject) => {
          var fulfilled = (value) => {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          };
          var rejected = (value) => {
            try {
              step(generator.throw(value));
            } catch (e) {
              reject(e);
            }
          };
          var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
          step((generator = generator.apply(__this, __arguments)).next());
        });
      };
      let onmessage;
      let globalThis = {};
      for (let o = self; o; o = Object.getPrototypeOf(o))
        for (let k of Object.getOwnPropertyNames(o))
          if (!(k in globalThis))
            Object.defineProperty(globalThis, k, { get: () => self[k] });
      "use strict";
      (() => {
        const enosys = () => {
          const err = new Error("not implemented");
          err.code = "ENOSYS";
          return err;
        };
        if (!globalThis.fs) {
          let outputBuf = "";
          globalThis.fs = {
            constants: { O_WRONLY: -1, O_RDWR: -1, O_CREAT: -1, O_TRUNC: -1, O_APPEND: -1, O_EXCL: -1, O_DIRECTORY: -1 },
            // unused
            writeSync(fd, buf) {
              outputBuf += decoder.decode(buf);
              const nl = outputBuf.lastIndexOf("\\n");
              if (nl != -1) {
                console.log(outputBuf.substring(0, nl));
                outputBuf = outputBuf.substring(nl + 1);
              }
              return buf.length;
            },
            write(fd, buf, offset, length, position, callback) {
              if (offset !== 0 || length !== buf.length || position !== null) {
                callback(enosys());
                return;
              }
              const n = this.writeSync(fd, buf);
              callback(null, n);
            },
            chmod(path, mode, callback) {
              callback(enosys());
            },
            chown(path, uid, gid, callback) {
              callback(enosys());
            },
            close(fd, callback) {
              callback(enosys());
            },
            fchmod(fd, mode, callback) {
              callback(enosys());
            },
            fchown(fd, uid, gid, callback) {
              callback(enosys());
            },
            fstat(fd, callback) {
              callback(enosys());
            },
            fsync(fd, callback) {
              callback(null);
            },
            ftruncate(fd, length, callback) {
              callback(enosys());
            },
            lchown(path, uid, gid, callback) {
              callback(enosys());
            },
            link(path, link, callback) {
              callback(enosys());
            },
            lstat(path, callback) {
              callback(enosys());
            },
            mkdir(path, perm, callback) {
              callback(enosys());
            },
            open(path, flags, mode, callback) {
              callback(enosys());
            },
            read(fd, buffer, offset, length, position, callback) {
              callback(enosys());
            },
            readdir(path, callback) {
              callback(enosys());
            },
            readlink(path, callback) {
              callback(enosys());
            },
            rename(from, to, callback) {
              callback(enosys());
            },
            rmdir(path, callback) {
              callback(enosys());
            },
            stat(path, callback) {
              callback(enosys());
            },
            symlink(path, link, callback) {
              callback(enosys());
            },
            truncate(path, length, callback) {
              callback(enosys());
            },
            unlink(path, callback) {
              callback(enosys());
            },
            utimes(path, atime, mtime, callback) {
              callback(enosys());
            }
          };
        }
        if (!globalThis.process) {
          globalThis.process = {
            getuid() {
              return -1;
            },
            getgid() {
              return -1;
            },
            geteuid() {
              return -1;
            },
            getegid() {
              return -1;
            },
            getgroups() {
              throw enosys();
            },
            pid: -1,
            ppid: -1,
            umask() {
              throw enosys();
            },
            cwd() {
              throw enosys();
            },
            chdir() {
              throw enosys();
            }
          };
        }
        if (!globalThis.path) {
          globalThis.path = {
            resolve(...pathSegments) {
              return pathSegments.join("/");
            }
          };
        }
        if (!globalThis.crypto) {
          throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");
        }
        if (!globalThis.performance) {
          throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");
        }
        if (!globalThis.TextEncoder) {
          throw new Error("globalThis.TextEncoder is not available, polyfill required");
        }
        if (!globalThis.TextDecoder) {
          throw new Error("globalThis.TextDecoder is not available, polyfill required");
        }
        const encoder = new TextEncoder("utf-8");
        const decoder = new TextDecoder("utf-8");
        globalThis.Go = class {
          constructor() {
            this.argv = ["js"];
            this.env = {};
            this.exit = (code) => {
              if (code !== 0) {
                console.warn("exit code:", code);
              }
            };
            this._exitPromise = new Promise((resolve) => {
              this._resolveExitPromise = resolve;
            });
            this._pendingEvent = null;
            this._scheduledTimeouts = /* @__PURE__ */ new Map();
            this._nextCallbackTimeoutID = 1;
            const setInt64 = (addr, v) => {
              this.mem.setUint32(addr + 0, v, true);
              this.mem.setUint32(addr + 4, Math.floor(v / 4294967296), true);
            };
            const setInt32 = (addr, v) => {
              this.mem.setUint32(addr + 0, v, true);
            };
            const getInt64 = (addr) => {
              const low = this.mem.getUint32(addr + 0, true);
              const high = this.mem.getInt32(addr + 4, true);
              return low + high * 4294967296;
            };
            const loadValue = (addr) => {
              const f = this.mem.getFloat64(addr, true);
              if (f === 0) {
                return void 0;
              }
              if (!isNaN(f)) {
                return f;
              }
              const id = this.mem.getUint32(addr, true);
              return this._values[id];
            };
            const storeValue = (addr, v) => {
              const nanHead = 2146959360;
              if (typeof v === "number" && v !== 0) {
                if (isNaN(v)) {
                  this.mem.setUint32(addr + 4, nanHead, true);
                  this.mem.setUint32(addr, 0, true);
                  return;
                }
                this.mem.setFloat64(addr, v, true);
                return;
              }
              if (v === void 0) {
                this.mem.setFloat64(addr, 0, true);
                return;
              }
              let id = this._ids.get(v);
              if (id === void 0) {
                id = this._idPool.pop();
                if (id === void 0) {
                  id = this._values.length;
                }
                this._values[id] = v;
                this._goRefCounts[id] = 0;
                this._ids.set(v, id);
              }
              this._goRefCounts[id]++;
              let typeFlag = 0;
              switch (typeof v) {
                case "object":
                  if (v !== null) {
                    typeFlag = 1;
                  }
                  break;
                case "string":
                  typeFlag = 2;
                  break;
                case "symbol":
                  typeFlag = 3;
                  break;
                case "function":
                  typeFlag = 4;
                  break;
              }
              this.mem.setUint32(addr + 4, nanHead | typeFlag, true);
              this.mem.setUint32(addr, id, true);
            };
            const loadSlice = (addr) => {
              const array = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              return new Uint8Array(this._inst.exports.mem.buffer, array, len);
            };
            const loadSliceOfValues = (addr) => {
              const array = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              const a = new Array(len);
              for (let i = 0; i < len; i++) {
                a[i] = loadValue(array + i * 8);
              }
              return a;
            };
            const loadString = (addr) => {
              const saddr = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              return decoder.decode(new DataView(this._inst.exports.mem.buffer, saddr, len));
            };
            const testCallExport = (a, b) => {
              this._inst.exports.testExport0();
              return this._inst.exports.testExport(a, b);
            };
            const timeOrigin = Date.now() - performance.now();
            this.importObject = {
              _gotest: {
                add: (a, b) => a + b,
                callExport: testCallExport
              },
              gojs: {
                // Go's SP does not change as long as no Go code is running. Some operations (e.g. calls, getters and setters)
                // may synchronously trigger a Go event handler. This makes Go code get executed in the middle of the imported
                // function. A goroutine can switch to a new stack if the current stack is too small (see morestack function).
                // This changes the SP, thus we have to update the SP used by the imported function.
                // func wasmExit(code int32)
                "runtime.wasmExit": (sp) => {
                  sp >>>= 0;
                  const code = this.mem.getInt32(sp + 8, true);
                  this.exited = true;
                  delete this._inst;
                  delete this._values;
                  delete this._goRefCounts;
                  delete this._ids;
                  delete this._idPool;
                  this.exit(code);
                },
                // func wasmWrite(fd uintptr, p unsafe.Pointer, n int32)
                "runtime.wasmWrite": (sp) => {
                  sp >>>= 0;
                  const fd = getInt64(sp + 8);
                  const p = getInt64(sp + 16);
                  const n = this.mem.getInt32(sp + 24, true);
                  globalThis.fs.writeSync(fd, new Uint8Array(this._inst.exports.mem.buffer, p, n));
                },
                // func resetMemoryDataView()
                "runtime.resetMemoryDataView": (sp) => {
                  sp >>>= 0;
                  this.mem = new DataView(this._inst.exports.mem.buffer);
                },
                // func nanotime1() int64
                "runtime.nanotime1": (sp) => {
                  sp >>>= 0;
                  setInt64(sp + 8, (timeOrigin + performance.now()) * 1e6);
                },
                // func walltime() (sec int64, nsec int32)
                "runtime.walltime": (sp) => {
                  sp >>>= 0;
                  const msec = (/* @__PURE__ */ new Date()).getTime();
                  setInt64(sp + 8, msec / 1e3);
                  this.mem.setInt32(sp + 16, msec % 1e3 * 1e6, true);
                },
                // func scheduleTimeoutEvent(delay int64) int32
                "runtime.scheduleTimeoutEvent": (sp) => {
                  sp >>>= 0;
                  const id = this._nextCallbackTimeoutID;
                  this._nextCallbackTimeoutID++;
                  this._scheduledTimeouts.set(id, setTimeout(
                    () => {
                      this._resume();
                      while (this._scheduledTimeouts.has(id)) {
                        console.warn("scheduleTimeoutEvent: missed timeout event");
                        this._resume();
                      }
                    },
                    getInt64(sp + 8)
                  ));
                  this.mem.setInt32(sp + 16, id, true);
                },
                // func clearTimeoutEvent(id int32)
                "runtime.clearTimeoutEvent": (sp) => {
                  sp >>>= 0;
                  const id = this.mem.getInt32(sp + 8, true);
                  clearTimeout(this._scheduledTimeouts.get(id));
                  this._scheduledTimeouts.delete(id);
                },
                // func getRandomData(r []byte)
                "runtime.getRandomData": (sp) => {
                  sp >>>= 0;
                  crypto.getRandomValues(loadSlice(sp + 8));
                },
                // func finalizeRef(v ref)
                "syscall/js.finalizeRef": (sp) => {
                  sp >>>= 0;
                  const id = this.mem.getUint32(sp + 8, true);
                  this._goRefCounts[id]--;
                  if (this._goRefCounts[id] === 0) {
                    const v = this._values[id];
                    this._values[id] = null;
                    this._ids.delete(v);
                    this._idPool.push(id);
                  }
                },
                // func stringVal(value string) ref
                "syscall/js.stringVal": (sp) => {
                  sp >>>= 0;
                  storeValue(sp + 24, loadString(sp + 8));
                },
                // func valueGet(v ref, p string) ref
                "syscall/js.valueGet": (sp) => {
                  sp >>>= 0;
                  const result = Reflect.get(loadValue(sp + 8), loadString(sp + 16));
                  sp = this._inst.exports.getsp() >>> 0;
                  storeValue(sp + 32, result);
                },
                // func valueSet(v ref, p string, x ref)
                "syscall/js.valueSet": (sp) => {
                  sp >>>= 0;
                  Reflect.set(loadValue(sp + 8), loadString(sp + 16), loadValue(sp + 32));
                },
                // func valueDelete(v ref, p string)
                "syscall/js.valueDelete": (sp) => {
                  sp >>>= 0;
                  Reflect.deleteProperty(loadValue(sp + 8), loadString(sp + 16));
                },
                // func valueIndex(v ref, i int) ref
                "syscall/js.valueIndex": (sp) => {
                  sp >>>= 0;
                  storeValue(sp + 24, Reflect.get(loadValue(sp + 8), getInt64(sp + 16)));
                },
                // valueSetIndex(v ref, i int, x ref)
                "syscall/js.valueSetIndex": (sp) => {
                  sp >>>= 0;
                  Reflect.set(loadValue(sp + 8), getInt64(sp + 16), loadValue(sp + 24));
                },
                // func valueCall(v ref, m string, args []ref) (ref, bool)
                "syscall/js.valueCall": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const m = Reflect.get(v, loadString(sp + 16));
                    const args = loadSliceOfValues(sp + 32);
                    const result = Reflect.apply(m, v, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 56, result);
                    this.mem.setUint8(sp + 64, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 56, err);
                    this.mem.setUint8(sp + 64, 0);
                  }
                },
                // func valueInvoke(v ref, args []ref) (ref, bool)
                "syscall/js.valueInvoke": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const args = loadSliceOfValues(sp + 16);
                    const result = Reflect.apply(v, void 0, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, result);
                    this.mem.setUint8(sp + 48, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, err);
                    this.mem.setUint8(sp + 48, 0);
                  }
                },
                // func valueNew(v ref, args []ref) (ref, bool)
                "syscall/js.valueNew": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const args = loadSliceOfValues(sp + 16);
                    const result = Reflect.construct(v, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, result);
                    this.mem.setUint8(sp + 48, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, err);
                    this.mem.setUint8(sp + 48, 0);
                  }
                },
                // func valueLength(v ref) int
                "syscall/js.valueLength": (sp) => {
                  sp >>>= 0;
                  setInt64(sp + 16, parseInt(loadValue(sp + 8).length));
                },
                // valuePrepareString(v ref) (ref, int)
                "syscall/js.valuePrepareString": (sp) => {
                  sp >>>= 0;
                  const str = encoder.encode(String(loadValue(sp + 8)));
                  storeValue(sp + 16, str);
                  setInt64(sp + 24, str.length);
                },
                // valueLoadString(v ref, b []byte)
                "syscall/js.valueLoadString": (sp) => {
                  sp >>>= 0;
                  const str = loadValue(sp + 8);
                  loadSlice(sp + 16).set(str);
                },
                // func valueInstanceOf(v ref, t ref) bool
                "syscall/js.valueInstanceOf": (sp) => {
                  sp >>>= 0;
                  this.mem.setUint8(sp + 24, loadValue(sp + 8) instanceof loadValue(sp + 16) ? 1 : 0);
                },
                // func copyBytesToGo(dst []byte, src ref) (int, bool)
                "syscall/js.copyBytesToGo": (sp) => {
                  sp >>>= 0;
                  const dst = loadSlice(sp + 8);
                  const src = loadValue(sp + 32);
                  if (!(src instanceof Uint8Array || src instanceof Uint8ClampedArray)) {
                    this.mem.setUint8(sp + 48, 0);
                    return;
                  }
                  const toCopy = src.subarray(0, dst.length);
                  dst.set(toCopy);
                  setInt64(sp + 40, toCopy.length);
                  this.mem.setUint8(sp + 48, 1);
                },
                // func copyBytesToJS(dst ref, src []byte) (int, bool)
                "syscall/js.copyBytesToJS": (sp) => {
                  sp >>>= 0;
                  const dst = loadValue(sp + 8);
                  const src = loadSlice(sp + 16);
                  if (!(dst instanceof Uint8Array || dst instanceof Uint8ClampedArray)) {
                    this.mem.setUint8(sp + 48, 0);
                    return;
                  }
                  const toCopy = src.subarray(0, dst.length);
                  dst.set(toCopy);
                  setInt64(sp + 40, toCopy.length);
                  this.mem.setUint8(sp + 48, 1);
                },
                "debug": (value) => {
                  console.log(value);
                }
              }
            };
          }
          run(instance) {
            return __async(this, null, function* () {
              if (!(instance instanceof WebAssembly.Instance)) {
                throw new Error("Go.run: WebAssembly.Instance expected");
              }
              this._inst = instance;
              this.mem = new DataView(this._inst.exports.mem.buffer);
              this._values = [
                // JS values that Go currently has references to, indexed by reference id
                NaN,
                0,
                null,
                true,
                false,
                globalThis,
                this
              ];
              this._goRefCounts = new Array(this._values.length).fill(Infinity);
              this._ids = /* @__PURE__ */ new Map([
                // mapping from JS values to reference ids
                [0, 1],
                [null, 2],
                [true, 3],
                [false, 4],
                [globalThis, 5],
                [this, 6]
              ]);
              this._idPool = [];
              this.exited = false;
              let offset = 4096;
              const strPtr = (str) => {
                const ptr = offset;
                const bytes = encoder.encode(str + "\\0");
                new Uint8Array(this.mem.buffer, offset, bytes.length).set(bytes);
                offset += bytes.length;
                if (offset % 8 !== 0) {
                  offset += 8 - offset % 8;
                }
                return ptr;
              };
              const argc = this.argv.length;
              const argvPtrs = [];
              this.argv.forEach((arg) => {
                argvPtrs.push(strPtr(arg));
              });
              argvPtrs.push(0);
              const keys = Object.keys(this.env).sort();
              keys.forEach((key) => {
                argvPtrs.push(strPtr(\`\${key}=\${this.env[key]}\`));
              });
              argvPtrs.push(0);
              const argv = offset;
              argvPtrs.forEach((ptr) => {
                this.mem.setUint32(offset, ptr, true);
                this.mem.setUint32(offset + 4, 0, true);
                offset += 8;
              });
              const wasmMinDataAddr = 4096 + 8192;
              if (offset >= wasmMinDataAddr) {
                throw new Error("total length of command line and environment variables exceeds limit");
              }
              this._inst.exports.run(argc, argv);
              if (this.exited) {
                this._resolveExitPromise();
              }
              yield this._exitPromise;
            });
          }
          _resume() {
            if (this.exited) {
              throw new Error("Go program has already exited");
            }
            this._inst.exports.resume();
            if (this.exited) {
              this._resolveExitPromise();
            }
          }
          _makeFuncWrapper(id) {
            const go = this;
            return function() {
              const event = { id, this: this, args: arguments };
              go._pendingEvent = event;
              go._resume();
              return event.result;
            };
          }
        };
      })();
      onmessage = ({ data: wasm }) => {
        let decoder = new TextDecoder();
        let fs = globalThis.fs;
        let stderr = "";
        fs.writeSync = (fd, buffer) => {
          if (fd === 1) {
            postMessage(buffer);
          } else if (fd === 2) {
            stderr += decoder.decode(buffer);
            let parts = stderr.split("\\n");
            if (parts.length > 1) console.log(parts.slice(0, -1).join("\\n"));
            stderr = parts[parts.length - 1];
          } else {
            throw new Error("Bad write");
          }
          return buffer.length;
        };
        let stdin = [];
        let resumeStdin;
        let stdinPos = 0;
        onmessage = ({ data }) => {
          if (data.length > 0) {
            stdin.push(data);
            if (resumeStdin) resumeStdin();
          }
          return go;
        };
        fs.read = (fd, buffer, offset, length, position, callback) => {
          if (fd !== 0 || offset !== 0 || length !== buffer.length || position !== null) {
            throw new Error("Bad read");
          }
          if (stdin.length === 0) {
            resumeStdin = () => fs.read(fd, buffer, offset, length, position, callback);
            return;
          }
          let first = stdin[0];
          let count = Math.max(0, Math.min(length, first.length - stdinPos));
          buffer.set(first.subarray(stdinPos, stdinPos + count), offset);
          stdinPos += count;
          if (stdinPos === first.length) {
            stdin.shift();
            stdinPos = 0;
          }
          callback(null, count);
        };
        let go = new globalThis.Go();
        go.argv = ["", \`--service=\${"0.28.2"}\`];
        tryToInstantiateModule(wasm, go).then(
          (instance) => {
            postMessage(null);
            go.run(instance);
          },
          (error) => {
            postMessage(error);
          }
        );
        return go;
      };
      function tryToInstantiateModule(wasm, go) {
        return __async(this, null, function* () {
          if (wasm instanceof WebAssembly.Module) {
            return WebAssembly.instantiate(wasm, go.importObject);
          }
          const res = yield fetch(wasm);
          if (!res.ok) throw new Error(\`Failed to download \${JSON.stringify(wasm)}\`);
          if ("instantiateStreaming" in WebAssembly && /^application\\/wasm($|;)/i.test(res.headers.get("Content-Type") || "")) {
            const result2 = yield WebAssembly.instantiateStreaming(res, go.importObject);
            return result2.instance;
          }
          const bytes = yield res.arrayBuffer();
          const result = yield WebAssembly.instantiate(bytes, go.importObject);
          return result.instance;
        });
      }
      return (m) => onmessage(m);
    })(postMessage)`],{type:"text/javascript"});c=new Worker(URL.createObjectURL(T))}else{let T=(F=>{var z=(A,C,b)=>new Promise((p,l)=>{var d=$=>{try{v(b.next($))}catch(f){l(f)}},m=$=>{try{v(b.throw($))}catch(f){l(f)}},v=$=>$.done?p($.value):Promise.resolve($.value).then(d,m);v((b=b.apply(A,C)).next())});let G,U={};for(let A=self;A;A=Object.getPrototypeOf(A))for(let C of Object.getOwnPropertyNames(A))C in U||Object.defineProperty(U,C,{get:()=>self[C]});(()=>{let A=()=>{let p=new Error("not implemented");return p.code="ENOSYS",p};if(!U.fs){let p="";U.fs={constants:{O_WRONLY:-1,O_RDWR:-1,O_CREAT:-1,O_TRUNC:-1,O_APPEND:-1,O_EXCL:-1,O_DIRECTORY:-1},writeSync(l,d){p+=b.decode(d);let m=p.lastIndexOf(`
`);return m!=-1&&(console.log(p.substring(0,m)),p=p.substring(m+1)),d.length},write(l,d,m,v,$,f){if(m!==0||v!==d.length||$!==null){f(A());return}let y=this.writeSync(l,d);f(null,y)},chmod(l,d,m){m(A())},chown(l,d,m,v){v(A())},close(l,d){d(A())},fchmod(l,d,m){m(A())},fchown(l,d,m,v){v(A())},fstat(l,d){d(A())},fsync(l,d){d(null)},ftruncate(l,d,m){m(A())},lchown(l,d,m,v){v(A())},link(l,d,m){m(A())},lstat(l,d){d(A())},mkdir(l,d,m){m(A())},open(l,d,m,v){v(A())},read(l,d,m,v,$,f){f(A())},readdir(l,d){d(A())},readlink(l,d){d(A())},rename(l,d,m){m(A())},rmdir(l,d){d(A())},stat(l,d){d(A())},symlink(l,d,m){m(A())},truncate(l,d,m){m(A())},unlink(l,d){d(A())},utimes(l,d,m,v){v(A())}}}if(U.process||(U.process={getuid(){return-1},getgid(){return-1},geteuid(){return-1},getegid(){return-1},getgroups(){throw A()},pid:-1,ppid:-1,umask(){throw A()},cwd(){throw A()},chdir(){throw A()}}),U.path||(U.path={resolve(...p){return p.join("/")}}),!U.crypto)throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");if(!U.performance)throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");if(!U.TextEncoder)throw new Error("globalThis.TextEncoder is not available, polyfill required");if(!U.TextDecoder)throw new Error("globalThis.TextDecoder is not available, polyfill required");let C=new TextEncoder("utf-8"),b=new TextDecoder("utf-8");U.Go=class{constructor(){this.argv=["js"],this.env={},this.exit=n=>{n!==0&&console.warn("exit code:",n)},this._exitPromise=new Promise(n=>{this._resolveExitPromise=n}),this._pendingEvent=null,this._scheduledTimeouts=new Map,this._nextCallbackTimeoutID=1;let p=(n,o)=>{this.mem.setUint32(n+0,o,!0),this.mem.setUint32(n+4,Math.floor(o/4294967296),!0)},l=(n,o)=>{this.mem.setUint32(n+0,o,!0)},d=n=>{let o=this.mem.getUint32(n+0,!0),k=this.mem.getInt32(n+4,!0);return o+k*4294967296},m=n=>{let o=this.mem.getFloat64(n,!0);if(o===0)return;if(!isNaN(o))return o;let k=this.mem.getUint32(n,!0);return this._values[k]},v=(n,o)=>{if(typeof o=="number"&&o!==0){if(isNaN(o)){this.mem.setUint32(n+4,2146959360,!0),this.mem.setUint32(n,0,!0);return}this.mem.setFloat64(n,o,!0);return}if(o===void 0){this.mem.setFloat64(n,0,!0);return}let O=this._ids.get(o);O===void 0&&(O=this._idPool.pop(),O===void 0&&(O=this._values.length),this._values[O]=o,this._goRefCounts[O]=0,this._ids.set(o,O)),this._goRefCounts[O]++;let V=0;switch(typeof o){case"object":o!==null&&(V=1);break;case"string":V=2;break;case"symbol":V=3;break;case"function":V=4;break}this.mem.setUint32(n+4,2146959360|V,!0),this.mem.setUint32(n,O,!0)},$=n=>{let o=d(n+0),k=d(n+8);return new Uint8Array(this._inst.exports.mem.buffer,o,k)},f=n=>{let o=d(n+0),k=d(n+8),O=new Array(k);for(let V=0;V<k;V++)O[V]=m(o+V*8);return O},y=n=>{let o=d(n+0),k=d(n+8);return b.decode(new DataView(this._inst.exports.mem.buffer,o,k))},j=(n,o)=>(this._inst.exports.testExport0(),this._inst.exports.testExport(n,o)),M=Date.now()-performance.now();this.importObject={_gotest:{add:(n,o)=>n+o,callExport:j},gojs:{"runtime.wasmExit":n=>{n>>>=0;let o=this.mem.getInt32(n+8,!0);this.exited=!0,delete this._inst,delete this._values,delete this._goRefCounts,delete this._ids,delete this._idPool,this.exit(o)},"runtime.wasmWrite":n=>{n>>>=0;let o=d(n+8),k=d(n+16),O=this.mem.getInt32(n+24,!0);U.fs.writeSync(o,new Uint8Array(this._inst.exports.mem.buffer,k,O))},"runtime.resetMemoryDataView":n=>{n>>>=0,this.mem=new DataView(this._inst.exports.mem.buffer)},"runtime.nanotime1":n=>{n>>>=0,p(n+8,(M+performance.now())*1e6)},"runtime.walltime":n=>{n>>>=0;let o=new Date().getTime();p(n+8,o/1e3),this.mem.setInt32(n+16,o%1e3*1e6,!0)},"runtime.scheduleTimeoutEvent":n=>{n>>>=0;let o=this._nextCallbackTimeoutID;this._nextCallbackTimeoutID++,this._scheduledTimeouts.set(o,setTimeout(()=>{for(this._resume();this._scheduledTimeouts.has(o);)console.warn("scheduleTimeoutEvent: missed timeout event"),this._resume()},d(n+8))),this.mem.setInt32(n+16,o,!0)},"runtime.clearTimeoutEvent":n=>{n>>>=0;let o=this.mem.getInt32(n+8,!0);clearTimeout(this._scheduledTimeouts.get(o)),this._scheduledTimeouts.delete(o)},"runtime.getRandomData":n=>{n>>>=0,crypto.getRandomValues($(n+8))},"syscall/js.finalizeRef":n=>{n>>>=0;let o=this.mem.getUint32(n+8,!0);if(this._goRefCounts[o]--,this._goRefCounts[o]===0){let k=this._values[o];this._values[o]=null,this._ids.delete(k),this._idPool.push(o)}},"syscall/js.stringVal":n=>{n>>>=0,v(n+24,y(n+8))},"syscall/js.valueGet":n=>{n>>>=0;let o=Reflect.get(m(n+8),y(n+16));n=this._inst.exports.getsp()>>>0,v(n+32,o)},"syscall/js.valueSet":n=>{n>>>=0,Reflect.set(m(n+8),y(n+16),m(n+32))},"syscall/js.valueDelete":n=>{n>>>=0,Reflect.deleteProperty(m(n+8),y(n+16))},"syscall/js.valueIndex":n=>{n>>>=0,v(n+24,Reflect.get(m(n+8),d(n+16)))},"syscall/js.valueSetIndex":n=>{n>>>=0,Reflect.set(m(n+8),d(n+16),m(n+24))},"syscall/js.valueCall":n=>{n>>>=0;try{let o=m(n+8),k=Reflect.get(o,y(n+16)),O=f(n+32),V=Reflect.apply(k,o,O);n=this._inst.exports.getsp()>>>0,v(n+56,V),this.mem.setUint8(n+64,1)}catch(o){n=this._inst.exports.getsp()>>>0,v(n+56,o),this.mem.setUint8(n+64,0)}},"syscall/js.valueInvoke":n=>{n>>>=0;try{let o=m(n+8),k=f(n+16),O=Reflect.apply(o,void 0,k);n=this._inst.exports.getsp()>>>0,v(n+40,O),this.mem.setUint8(n+48,1)}catch(o){n=this._inst.exports.getsp()>>>0,v(n+40,o),this.mem.setUint8(n+48,0)}},"syscall/js.valueNew":n=>{n>>>=0;try{let o=m(n+8),k=f(n+16),O=Reflect.construct(o,k);n=this._inst.exports.getsp()>>>0,v(n+40,O),this.mem.setUint8(n+48,1)}catch(o){n=this._inst.exports.getsp()>>>0,v(n+40,o),this.mem.setUint8(n+48,0)}},"syscall/js.valueLength":n=>{n>>>=0,p(n+16,parseInt(m(n+8).length))},"syscall/js.valuePrepareString":n=>{n>>>=0;let o=C.encode(String(m(n+8)));v(n+16,o),p(n+24,o.length)},"syscall/js.valueLoadString":n=>{n>>>=0;let o=m(n+8);$(n+16).set(o)},"syscall/js.valueInstanceOf":n=>{n>>>=0,this.mem.setUint8(n+24,m(n+8)instanceof m(n+16)?1:0)},"syscall/js.copyBytesToGo":n=>{n>>>=0;let o=$(n+8),k=m(n+32);if(!(k instanceof Uint8Array||k instanceof Uint8ClampedArray)){this.mem.setUint8(n+48,0);return}let O=k.subarray(0,o.length);o.set(O),p(n+40,O.length),this.mem.setUint8(n+48,1)},"syscall/js.copyBytesToJS":n=>{n>>>=0;let o=m(n+8),k=$(n+16);if(!(o instanceof Uint8Array||o instanceof Uint8ClampedArray)){this.mem.setUint8(n+48,0);return}let O=k.subarray(0,o.length);o.set(O),p(n+40,O.length),this.mem.setUint8(n+48,1)},debug:n=>{console.log(n)}}}}run(p){return z(this,null,function*(){if(!(p instanceof WebAssembly.Instance))throw new Error("Go.run: WebAssembly.Instance expected");this._inst=p,this.mem=new DataView(this._inst.exports.mem.buffer),this._values=[NaN,0,null,!0,!1,U,this],this._goRefCounts=new Array(this._values.length).fill(1/0),this._ids=new Map([[0,1],[null,2],[!0,3],[!1,4],[U,5],[this,6]]),this._idPool=[],this.exited=!1;let l=4096,d=j=>{let M=l,n=C.encode(j+"\0");return new Uint8Array(this.mem.buffer,l,n.length).set(n),l+=n.length,l%8!==0&&(l+=8-l%8),M},m=this.argv.length,v=[];this.argv.forEach(j=>{v.push(d(j))}),v.push(0),Object.keys(this.env).sort().forEach(j=>{v.push(d(`${j}=${this.env[j]}`))}),v.push(0);let f=l;if(v.forEach(j=>{this.mem.setUint32(l,j,!0),this.mem.setUint32(l+4,0,!0),l+=8}),l>=12288)throw new Error("total length of command line and environment variables exceeds limit");this._inst.exports.run(m,f),this.exited&&this._resolveExitPromise(),yield this._exitPromise})}_resume(){if(this.exited)throw new Error("Go program has already exited");this._inst.exports.resume(),this.exited&&this._resolveExitPromise()}_makeFuncWrapper(p){let l=this;return function(){let d={id:p,this:this,args:arguments};return l._pendingEvent=d,l._resume(),d.result}}}})(),G=({data:A})=>{let C=new TextDecoder,b=U.fs,p="";b.writeSync=($,f)=>{if($===1)F(f);else if($===2){p+=C.decode(f);let y=p.split(`
`);y.length>1&&console.log(y.slice(0,-1).join(`
`)),p=y[y.length-1]}else throw new Error("Bad write");return f.length};let l=[],d,m=0;G=({data:$})=>($.length>0&&(l.push($),d&&d()),v),b.read=($,f,y,j,M,n)=>{if($!==0||y!==0||j!==f.length||M!==null)throw new Error("Bad read");if(l.length===0){d=()=>b.read($,f,y,j,M,n);return}let o=l[0],k=Math.max(0,Math.min(j,o.length-m));f.set(o.subarray(m,m+k),y),m+=k,m===o.length&&(l.shift(),m=0),n(null,k)};let v=new U.Go;return v.argv=["","--service=0.28.2"],Q(A,v).then($=>{F(null),v.run($)},$=>{F($)}),v};function Q(A,C){return z(this,null,function*(){if(A instanceof WebAssembly.Module)return WebAssembly.instantiate(A,C.importObject);let b=yield fetch(A);if(!b.ok)throw new Error(`Failed to download ${JSON.stringify(A)}`);if("instantiateStreaming"in WebAssembly&&/^application\/wasm($|;)/i.test(b.headers.get("Content-Type")||""))return(yield WebAssembly.instantiateStreaming(b,C.importObject)).instance;let p=yield b.arrayBuffer();return(yield WebAssembly.instantiate(p,C.importObject)).instance})}return A=>G(A)})(F=>c.onmessage({data:F})),L;c={onmessage:null,postMessage:F=>setTimeout(()=>{try{L=T({data:F})}catch(z){g(z)}}),terminate(){if(L)for(let F of L._scheduledTimeouts.values())clearTimeout(F)}}}let h,E,i=new Promise((T,L)=>{h=T,E=L});c.onmessage=({data:T})=>{c.onmessage=({data:L})=>x(L),T?E(T):h()},c.postMessage(t||new URL(e,location.href).toString());let{readFromStdout:x,service:_}=Tt({writeToStdin(T){c.postMessage(T)},isSync:!1,hasFS:!1,esbuild:Z});yield i,Ve=()=>{c.terminate(),_e=void 0,Ve=void 0,Be=void 0},Be={build:T=>new Promise((L,F)=>{w.then(F),_.buildOrContext({callName:"build",refs:null,options:T,isTTY:!1,defaultWD:"/",callback:(z,G)=>z?F(z):L(G)})}),context:T=>new Promise((L,F)=>{w.then(F),_.buildOrContext({callName:"context",refs:null,options:T,isTTY:!1,defaultWD:"/",callback:(z,G)=>z?F(z):L(G)})}),transform:(T,L)=>new Promise((F,z)=>{w.then(z),_.transform({callName:"transform",refs:null,input:T,options:L||{},isTTY:!1,fs:{readFile(G,U){U(new Error("Internal error"),null)},writeFile(G,U){U(null)}},callback:(G,U)=>G?z(G):F(U)})}),formatMessages:(T,L)=>new Promise((F,z)=>{w.then(z),_.formatMessages({callName:"formatMessages",refs:null,messages:T,options:L,callback:(G,U)=>G?z(G):F(U)})}),analyzeMetafile:(T,L)=>new Promise((F,z)=>{w.then(z),_.analyzeMetafile({callName:"analyzeMetafile",refs:null,metafile:typeof T=="string"?T:JSON.stringify(T),options:L,callback:(G,U)=>G?z(G):F(U)})})}}),Yt=Z})(typeof Ge=="object"?Ge:{set exports(a){(typeof self<"u"?self:this).esbuild=a}})});var Xe=sn(dt(),1);function Ue(a){return!a||typeof a!="object"?!1:!Array.isArray(a)}function ln(a,u,S){for(let N of a){let I=Pe(N,u,S);if(I)return I}return null}function on(a,u,S){for(let[N,I]of Object.entries(a)){if(!S.has(N))continue;let Y=Pe(I,u,S);if(Y)return Y}return null}function Pe(a,u,S){return typeof a=="string"?a.replaceAll("*",u??""):Array.isArray(a)?ln(a,u,S):Ue(a)?on(a,u,S):null}function an(a,u){if(!(!u||u===".")){if(u!==".."){a.push(u);return}if(!a.length)throw new Error("Import escapes its source root");a.pop()}}function be(a){let u=[];for(let S of a.split("/"))an(u,S);return u.join("/")}function Je(a,u){if(!a?.startsWith("./"))throw new Error(`Unsupported package export: ${u}`);return be(a)}function cn(a){return Ue(a)?Object.keys(a).some(u=>u.startsWith(".")):!1}var un=(a,u)=>{let[S,N]=a.split("*");return u.startsWith(S)&&u.endsWith(N)},fn=(a,u)=>Object.keys(a).filter(S=>S.includes("*")).sort((S,N)=>N.length-S.length).find(S=>un(S,u));function dn(a,u,S){let N=fn(a,u);if(!N)throw new Error(`Package does not export ${u}`);let[I,Y]=N.split("*");return Je(Pe(a[N],u.slice(I.length,u.length-Y.length),S),u)}function hn(a){return typeof a.browser=="string"&&a.browser?a.browser:a.module||a.main||"index.js"}function mn(a,u,S){return Object.hasOwn(a,u)?Je(Pe(a[u],void 0,S),u):dn(a,u,S)}function qe(a,u="",S="import"){let N=new Set(["browser",S,"default","production"]),I=a.exports;if(I===void 0)return be(u||hn(a));let Y=u?`./${u}`:".";if(cn(I))return mn(I,Y,N);if(u)throw new Error(`Package does not export ${Y}`);return Je(Pe(I,void 0,N),Y)}var Ye=a=>a.split("/").slice(0,-1).join("/"),Le=a=>a.split("/")[0],ht=a=>a.slice(a.indexOf("/")+1);function pn(a,u){let S=a?.manifest.browser;if(!Ue(S))return{specifier:u.path};let N=u.path.startsWith(".")?"./"+be(Ye(ht(u.importer))+"/"+u.path):u.path,I=S[N];return I===!1?{empty:!0,specifier:u.path}:typeof I!="string"?{specifier:u.path}:I.startsWith(".")?{local:`${Le(u.importer)}/${be(I)}`,specifier:u.path}:{specifier:I}}function gn(a,u,S){return a.namespace!=="npm"?S("project",be(Ye(a.importer)+"/"+u)):S("npm",`${Le(a.importer)}/${be(Ye(ht(a.importer))+"/"+u)}`)}function wn(a,u,S,N){return S?S.name===u?Le(a.importer):S.dependencies[u]:N.roots[u]?.id}function yn(a,u,S,{lock:N,find:I}){let Y=u.split("/"),le=Y.splice(0,u.startsWith("@")?2:1).join("/"),ne=wn(a,le,S,N);if(!ne)throw new Error(`Uninstalled browser dependency: ${u}`);let q=a.kind.startsWith("require")?"require":"import";return I("npm",`${ne}/${qe(N.packages[ne].manifest,Y.join("/"),q)}`)}async function He(a,u,S){if(a.kind==="entry-point")return S("project",be(a.path));let N=a.namespace==="npm"?u.packages[Le(a.importer)]:null,I=pn(N,a);if(I.empty)return{path:I.specifier,namespace:"empty"};if(I.local)return S("npm",I.local);if(I.specifier.startsWith("."))return gn(a,I.specifier,S);if(/^(?:[a-z]+:|\/|#)/i.test(I.specifier))throw new Error(`Unsupported browser import: ${I.specifier}`);return yn(a,I.specifier,N,{lock:u,find:S})}var mt=".webfront/developer/packages";var bn=new TextDecoder,vn=["",".tsx",".ts",".jsx",".js",".mjs",".cjs",".json",".css","/index.tsx","/index.ts","/index.js"],xn=new Map(Object.entries({mjs:"js",cjs:"js",js:"js",jsx:"jsx",ts:"ts",tsx:"tsx",css:"css",json:"json"}));async function kn(a,u,S){try{return await a(u,S)}catch(N){if(u!=="project")throw N;return}}function gt(a,u,S,N){let I=new Map,Y=(q,Z)=>{let te=N?.packages?.[q];if(te)return I.has(q)||I.set(q,new Set(te.files)),I.get(q).has(Z)?u(`${mt}/${te.key}/${Z}`):void 0},le=async(q,Z)=>{if(q==="project")return u(Z);let te=Z.indexOf("/"),[ve,Te]=[Z.slice(0,te),Z.slice(te+1)];return a?a[ve]?.get(Te):Y(ve,Te)};return{read:le,find:async(q,Z)=>{for(let te of vn){let ve=await kn(le,q,Z+te);if(ve!==void 0)return S.set(`${q}:${Z+te}`,ve),{path:Z+te,namespace:q}}throw new Error(`Cannot resolve ${Z}`)}}}function En(a,u,S){return wt(a,u,S,new Map)}function wt(a,u,S,N){let{read:I,find:Y}=gt(u,S,N,a),le=ne=>async q=>{let Z=N.get(`${ne}:${q.path}`)??await I(ne,q.path),te=xn.get(q.path.split(".").pop());return{contents:te?bn.decode(Z):Z,loader:te??"file"}};return{name:"webfront-project",setup(ne){ne.onResolve({filter:/.*/},q=>He(q,a,Y)),ne.onLoad({filter:/.*/,namespace:"empty"},()=>({contents:"",loader:"js"}));for(let q of["project","npm"])ne.onLoad({filter:/.*/,namespace:q},le(q))}}}async function yt(a,{entry:u,lock:S,packages:N,readProject:I}){let Y=await a.build({entryPoints:[u],bundle:!0,write:!1,outdir:"/output",entryNames:"app",assetNames:"assets/[name]-[hash]",format:"esm",platform:"browser",target:"es2020",jsx:"automatic",minify:!0,define:{"process.env.NODE_ENV":'"production"'},legalComments:"inline",plugins:[En(S,N,I)]});return new Map(Y.outputFiles.map(le=>[le.path.replace(/^\/output\//,""),le.contents]))}var _n=new Set(["assert","async_hooks","buffer","child_process","cluster","console","constants","crypto","dgram","diagnostics_channel","dns","domain","events","fs","http","http2","https","inspector","module","net","os","path","perf_hooks","process","punycode","querystring","readline","repl","stream","string_decoder","sys","timers","tls","trace_events","tty","url","util","v8","vm","wasi","worker_threads","zlib"]),jn=/^(?:node:|[a-z_][a-z0-9_]*(?:\/|$))/;function Sn(a){if(a.startsWith("node:"))return a.slice(5).split("/")[0];let u=a.split("/")[0];return _n.has(u)?u:null}var pt=a=>`"${a}" is a Node.js API, which WebFront scripts do not provide (no fs, child_process or process; use the context API)`;function $n(a,u,S){return{name:"webfront-script",setup(N){N.onResolve({filter:/^webfront-script-entry$/},()=>S(a.namespace,a.path)),N.onResolve({filter:jn},async I=>{let Y=Sn(I.path);if(Y){if(I.path.startsWith("node:"))return{errors:[{text:pt(Y)}]};try{return await He(I,u,S)}catch{return{errors:[{text:pt(Y)}]}}}})}}}async function bt(a,{entry:u,lock:S,packages:N,readProject:I}){let Y=new Map,{find:le}=gt(N,I,Y,S),ne=await a.build({entryPoints:["webfront-script-entry"],bundle:!0,write:!1,outfile:"/output/script.js",format:"esm",platform:"browser",target:"es2022",jsx:"automatic",legalComments:"inline",define:{"process.env.NODE_ENV":'"production"'},plugins:[$n(u,S,le),wt(S,N,I,Y)]});return new Map(ne.outputFiles.map(q=>[q.path.replace(/^\/output\//,""),q.contents]))}var Qe=new Map,Pn=0,Tn=a=>new Promise((u,S)=>{let N=++Pn;Qe.set(N,{resolve:u,reject:S}),self.postMessage({type:"read",id:N,path:a})}),On=Xe.initialize({wasmURL:new URL("./esbuild.wasm",import.meta.url).href,worker:!1});self.onmessage=async({data:a})=>{if(a.type==="read-result"){let u=Qe.get(a.id);if(!u)return;Qe.delete(a.id),a.error?u.reject(new Error(a.error)):u.resolve(a.bytes);return}if(!(a.type!=="build"&&a.type!=="script"))try{await On;let u=await(a.type==="script"?bt:yt)(Xe,{...a,readProject:Tn});self.postMessage({type:"result",files:u})}catch(u){self.postMessage({type:"error",error:u.message})}};
