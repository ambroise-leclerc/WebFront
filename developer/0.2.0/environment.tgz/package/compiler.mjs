var Vt=Object.create;var lt=Object.defineProperty;var Lt=Object.getOwnPropertyDescriptor;var Bt=Object.getOwnPropertyNames;var Wt=Object.getPrototypeOf,zt=Object.prototype.hasOwnProperty;var Gt=(U,R)=>()=>{try{return R||U((R={exports:{}}).exports,R),R.exports}catch(q){throw R=0,q}};var Jt=(U,R,q,ee)=>{if(R&&typeof R=="object"||typeof R=="function")for(let J of Bt(R))!zt.call(U,J)&&J!==q&&lt(U,J,{get:()=>R[J],enumerable:!(ee=Lt(R,J))||ee.enumerable});return U};var qt=(U,R,q)=>(q=U!=null?Vt(Wt(U)):{},Jt(R||!U||!U.__esModule?lt(q,"default",{value:U,enumerable:!0}):q,U));var ot=Gt((nn,ze)=>{(U=>{"use strict";var R=Object.defineProperty,q=Object.getOwnPropertyDescriptor,ee=Object.getOwnPropertyNames,J=Object.prototype.hasOwnProperty,K=(e,t)=>{for(var r in t)R(e,r,{get:t[r],enumerable:!0})},ne=(e,t,r,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let m of ee(t))!J.call(e,m)&&m!==r&&R(e,m,{get:()=>t[m],enumerable:!(a=q(t,m))||a.enumerable});return e},F=e=>ne(R({},"__esModule",{value:!0}),e),B=(e,t,r)=>new Promise((a,m)=>{var p=i=>{try{x(r.next(i))}catch(b){m(b)}},f=i=>{try{x(r.throw(i))}catch(b){m(b)}},x=i=>i.done?a(i.value):Promise.resolve(i.value).then(p,f);x((r=r.apply(e,t)).next())}),te={};K(te,{analyzeMetafile:()=>Pt,analyzeMetafileSync:()=>Ut,build:()=>jt,buildSync:()=>Ot,context:()=>St,default:()=>Mt,formatMessages:()=>Tt,formatMessagesSync:()=>At,initialize:()=>Rt,stop:()=>Dt,transform:()=>$t,transformSync:()=>Ct,version:()=>_t}),U.exports=F(te);function he(e){let t=a=>{if(a===null)r.write8(0);else if(typeof a=="boolean")r.write8(1),r.write8(+a);else if(typeof a=="number")r.write8(2),r.write32(a|0);else if(typeof a=="string")r.write8(3),r.write(re(a));else if(a instanceof Uint8Array)r.write8(4),r.write(a);else if(a instanceof Array){r.write8(5),r.write32(a.length);for(let m of a)t(m)}else{let m=Object.keys(a);r.write8(6),r.write32(m.length);for(let p of m)r.write(re(p)),t(a[p])}},r=new pe;return r.write32(0),r.write32(e.id<<1|+!e.isRequest),t(e.value),We(r.buf,r.len-4,0),r.buf.subarray(0,r.len)}function oe(e){let t=()=>{switch(r.read8()){case 0:return null;case 1:return!!r.read8();case 2:return r.read32();case 3:return ce(r.read());case 4:return r.read();case 5:{let f=r.read32(),x=[];for(let i=0;i<f;i++)x.push(t());return x}case 6:{let f=r.read32(),x={};for(let i=0;i<f;i++)x[ce(r.read())]=t();return x}default:throw new Error("Invalid packet")}},r=new pe(e),a=r.read32(),m=(a&1)===0;a>>>=1;let p=t();if(r.ptr!==e.length)throw new Error("Invalid packet");return{id:a,isRequest:m,value:p}}var pe=class{constructor(e=new Uint8Array(1024)){this.buf=e,this.len=0,this.ptr=0}_write(e){if(this.len+e>this.buf.length){let t=new Uint8Array((this.len+e)*2);t.set(this.buf),this.buf=t}return this.len+=e,this.len-e}write8(e){let t=this._write(1);this.buf[t]=e}write32(e){let t=this._write(4);We(this.buf,e,t)}write(e){let t=this._write(4+e.length);We(this.buf,e.length,t),this.buf.set(e,t+4)}_read(e){if(this.ptr+e>this.buf.length)throw new Error("Invalid packet");return this.ptr+=e,this.ptr-e}read8(){return this.buf[this._read(1)]}read32(){return Ue(this.buf,this._read(4))}read(){let e=this.read32(),t=new Uint8Array(e),r=this._read(t.length);return t.set(this.buf.subarray(r,r+e)),t}},re,ce,me;if(typeof TextEncoder<"u"&&typeof TextDecoder<"u"){let e=new TextEncoder,t=new TextDecoder;re=r=>e.encode(r),ce=r=>t.decode(r),me='new TextEncoder().encode("")'}else if(typeof Buffer<"u")re=e=>Buffer.from(e),ce=e=>{let{buffer:t,byteOffset:r,byteLength:a}=e;return Buffer.from(t,r,a).toString()},me='Buffer.from("")';else throw new Error("No UTF-8 codec found");if(!(re("")instanceof Uint8Array))throw new Error(`Invariant violation: "${me} instanceof Uint8Array" is incorrectly false

This indicates that your JavaScript environment is broken. You cannot use
esbuild in this environment because esbuild relies on this invariant. This
is not a problem with esbuild. You need to fix your environment instead.
`);function Ue(e,t){return(e[t++]|e[t++]<<8|e[t++]<<16|e[t++]<<24)>>>0}function We(e,t,r){e[r++]=t,e[r++]=t>>8,e[r++]=t>>16,e[r++]=t>>24}var we=String.fromCharCode;function ue(e,t,r){let a=e[t],m=1,p=0;for(let f=0;f<t;f++)e[f]===10?(m++,p=0):p++;throw new SyntaxError(r||(t===e.length?"Unexpected end of input while parsing JSON":a>=32&&a<=126?`Unexpected character ${we(a)} in JSON at position ${t} (line ${m}, column ${p})`:`Unexpected byte 0x${a.toString(16)} in JSON at position ${t} (line ${m}, column ${p})`))}function ct(e){if(!(e instanceof Uint8Array))throw new Error("JSON input must be a Uint8Array");let t=[],r=[],a=[],m=e.length,p=null,f=0,x,i=0;for(;i<m;){let b=e[i++];if(b<=32)continue;let k;switch(f===2&&p===null&&b!==34&&b!==125&&ue(e,--i),b){case 116:{(e[i++]!==114||e[i++]!==117||e[i++]!==101)&&ue(e,--i),k=!0;break}case 102:{(e[i++]!==97||e[i++]!==108||e[i++]!==115||e[i++]!==101)&&ue(e,--i),k=!1;break}case 110:{(e[i++]!==117||e[i++]!==108||e[i++]!==108)&&ue(e,--i),k=null;break}case 45:case 46:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:{let S=i;for(k=we(b),b=e[i];;){switch(b){case 43:case 45:case 46:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:case 101:case 69:{k+=we(b),b=e[++i];continue}}break}k=+k,isNaN(k)&&ue(e,--S,"Invalid number");break}case 34:{for(k="";i>=m&&ue(e,m),b=e[i++],b!==34;)if(b===92)switch(e[i++]){case 34:k+='"';break;case 47:k+="/";break;case 92:k+="\\";break;case 98:k+="\b";break;case 102:k+="\f";break;case 110:k+=`
`;break;case 114:k+="\r";break;case 116:k+="	";break;case 117:{let S=0;for(let V=0;V<4;V++)b=e[i++],S<<=4,b>=48&&b<=57?S|=b-48:b>=97&&b<=102?S|=b+-87:b>=65&&b<=70?S|=b+-55:ue(e,--i);k+=we(S);break}default:ue(e,--i);break}else if(b<=127)k+=we(b);else if((b&224)===192)k+=we((b&31)<<6|e[i++]&63);else if((b&240)===224)k+=we((b&15)<<12|(e[i++]&63)<<6|e[i++]&63);else if((b&248)==240){let S=(b&7)<<18|(e[i++]&63)<<12|(e[i++]&63)<<6|e[i++]&63;S>65535&&(S-=65536,k+=we(S>>10&1023|55296),S=56320|S&1023),k+=we(S)}k[0];break}case 91:{k=[],t.push(p),r.push(x),a.push(f),p=null,x=k,f=1;continue}case 123:{k={},t.push(p),r.push(x),a.push(f),p=null,x=k,f=2;continue}case 93:{f!==1&&ue(e,--i),k=x,p=t.pop(),x=r.pop(),f=a.pop();break}case 125:{f!==2&&ue(e,--i),k=x,p=t.pop(),x=r.pop(),f=a.pop();break}default:ue(e,--i)}for(b=e[i];b<=32;)b=e[++i];switch(f){case 0:{if(i===m)return k;break}case 1:{if(x.push(k),b===44){i++;continue}if(b===93)continue;break}case 2:{if(p===null){if(p=k,b===58){i++;continue}}else{if(x[p]=k,p=null,b===44){i++;continue}if(b===125)continue}break}}break}ue(e,i)}var Z=JSON.stringify,Ye="warning",He="silent";function $e(e,t){let r=[];for(let a of e){if(ie(a,t),a.indexOf(",")>=0)throw new Error(`Invalid ${t}: ${a}`);r.push(a)}return r.join(",")}var De=()=>null,Y=e=>typeof e=="boolean"?null:"a boolean",C=e=>typeof e=="string"?null:"a string",Re=e=>e instanceof RegExp?null:"a RegExp object",_e=e=>typeof e=="number"&&e===(e|0)?null:"an integer",ut=e=>typeof e=="number"&&e===(e|0)&&e>=0&&e<=65535?null:"a valid port number",Qe=e=>typeof e=="function"?null:"a function",ye=e=>Array.isArray(e)?null:"an array",se=e=>Array.isArray(e)&&e.every(t=>typeof t=="string")?null:"an array of strings",ae=e=>typeof e=="object"&&e!==null&&!Array.isArray(e)?null:"an object",ft=e=>typeof e=="object"&&e!==null?null:"an array or an object",dt=e=>e instanceof WebAssembly.Module?null:"a WebAssembly.Module",Xe=e=>typeof e=="object"&&!Array.isArray(e)?null:"an object or null",Ke=e=>typeof e=="string"||typeof e=="boolean"?null:"a string or a boolean",ht=e=>typeof e=="string"||typeof e=="object"&&e!==null&&!Array.isArray(e)?null:"a string or an object",Ze=e=>typeof e=="string"||Array.isArray(e)&&e.every(t=>typeof t=="string")?null:"a string or an array of strings",et=e=>typeof e=="string"||e instanceof Uint8Array?null:"a string or a Uint8Array",mt=e=>typeof e=="string"||e instanceof URL?null:"a string or a URL";function s(e,t,r,a){let m=e[r];if(t[r+""]=!0,m===void 0)return;let p=a(m);if(p!==null)throw new Error(`${Z(r)} must be ${p}`);return m}function Q(e,t,r){for(let a in e)if(!(a in t))throw new Error(`Invalid option ${r}: ${Z(a)}`)}function pt(e){let t=Object.create(null),r=s(e,t,"wasmURL",mt),a=s(e,t,"wasmModule",dt),m=s(e,t,"worker",Y);return Q(e,t,"in initialize() call"),{wasmURL:r,wasmModule:a,worker:m}}function tt(e){let t;if(e!==void 0){t=Object.create(null);for(let r in e){let a=e[r];if(typeof a=="string"||a===!1)t[r]=a;else throw new Error(`Expected ${Z(r)} in mangle cache to map to either a string or false`)}}return t}function Ie(e,t,r,a,m){let p=s(t,r,"color",Y),f=s(t,r,"logLevel",C),x=s(t,r,"logLimit",_e),i=s(t,r,"logStyle",C);p!==void 0?e.push(`--color=${p}`):a&&e.push("--color=true"),e.push(`--log-level=${f||m}`),e.push(`--log-limit=${x||0}`),i&&e.push(`--log-style=${i}`)}function ie(e,t,r){if(typeof e!="string")throw new Error(`Expected value for ${t}${r!==void 0?" "+Z(r):""} to be a string, got ${typeof e} instead`);return e}function nt(e,t,r){let a=s(t,r,"legalComments",C),m=s(t,r,"sourceRoot",C),p=s(t,r,"sourcesContent",Y),f=s(t,r,"target",Ze),x=s(t,r,"format",C),i=s(t,r,"globalName",C),b=s(t,r,"mangleProps",Re),k=s(t,r,"reserveProps",Re),S=s(t,r,"mangleQuoted",Y),V=s(t,r,"minify",Y),I=s(t,r,"minifySyntax",Y),W=s(t,r,"minifyWhitespace",Y),z=s(t,r,"minifyIdentifiers",Y),O=s(t,r,"lineLimit",_e),H=s(t,r,"drop",se),P=s(t,r,"dropLabels",se),T=s(t,r,"charset",C),w=s(t,r,"treeShaking",Y),h=s(t,r,"ignoreAnnotations",Y),l=s(t,r,"jsx",C),u=s(t,r,"jsxFactory",C),d=s(t,r,"jsxFragment",C),y=s(t,r,"jsxImportSource",C),_=s(t,r,"jsxDev",Y),c=s(t,r,"jsxSideEffects",Y),g=s(t,r,"define",ae),E=s(t,r,"logOverride",ae),D=s(t,r,"supported",ae),n=s(t,r,"pure",se),o=s(t,r,"keepNames",Y),v=s(t,r,"platform",C),$=s(t,r,"tsconfigRaw",ht),M=s(t,r,"absPaths",se);if(a&&e.push(`--legal-comments=${a}`),m!==void 0&&e.push(`--source-root=${m}`),p!==void 0&&e.push(`--sources-content=${p}`),f&&e.push(`--target=${$e(Array.isArray(f)?f:[f],"target")}`),x&&e.push(`--format=${x}`),i&&e.push(`--global-name=${i}`),v&&e.push(`--platform=${v}`),$&&e.push(`--tsconfig-raw=${typeof $=="string"?$:JSON.stringify($)}`),V&&e.push("--minify"),I&&e.push("--minify-syntax"),W&&e.push("--minify-whitespace"),z&&e.push("--minify-identifiers"),O&&e.push(`--line-limit=${O}`),T&&e.push(`--charset=${T}`),w!==void 0&&e.push(`--tree-shaking=${w}`),h&&e.push("--ignore-annotations"),H)for(let j of H)e.push(`--drop:${ie(j,"drop")}`);if(P&&e.push(`--drop-labels=${$e(P,"drop label")}`),M&&e.push(`--abs-paths=${$e(M,"abs paths")}`),b&&e.push(`--mangle-props=${Fe(b)}`),k&&e.push(`--reserve-props=${Fe(k)}`),S!==void 0&&e.push(`--mangle-quoted=${S}`),l&&e.push(`--jsx=${l}`),u&&e.push(`--jsx-factory=${u}`),d&&e.push(`--jsx-fragment=${d}`),y&&e.push(`--jsx-import-source=${y}`),_&&e.push("--jsx-dev"),c&&e.push("--jsx-side-effects"),g)for(let j in g){if(j.indexOf("=")>=0)throw new Error(`Invalid define: ${j}`);e.push(`--define:${j}=${ie(g[j],"define",j)}`)}if(E)for(let j in E){if(j.indexOf("=")>=0)throw new Error(`Invalid log override: ${j}`);e.push(`--log-override:${j}=${ie(E[j],"log override",j)}`)}if(D)for(let j in D){if(j.indexOf("=")>=0)throw new Error(`Invalid supported: ${j}`);let G=D[j];if(typeof G!="boolean")throw new Error(`Expected value for supported ${Z(j)} to be a boolean, got ${typeof G} instead`);e.push(`--supported:${j}=${G}`)}if(n)for(let j of n)e.push(`--pure:${ie(j,"pure")}`);o&&e.push("--keep-names")}function gt(e,t,r,a,m){var p;let f=[],x=[],i=Object.create(null),b=null,k=null;Ie(f,t,i,r,a),nt(f,t,i);let S=s(t,i,"sourcemap",Ke),V=s(t,i,"bundle",Y),I=s(t,i,"splitting",Y),W=s(t,i,"preserveSymlinks",Y),z=s(t,i,"metafile",Y),O=s(t,i,"outfile",C),H=s(t,i,"outdir",C),P=s(t,i,"outbase",C),T=s(t,i,"tsconfig",C),w=s(t,i,"resolveExtensions",se),h=s(t,i,"nodePaths",se),l=s(t,i,"mainFields",se),u=s(t,i,"conditions",se),d=s(t,i,"external",se),y=s(t,i,"packages",C),_=s(t,i,"alias",ae),c=s(t,i,"loader",ae),g=s(t,i,"outExtension",ae),E=s(t,i,"publicPath",C),D=s(t,i,"entryNames",C),n=s(t,i,"chunkNames",C),o=s(t,i,"assetNames",C),v=s(t,i,"inject",se),$=s(t,i,"banner",ae),M=s(t,i,"footer",ae),j=s(t,i,"entryPoints",ft),G=s(t,i,"absWorkingDir",C),L=s(t,i,"stdin",ae),N=(p=s(t,i,"write",Y))!=null?p:m,le=s(t,i,"allowOverwrite",Y),X=s(t,i,"mangleCache",ae);if(i.plugins=!0,Q(t,i,`in ${e}() call`),S&&f.push(`--sourcemap${S===!0?"":`=${S}`}`),V&&f.push("--bundle"),le&&f.push("--allow-overwrite"),I&&f.push("--splitting"),W&&f.push("--preserve-symlinks"),z&&f.push("--metafile"),O&&f.push(`--outfile=${O}`),H&&f.push(`--outdir=${H}`),P&&f.push(`--outbase=${P}`),T&&f.push(`--tsconfig=${T}`),y&&f.push(`--packages=${y}`),w&&f.push(`--resolve-extensions=${$e(w,"resolve extension")}`),E&&f.push(`--public-path=${E}`),D&&f.push(`--entry-names=${D}`),n&&f.push(`--chunk-names=${n}`),o&&f.push(`--asset-names=${o}`),l&&f.push(`--main-fields=${$e(l,"main field")}`),u&&f.push(`--conditions=${$e(u,"condition")}`),d)for(let A of d)f.push(`--external:${ie(A,"external")}`);if(_)for(let A in _){if(A.indexOf("=")>=0)throw new Error(`Invalid package name in alias: ${A}`);f.push(`--alias:${A}=${ie(_[A],"alias",A)}`)}if($)for(let A in $){if(A.indexOf("=")>=0)throw new Error(`Invalid banner file type: ${A}`);f.push(`--banner:${A}=${ie($[A],"banner",A)}`)}if(M)for(let A in M){if(A.indexOf("=")>=0)throw new Error(`Invalid footer file type: ${A}`);f.push(`--footer:${A}=${ie(M[A],"footer",A)}`)}if(v)for(let A of v)f.push(`--inject:${ie(A,"inject")}`);if(c)for(let A in c){if(A.indexOf("=")>=0)throw new Error(`Invalid loader extension: ${A}`);f.push(`--loader:${A}=${ie(c[A],"loader",A)}`)}if(g)for(let A in g){if(A.indexOf("=")>=0)throw new Error(`Invalid out extension: ${A}`);f.push(`--out-extension:${A}=${ie(g[A],"out extension",A)}`)}if(j)if(Array.isArray(j))for(let A=0,xe=j.length;A<xe;A++){let fe=j[A];if(typeof fe=="object"&&fe!==null){let ge=Object.create(null),ke=s(fe,ge,"in",C),de=s(fe,ge,"out",C);if(Q(fe,ge,"in entry point at index "+A),ke===void 0)throw new Error('Missing property "in" for entry point at index '+A);if(de===void 0)throw new Error('Missing property "out" for entry point at index '+A);x.push([de,ke])}else x.push(["",ie(fe,"entry point at index "+A)])}else for(let A in j)x.push([A,ie(j[A],"entry point",A)]);if(L){let A=Object.create(null),xe=s(L,A,"contents",et),fe=s(L,A,"resolveDir",C),ge=s(L,A,"sourcefile",C),ke=s(L,A,"loader",C);Q(L,A,'in "stdin" object'),ge&&f.push(`--sourcefile=${ge}`),ke&&f.push(`--loader=${ke}`),fe&&(k=fe),typeof xe=="string"?b=re(xe):xe instanceof Uint8Array&&(b=xe)}let ve=[];if(h)for(let A of h)A+="",ve.push(A);return{entries:x,flags:f,write:N,stdinContents:b,stdinResolveDir:k,absWorkingDir:G,nodePaths:ve,mangleCache:tt(X)}}function wt(e,t,r,a){let m=[],p=Object.create(null);Ie(m,t,p,r,a),nt(m,t,p);let f=s(t,p,"sourcemap",Ke),x=s(t,p,"sourcefile",C),i=s(t,p,"loader",C),b=s(t,p,"banner",C),k=s(t,p,"footer",C),S=s(t,p,"mangleCache",ae);return Q(t,p,`in ${e}() call`),f&&m.push(`--sourcemap=${f===!0?"external":f}`),x&&m.push(`--sourcefile=${x}`),i&&m.push(`--loader=${i}`),b&&m.push(`--banner=${b}`),k&&m.push(`--footer=${k}`),{flags:m,mangleCache:tt(S)}}function yt(e){let t={},r={didClose:!1,reason:""},a={},m=0,p=0,f=new Uint8Array(16*1024),x=0,i=T=>{let w=x+T.length;if(w>f.length){let l=new Uint8Array(w*2);l.set(f),f=l}f.set(T,x),x+=T.length;let h=0;for(;h+4<=x;){let l=Ue(f,h);if(h+4+l>x)break;h+=4,W(f.subarray(h,h+l)),h+=l}h>0&&(f.copyWithin(0,h,x),x-=h)},b=T=>{r.didClose=!0,T&&(r.reason=": "+(T.message||T));let w="The service was stopped"+r.reason;for(let h in a)a[h](w,null);a={}},k=(T,w,h)=>{if(r.didClose)return h("The service is no longer running"+r.reason,null);let l=m++;a[l]=(u,d)=>{try{h(u,d)}finally{T&&T.unref()}},T&&T.ref(),e.writeToStdin(he({id:l,isRequest:!0,value:w}))},S=(T,w)=>{if(r.didClose)throw new Error("The service is no longer running"+r.reason);e.writeToStdin(he({id:T,isRequest:!1,value:w}))},V=(T,w)=>B(null,null,function*(){try{if(w.command==="ping"){S(T,{});return}if(typeof w.key=="number"){let h=t[w.key];if(!h)return;let l=h[w.command];if(l){yield l(T,w);return}}throw new Error("Invalid command: "+w.command)}catch(h){let l=[je(h,e,null,void 0,"")];try{S(T,{errors:l})}catch{}}}),I=!0,W=T=>{if(I){I=!1;let h=String.fromCharCode(...T);if(h!=="0.28.2")throw new Error(`Cannot start service: Host version "0.28.2" does not match binary version ${Z(h)}`);return}let w=oe(T);if(w.isRequest)V(w.id,w.value);else{let h=a[w.id];delete a[w.id],w.value.error?h(w.value.error,{}):h(null,w.value)}};return{readFromStdout:i,afterClose:b,service:{buildOrContext:({callName:T,refs:w,options:h,isTTY:l,defaultWD:u,callback:d})=>{let y=0,_=p++,c={},g={ref(){++y===1&&w&&w.ref()},unref(){--y===0&&(delete t[_],w&&w.unref())}};t[_]=c,g.ref(),bt(T,_,k,S,g,e,c,h,l,u,(E,D)=>{try{d(E,D)}finally{g.unref()}})},transform:({callName:T,refs:w,input:h,options:l,isTTY:u,fs:d,callback:y})=>{let _=rt(),c=g=>{try{if(typeof h!="string"&&!(h instanceof Uint8Array))throw new Error('The input to "transform" must be a string or a Uint8Array');let{flags:E,mangleCache:D}=wt(T,l,u,He),n={command:"transform",flags:E,inputFS:g!==null,input:g!==null?re(g):typeof h=="string"?re(h):h};D&&(n.mangleCache=D),k(w,n,(o,v)=>{if(o)return y(new Error(o),null);let $=Te(v.errors,_),M=Te(v.warnings,_),j=1,G=()=>{if(--j===0){let L={warnings:M,code:v.code,map:v.map,mangleCache:void 0,legalComments:void 0};"legalComments"in v&&(L.legalComments=v?.legalComments),v.mangleCache&&(L.mangleCache=v?.mangleCache),y(null,L)}};if($.length>0)return y(Oe("Transform failed",$,M),null);v.codeFS&&(j++,d.readFile(v.code,(L,N)=>{L!==null?y(L,null):(v.code=N,G())})),v.mapFS&&(j++,d.readFile(v.map,(L,N)=>{L!==null?y(L,null):(v.map=N,G())})),G()})}catch(E){let D=[];try{Ie(D,l,{},u,He)}catch{}let n=je(E,e,_,void 0,"");k(w,{command:"error",flags:D,error:n},()=>{n.detail=_.load(n.detail),y(Oe("Transform failed",[n],[]),null)})}};if((typeof h=="string"||h instanceof Uint8Array)&&h.length>1024*1024){let g=c;c=()=>d.writeFile(h,g)}c(null)},formatMessages:({callName:T,refs:w,messages:h,options:l,callback:u})=>{if(!l)throw new Error(`Missing second argument in ${T}() call`);let d={},y=s(l,d,"kind",C),_=s(l,d,"color",Y),c=s(l,d,"terminalWidth",_e),g=s(l,d,"logStyle",C);if(Q(l,d,`in ${T}() call`),y===void 0)throw new Error(`Missing "kind" in ${T}() call`);if(y!=="error"&&y!=="warning")throw new Error(`Expected "kind" to be "error" or "warning" in ${T}() call`);let E={command:"format-msgs",messages:be(h,"messages",null,"",c),isWarning:y==="warning"};_!==void 0&&(E.color=_),c!==void 0&&(E.terminalWidth=c),g!==void 0&&(E.logStyle=g),k(w,E,(D,n)=>{if(D)return u(new Error(D),null);u(null,n.messages)})},analyzeMetafile:({callName:T,refs:w,metafile:h,options:l,callback:u})=>{l===void 0&&(l={});let d={},y=s(l,d,"color",Y),_=s(l,d,"verbose",Y);Q(l,d,`in ${T}() call`);let c={command:"analyze-metafile",metafile:h};y!==void 0&&(c.color=y),_!==void 0&&(c.verbose=_),k(w,c,(g,E)=>{if(g)return u(new Error(g),null);u(null,E.result)})}}}}function bt(e,t,r,a,m,p,f,x,i,b,k){let S=rt(),V=e==="context",I=(O,H)=>{let P=[];try{Ie(P,x,{},i,Ye)}catch{}let T=je(O,p,S,void 0,H);r(m,{command:"error",flags:P,error:T},()=>{T.detail=S.load(T.detail),k(Oe(V?"Context failed":"Build failed",[T],[]),null)})},W;if(typeof x=="object"){let O=x.plugins;if(O!==void 0){if(!Array.isArray(O))return I(new Error('"plugins" must be an array'),"");W=O}}if(W&&W.length>0){if(p.isSync)return I(new Error("Cannot use plugins in synchronous API calls"),"");vt(t,r,a,m,p,f,x,W,S).then(O=>{if(!O.ok)return I(O.error,O.pluginName);try{z(O.requestPlugins,O.runOnEndCallbacks,O.scheduleOnDisposeCallbacks)}catch(H){I(H,"")}},O=>I(O,""));return}try{z(null,(O,H)=>H([],[]),()=>{})}catch(O){I(O,"")}function z(O,H,P){let T=p.hasFS,{entries:w,flags:h,write:l,stdinContents:u,stdinResolveDir:d,absWorkingDir:y,nodePaths:_,mangleCache:c}=gt(e,x,i,Ye,T);if(l&&!p.hasFS)throw new Error('The "write" option is unavailable in this environment');let g={command:"build",key:t,entries:w,flags:h,write:l,stdinContents:u,stdinResolveDir:d,absWorkingDir:y||b,nodePaths:_,context:V};O&&(g.plugins=O),c&&(g.mangleCache=c);let E=(o,v)=>{let $={errors:Te(o.errors,S),warnings:Te(o.warnings,S),outputFiles:void 0,metafile:void 0,mangleCache:void 0},M=$.errors.slice(),j=$.warnings.slice();o.outputFiles&&($.outputFiles=o.outputFiles.map(kt)),o.metafile&&o.metafile.length&&($.metafile=Et(o.metafile)),o.mangleCache&&($.mangleCache=o.mangleCache),o.writeToStdout!==void 0&&console.log(ce(o.writeToStdout).replace(/\n$/,"")),H($,(G,L)=>{if(M.length>0||G.length>0){let N=Oe("Build failed",M.concat(G),j.concat(L));return v(N,null,G,L)}v(null,$,G,L)})},D,n;V&&(f["on-end"]=(o,v)=>new Promise($=>{E(v,(M,j,G,L)=>{let N={errors:G,warnings:L};n&&n(M,j),D=void 0,n=void 0,a(o,N),$()})})),r(m,g,(o,v)=>{if(o)return k(new Error(o),null);if(!V)return E(v,(j,G)=>(P(),k(j,G)));if(v.errors.length>0)return k(Oe("Context failed",v.errors,v.warnings),null);let $=!1,M={rebuild:()=>(D||(D=new Promise((j,G)=>{let L;n=(le,X)=>{L||(L=()=>le?G(le):j(X))};let N=()=>{r(m,{command:"rebuild",key:t},(X,ve)=>{X?G(new Error(X)):L?L():N()})};N()})),D),watch:(j={})=>new Promise((G,L)=>{if(!p.hasFS)throw new Error('Cannot use the "watch" API in this environment');let N={},le=s(j,N,"delay",_e);Q(j,N,"in watch() call");let X={command:"watch",key:t};le&&(X.delay=le),r(m,X,ve=>{ve?L(new Error(ve)):G(void 0)})}),serve:(j={})=>new Promise((G,L)=>{if(!p.hasFS)throw new Error('Cannot use the "serve" API in this environment');let N={},le=s(j,N,"port",ut),X=s(j,N,"host",C),ve=s(j,N,"servedir",C),A=s(j,N,"keyfile",C),xe=s(j,N,"certfile",C),fe=s(j,N,"fallback",C),ge=s(j,N,"cors",ae),ke=s(j,N,"onRequest",Qe);Q(j,N,"in serve() call");let de={command:"serve",key:t,onRequest:!!ke};if(le!==void 0&&(de.port=le),X!==void 0&&(de.host=X),ve!==void 0&&(de.servedir=ve),A!==void 0&&(de.keyfile=A),xe!==void 0&&(de.certfile=xe),fe!==void 0&&(de.fallback=fe),ge){let Ae={},Pe=s(ge,Ae,"origin",Ze);Q(ge,Ae,'on "cors" object'),Array.isArray(Pe)?de.corsOrigin=Pe:Pe!==void 0&&(de.corsOrigin=[Pe])}r(m,de,(Ae,Pe)=>{if(Ae)return L(new Error(Ae));ke&&(f["serve-request"]=(Nt,Ft)=>{ke(Ft.args),a(Nt,{})}),G(Pe)})}),cancel:()=>new Promise(j=>{if($)return j();r(m,{command:"cancel",key:t},()=>{j()})}),dispose:()=>new Promise(j=>{if($)return j();$=!0,r(m,{command:"dispose",key:t},()=>{j(),P(),m.unref()})})};m.ref(),k(null,M)})}}var vt=(e,t,r,a,m,p,f,x,i)=>B(null,null,function*(){let b=[],k=[],S={},V={},I=[],W=0,z=0,O=[],H=!1;x=[...x];for(let w of x){let h={};if(typeof w!="object")throw new Error(`Plugin at index ${z} must be an object`);let l=s(w,h,"name",C);if(typeof l!="string"||l==="")throw new Error(`Plugin at index ${z} is missing a name`);try{let u=s(w,h,"setup",Qe);if(typeof u!="function")throw new Error("Plugin is missing a setup function");Q(w,h,`on plugin ${Z(l)}`);let d={name:l,onStart:!1,onEnd:!1,onResolve:[],onLoad:[]};z++;let _=u({initialOptions:f,resolve:(c,g={})=>{if(!H)throw new Error('Cannot call "resolve" before plugin setup has completed');if(typeof c!="string")throw new Error("The path to resolve must be a string");let E=Object.create(null),D=s(g,E,"pluginName",C),n=s(g,E,"importer",C),o=s(g,E,"namespace",C),v=s(g,E,"resolveDir",C),$=s(g,E,"kind",C),M=s(g,E,"pluginData",De),j=s(g,E,"with",ae);return Q(g,E,"in resolve() call"),new Promise((G,L)=>{let N={command:"resolve",path:c,key:e,pluginName:l};if(D!=null&&(N.pluginName=D),n!=null&&(N.importer=n),o!=null&&(N.namespace=o),v!=null&&(N.resolveDir=v),$!=null)N.kind=$;else throw new Error('Must specify "kind" when calling "resolve"');M!=null&&(N.pluginData=i.store(M)),j!=null&&(N.with=xt(j,"with")),t(a,N,(le,X)=>{le!==null?L(new Error(le)):G({errors:Te(X.errors,i),warnings:Te(X.warnings,i),path:X.path,external:X.external,sideEffects:X.sideEffects,namespace:X.namespace,suffix:X.suffix,pluginData:i.load(X.pluginData)})})})},onStart(c){let g='This error came from the "onStart" callback registered here:',E=Me(new Error(g),m,"onStart");b.push({name:l,callback:c,note:E}),d.onStart=!0},onEnd(c){let g='This error came from the "onEnd" callback registered here:',E=Me(new Error(g),m,"onEnd");k.push({name:l,callback:c,note:E}),d.onEnd=!0},onResolve(c,g){let E='This error came from the "onResolve" callback registered here:',D=Me(new Error(E),m,"onResolve"),n={},o=s(c,n,"filter",Re),v=s(c,n,"namespace",C);if(Q(c,n,`in onResolve() call for plugin ${Z(l)}`),o==null)throw new Error("onResolve() call is missing a filter");let $=W++;S[$]={name:l,callback:g,note:D},d.onResolve.push({id:$,filter:Fe(o),namespace:v||""})},onLoad(c,g){let E='This error came from the "onLoad" callback registered here:',D=Me(new Error(E),m,"onLoad"),n={},o=s(c,n,"filter",Re),v=s(c,n,"namespace",C);if(Q(c,n,`in onLoad() call for plugin ${Z(l)}`),o==null)throw new Error("onLoad() call is missing a filter");let $=W++;V[$]={name:l,callback:g,note:D},d.onLoad.push({id:$,filter:Fe(o),namespace:v||""})},onDispose(c){I.push(c)},esbuild:m.esbuild});_&&(yield _),O.push(d)}catch(u){return{ok:!1,error:u,pluginName:l}}}p["on-start"]=(w,h)=>B(null,null,function*(){i.clear();let l={errors:[],warnings:[]};yield Promise.all(b.map(u=>B(null,[u],function*({name:d,callback:y,note:_}){try{let c=yield y();if(c!=null){if(typeof c!="object")throw new Error(`Expected onStart() callback in plugin ${Z(d)} to return an object`);let g={},E=s(c,g,"errors",ye),D=s(c,g,"warnings",ye);Q(c,g,`from onStart() callback in plugin ${Z(d)}`),E!=null&&l.errors.push(...be(E,"errors",i,d,void 0)),D!=null&&l.warnings.push(...be(D,"warnings",i,d,void 0))}}catch(c){l.errors.push(je(c,m,i,_&&_(),d))}}))),r(w,l)}),p["on-resolve"]=(w,h)=>B(null,null,function*(){let l={},u="",d,y;for(let _ of h.ids)try{({name:u,callback:d,note:y}=S[_]);let c=yield d({path:h.path,importer:h.importer,namespace:h.namespace,resolveDir:h.resolveDir,kind:h.kind,pluginData:i.load(h.pluginData),with:h.with});if(c!=null){if(typeof c!="object")throw new Error(`Expected onResolve() callback in plugin ${Z(u)} to return an object`);let g={},E=s(c,g,"pluginName",C),D=s(c,g,"path",C),n=s(c,g,"namespace",C),o=s(c,g,"suffix",C),v=s(c,g,"external",Y),$=s(c,g,"sideEffects",Y),M=s(c,g,"pluginData",De),j=s(c,g,"errors",ye),G=s(c,g,"warnings",ye),L=s(c,g,"watchFiles",se),N=s(c,g,"watchDirs",se);Q(c,g,`from onResolve() callback in plugin ${Z(u)}`),l.id=_,E!=null&&(l.pluginName=E),D!=null&&(l.path=D),n!=null&&(l.namespace=n),o!=null&&(l.suffix=o),v!=null&&(l.external=v),$!=null&&(l.sideEffects=$),M!=null&&(l.pluginData=i.store(M)),j!=null&&(l.errors=be(j,"errors",i,u,void 0)),G!=null&&(l.warnings=be(G,"warnings",i,u,void 0)),L!=null&&(l.watchFiles=Ne(L,"watchFiles")),N!=null&&(l.watchDirs=Ne(N,"watchDirs"));break}}catch(c){l={id:_,errors:[je(c,m,i,y&&y(),u)]};break}r(w,l)}),p["on-load"]=(w,h)=>B(null,null,function*(){let l={},u="",d,y;for(let _ of h.ids)try{({name:u,callback:d,note:y}=V[_]);let c=yield d({path:h.path,namespace:h.namespace,suffix:h.suffix,pluginData:i.load(h.pluginData),with:h.with});if(c!=null){if(typeof c!="object")throw new Error(`Expected onLoad() callback in plugin ${Z(u)} to return an object`);let g={},E=s(c,g,"pluginName",C),D=s(c,g,"contents",et),n=s(c,g,"resolveDir",C),o=s(c,g,"pluginData",De),v=s(c,g,"loader",C),$=s(c,g,"errors",ye),M=s(c,g,"warnings",ye),j=s(c,g,"watchFiles",se),G=s(c,g,"watchDirs",se);Q(c,g,`from onLoad() callback in plugin ${Z(u)}`),l.id=_,E!=null&&(l.pluginName=E),D instanceof Uint8Array?l.contents=D:D!=null&&(l.contents=re(D)),n!=null&&(l.resolveDir=n),o!=null&&(l.pluginData=i.store(o)),v!=null&&(l.loader=v),$!=null&&(l.errors=be($,"errors",i,u,void 0)),M!=null&&(l.warnings=be(M,"warnings",i,u,void 0)),j!=null&&(l.watchFiles=Ne(j,"watchFiles")),G!=null&&(l.watchDirs=Ne(G,"watchDirs"));break}}catch(c){l={id:_,errors:[je(c,m,i,y&&y(),u)]};break}r(w,l)});let P=(w,h)=>h([],[]);k.length>0&&(P=(w,h)=>{B(null,null,function*(){let l=[],u=[];for(let{name:d,callback:y,note:_}of k){let c,g;try{let E=yield y(w);if(E!=null){if(typeof E!="object")throw new Error(`Expected onEnd() callback in plugin ${Z(d)} to return an object`);let D={},n=s(E,D,"errors",ye),o=s(E,D,"warnings",ye);Q(E,D,`from onEnd() callback in plugin ${Z(d)}`),n!=null&&(c=be(n,"errors",i,d,void 0)),o!=null&&(g=be(o,"warnings",i,d,void 0))}}catch(E){c=[je(E,m,i,_&&_(),d)]}if(c){l.push(...c);try{w.errors.push(...c)}catch{}}if(g){u.push(...g);try{w.warnings.push(...g)}catch{}}}h(l,u)})});let T=()=>{for(let w of I)setTimeout(()=>w(),0)};return H=!0,{ok:!0,requestPlugins:O,runOnEndCallbacks:P,scheduleOnDisposeCallbacks:T}});function rt(){let e=new Map,t=0;return{clear(){e.clear()},load(r){return e.get(r)},store(r){if(r===void 0)return-1;let a=t++;return e.set(a,r),a}}}function Me(e,t,r){let a,m=!1;return()=>{if(m)return a;m=!0;try{let p=(e.stack+"").split(`
`);p.splice(1,1);let f=st(t,p,r);if(f)return a={text:e.message,location:f},a}catch{}}}function je(e,t,r,a,m){let p="Internal error",f=null;try{p=(e&&e.message||e)+""}catch{}try{f=st(t,(e.stack+"").split(`
`),"")}catch{}return{id:"",pluginName:m,text:p,location:f,notes:a?[a]:[],detail:r?r.store(e):-1}}function st(e,t,r){let a="    at ";if(e.readFileSync&&!t[0].startsWith(a)&&t[1].startsWith(a))for(let m=1;m<t.length;m++){let p=t[m];if(p.startsWith(a))for(p=p.slice(a.length);;){let f=/^(?:new |async )?\S+ \((.*)\)$/.exec(p);if(f){p=f[1];continue}if(f=/^eval at \S+ \((.*)\)(?:, \S+:\d+:\d+)?$/.exec(p),f){p=f[1];continue}if(f=/^(\S+):(\d+):(\d+)$/.exec(p),f){let x;try{x=e.readFileSync(f[1],"utf8")}catch{break}let i=x.split(/\r\n|\r|\n|\u2028|\u2029/)[+f[2]-1]||"",b=+f[3]-1,k=i.slice(b,b+r.length)===r?r.length:0;return{file:f[1],namespace:"file",line:+f[2],column:re(i.slice(0,b)).length,length:re(i.slice(b,b+k)).length,lineText:i+`
`+t.slice(1).join(`
`),suggestion:""}}break}}return null}function Oe(e,t,r){let a=5;e+=t.length<1?"":` with ${t.length} error${t.length<2?"":"s"}:`+t.slice(0,a+1).map((p,f)=>{if(f===a)return`
...`;if(!p.location)return`
error: ${p.text}`;let{file:x,line:i,column:b}=p.location,k=p.pluginName?`[plugin: ${p.pluginName}] `:"";return`
${x}:${i}:${b}: ERROR: ${k}${p.text}`}).join("");let m=new Error(e);for(let[p,f]of[["errors",t],["warnings",r]])Object.defineProperty(m,p,{configurable:!0,enumerable:!0,get:()=>f,set:x=>Object.defineProperty(m,p,{configurable:!0,enumerable:!0,value:x})});return m}function Te(e,t){for(let r of e)r.detail=t.load(r.detail);return e}function it(e,t,r){if(e==null)return null;let a={},m=s(e,a,"file",C),p=s(e,a,"namespace",C),f=s(e,a,"line",_e),x=s(e,a,"column",_e),i=s(e,a,"length",_e),b=s(e,a,"lineText",C),k=s(e,a,"suggestion",C);if(Q(e,a,t),b){let S=b.slice(0,(x&&x>0?x:0)+(i&&i>0?i:0)+(r&&r>0?r:80));!/[\x7F-\uFFFF]/.test(S)&&!/\n/.test(b)&&(b=S)}return{file:m||"",namespace:p||"",line:f||0,column:x||0,length:i||0,lineText:b||"",suggestion:k||""}}function be(e,t,r,a,m){let p=[],f=0;for(let x of e){let i={},b=s(x,i,"id",C),k=s(x,i,"pluginName",C),S=s(x,i,"text",C),V=s(x,i,"location",Xe),I=s(x,i,"notes",ye),W=s(x,i,"detail",De),z=`in element ${f} of "${t}"`;Q(x,i,z);let O=[];if(I)for(let H of I){let P={},T=s(H,P,"text",C),w=s(H,P,"location",Xe);Q(H,P,z),O.push({text:T||"",location:it(w,z,m)})}p.push({id:b||"",pluginName:k||a,text:S||"",location:it(V,z,m),notes:O,detail:r?r.store(W):-1}),f++}return p}function Ne(e,t){let r=[];for(let a of e){if(typeof a!="string")throw new Error(`${Z(t)} must be an array of strings`);r.push(a)}return r}function xt(e,t){let r=Object.create(null);for(let a in e){let m=e[a];if(typeof m!="string")throw new Error(`key ${Z(a)} in object ${Z(t)} must be a string`);r[a]=m}return r}function kt({path:e,contents:t,hash:r}){let a=null;return{path:e,contents:t,hash:r,get text(){let m=this.contents;return(a===null||m!==t)&&(t=m,a=ce(m)),a}}}function Fe(e){let t=e.source;return e.flags&&(t=`(?${e.flags})${t}`),t}function Et(e){let t;try{t=ce(e)}catch{return ct(e)}return JSON.parse(t)}var _t="0.28.2",jt=e=>Ce().build(e),St=e=>Ce().context(e),$t=(e,t)=>Ce().transform(e,t),Tt=(e,t)=>Ce().formatMessages(e,t),Pt=(e,t)=>Ce().analyzeMetafile(e,t),Ot=()=>{throw new Error('The "buildSync" API only works in node')},Ct=()=>{throw new Error('The "transformSync" API only works in node')},At=()=>{throw new Error('The "formatMessagesSync" API only works in node')},Ut=()=>{throw new Error('The "analyzeMetafileSync" API only works in node')},Dt=()=>(Ve&&Ve(),Promise.resolve()),Se,Ve,Le,Ce=()=>{if(Le)return Le;throw Se?new Error('You need to wait for the promise returned from "initialize" to be resolved before calling this'):new Error('You need to call "initialize" before calling this')},Rt=e=>{e=pt(e||{});let t=e.wasmURL,r=e.wasmModule,a=e.worker!==!1;if(!t&&!r)throw new Error('Must provide either the "wasmURL" option or the "wasmModule" option');if(Se)throw new Error('Cannot call "initialize" more than once');return Se=It(t||"",r,a),Se.catch(()=>{Se=void 0}),Se},It=(e,t,r)=>B(null,null,function*(){let a,m,p=new Promise(S=>m=S);if(r){let S=new Blob([`onmessage=((postMessage) => {
      // Copyright 2018 The Go Authors. All rights reserved.
      // Use of this source code is governed by a BSD-style
      // license that can be found in the LICENSE file.
      var __async = (__this, __arguments, generator) => {
        return new Promise((resolve, reject) => {
          var fulfilled = (value) => {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          };
          var rejected = (value) => {
            try {
              step(generator.throw(value));
            } catch (e) {
              reject(e);
            }
          };
          var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
          step((generator = generator.apply(__this, __arguments)).next());
        });
      };
      let onmessage;
      let globalThis = {};
      for (let o = self; o; o = Object.getPrototypeOf(o))
        for (let k of Object.getOwnPropertyNames(o))
          if (!(k in globalThis))
            Object.defineProperty(globalThis, k, { get: () => self[k] });
      "use strict";
      (() => {
        const enosys = () => {
          const err = new Error("not implemented");
          err.code = "ENOSYS";
          return err;
        };
        if (!globalThis.fs) {
          let outputBuf = "";
          globalThis.fs = {
            constants: { O_WRONLY: -1, O_RDWR: -1, O_CREAT: -1, O_TRUNC: -1, O_APPEND: -1, O_EXCL: -1, O_DIRECTORY: -1 },
            // unused
            writeSync(fd, buf) {
              outputBuf += decoder.decode(buf);
              const nl = outputBuf.lastIndexOf("\\n");
              if (nl != -1) {
                console.log(outputBuf.substring(0, nl));
                outputBuf = outputBuf.substring(nl + 1);
              }
              return buf.length;
            },
            write(fd, buf, offset, length, position, callback) {
              if (offset !== 0 || length !== buf.length || position !== null) {
                callback(enosys());
                return;
              }
              const n = this.writeSync(fd, buf);
              callback(null, n);
            },
            chmod(path, mode, callback) {
              callback(enosys());
            },
            chown(path, uid, gid, callback) {
              callback(enosys());
            },
            close(fd, callback) {
              callback(enosys());
            },
            fchmod(fd, mode, callback) {
              callback(enosys());
            },
            fchown(fd, uid, gid, callback) {
              callback(enosys());
            },
            fstat(fd, callback) {
              callback(enosys());
            },
            fsync(fd, callback) {
              callback(null);
            },
            ftruncate(fd, length, callback) {
              callback(enosys());
            },
            lchown(path, uid, gid, callback) {
              callback(enosys());
            },
            link(path, link, callback) {
              callback(enosys());
            },
            lstat(path, callback) {
              callback(enosys());
            },
            mkdir(path, perm, callback) {
              callback(enosys());
            },
            open(path, flags, mode, callback) {
              callback(enosys());
            },
            read(fd, buffer, offset, length, position, callback) {
              callback(enosys());
            },
            readdir(path, callback) {
              callback(enosys());
            },
            readlink(path, callback) {
              callback(enosys());
            },
            rename(from, to, callback) {
              callback(enosys());
            },
            rmdir(path, callback) {
              callback(enosys());
            },
            stat(path, callback) {
              callback(enosys());
            },
            symlink(path, link, callback) {
              callback(enosys());
            },
            truncate(path, length, callback) {
              callback(enosys());
            },
            unlink(path, callback) {
              callback(enosys());
            },
            utimes(path, atime, mtime, callback) {
              callback(enosys());
            }
          };
        }
        if (!globalThis.process) {
          globalThis.process = {
            getuid() {
              return -1;
            },
            getgid() {
              return -1;
            },
            geteuid() {
              return -1;
            },
            getegid() {
              return -1;
            },
            getgroups() {
              throw enosys();
            },
            pid: -1,
            ppid: -1,
            umask() {
              throw enosys();
            },
            cwd() {
              throw enosys();
            },
            chdir() {
              throw enosys();
            }
          };
        }
        if (!globalThis.path) {
          globalThis.path = {
            resolve(...pathSegments) {
              return pathSegments.join("/");
            }
          };
        }
        if (!globalThis.crypto) {
          throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");
        }
        if (!globalThis.performance) {
          throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");
        }
        if (!globalThis.TextEncoder) {
          throw new Error("globalThis.TextEncoder is not available, polyfill required");
        }
        if (!globalThis.TextDecoder) {
          throw new Error("globalThis.TextDecoder is not available, polyfill required");
        }
        const encoder = new TextEncoder("utf-8");
        const decoder = new TextDecoder("utf-8");
        globalThis.Go = class {
          constructor() {
            this.argv = ["js"];
            this.env = {};
            this.exit = (code) => {
              if (code !== 0) {
                console.warn("exit code:", code);
              }
            };
            this._exitPromise = new Promise((resolve) => {
              this._resolveExitPromise = resolve;
            });
            this._pendingEvent = null;
            this._scheduledTimeouts = /* @__PURE__ */ new Map();
            this._nextCallbackTimeoutID = 1;
            const setInt64 = (addr, v) => {
              this.mem.setUint32(addr + 0, v, true);
              this.mem.setUint32(addr + 4, Math.floor(v / 4294967296), true);
            };
            const setInt32 = (addr, v) => {
              this.mem.setUint32(addr + 0, v, true);
            };
            const getInt64 = (addr) => {
              const low = this.mem.getUint32(addr + 0, true);
              const high = this.mem.getInt32(addr + 4, true);
              return low + high * 4294967296;
            };
            const loadValue = (addr) => {
              const f = this.mem.getFloat64(addr, true);
              if (f === 0) {
                return void 0;
              }
              if (!isNaN(f)) {
                return f;
              }
              const id = this.mem.getUint32(addr, true);
              return this._values[id];
            };
            const storeValue = (addr, v) => {
              const nanHead = 2146959360;
              if (typeof v === "number" && v !== 0) {
                if (isNaN(v)) {
                  this.mem.setUint32(addr + 4, nanHead, true);
                  this.mem.setUint32(addr, 0, true);
                  return;
                }
                this.mem.setFloat64(addr, v, true);
                return;
              }
              if (v === void 0) {
                this.mem.setFloat64(addr, 0, true);
                return;
              }
              let id = this._ids.get(v);
              if (id === void 0) {
                id = this._idPool.pop();
                if (id === void 0) {
                  id = this._values.length;
                }
                this._values[id] = v;
                this._goRefCounts[id] = 0;
                this._ids.set(v, id);
              }
              this._goRefCounts[id]++;
              let typeFlag = 0;
              switch (typeof v) {
                case "object":
                  if (v !== null) {
                    typeFlag = 1;
                  }
                  break;
                case "string":
                  typeFlag = 2;
                  break;
                case "symbol":
                  typeFlag = 3;
                  break;
                case "function":
                  typeFlag = 4;
                  break;
              }
              this.mem.setUint32(addr + 4, nanHead | typeFlag, true);
              this.mem.setUint32(addr, id, true);
            };
            const loadSlice = (addr) => {
              const array = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              return new Uint8Array(this._inst.exports.mem.buffer, array, len);
            };
            const loadSliceOfValues = (addr) => {
              const array = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              const a = new Array(len);
              for (let i = 0; i < len; i++) {
                a[i] = loadValue(array + i * 8);
              }
              return a;
            };
            const loadString = (addr) => {
              const saddr = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              return decoder.decode(new DataView(this._inst.exports.mem.buffer, saddr, len));
            };
            const testCallExport = (a, b) => {
              this._inst.exports.testExport0();
              return this._inst.exports.testExport(a, b);
            };
            const timeOrigin = Date.now() - performance.now();
            this.importObject = {
              _gotest: {
                add: (a, b) => a + b,
                callExport: testCallExport
              },
              gojs: {
                // Go's SP does not change as long as no Go code is running. Some operations (e.g. calls, getters and setters)
                // may synchronously trigger a Go event handler. This makes Go code get executed in the middle of the imported
                // function. A goroutine can switch to a new stack if the current stack is too small (see morestack function).
                // This changes the SP, thus we have to update the SP used by the imported function.
                // func wasmExit(code int32)
                "runtime.wasmExit": (sp) => {
                  sp >>>= 0;
                  const code = this.mem.getInt32(sp + 8, true);
                  this.exited = true;
                  delete this._inst;
                  delete this._values;
                  delete this._goRefCounts;
                  delete this._ids;
                  delete this._idPool;
                  this.exit(code);
                },
                // func wasmWrite(fd uintptr, p unsafe.Pointer, n int32)
                "runtime.wasmWrite": (sp) => {
                  sp >>>= 0;
                  const fd = getInt64(sp + 8);
                  const p = getInt64(sp + 16);
                  const n = this.mem.getInt32(sp + 24, true);
                  globalThis.fs.writeSync(fd, new Uint8Array(this._inst.exports.mem.buffer, p, n));
                },
                // func resetMemoryDataView()
                "runtime.resetMemoryDataView": (sp) => {
                  sp >>>= 0;
                  this.mem = new DataView(this._inst.exports.mem.buffer);
                },
                // func nanotime1() int64
                "runtime.nanotime1": (sp) => {
                  sp >>>= 0;
                  setInt64(sp + 8, (timeOrigin + performance.now()) * 1e6);
                },
                // func walltime() (sec int64, nsec int32)
                "runtime.walltime": (sp) => {
                  sp >>>= 0;
                  const msec = (/* @__PURE__ */ new Date()).getTime();
                  setInt64(sp + 8, msec / 1e3);
                  this.mem.setInt32(sp + 16, msec % 1e3 * 1e6, true);
                },
                // func scheduleTimeoutEvent(delay int64) int32
                "runtime.scheduleTimeoutEvent": (sp) => {
                  sp >>>= 0;
                  const id = this._nextCallbackTimeoutID;
                  this._nextCallbackTimeoutID++;
                  this._scheduledTimeouts.set(id, setTimeout(
                    () => {
                      this._resume();
                      while (this._scheduledTimeouts.has(id)) {
                        console.warn("scheduleTimeoutEvent: missed timeout event");
                        this._resume();
                      }
                    },
                    getInt64(sp + 8)
                  ));
                  this.mem.setInt32(sp + 16, id, true);
                },
                // func clearTimeoutEvent(id int32)
                "runtime.clearTimeoutEvent": (sp) => {
                  sp >>>= 0;
                  const id = this.mem.getInt32(sp + 8, true);
                  clearTimeout(this._scheduledTimeouts.get(id));
                  this._scheduledTimeouts.delete(id);
                },
                // func getRandomData(r []byte)
                "runtime.getRandomData": (sp) => {
                  sp >>>= 0;
                  crypto.getRandomValues(loadSlice(sp + 8));
                },
                // func finalizeRef(v ref)
                "syscall/js.finalizeRef": (sp) => {
                  sp >>>= 0;
                  const id = this.mem.getUint32(sp + 8, true);
                  this._goRefCounts[id]--;
                  if (this._goRefCounts[id] === 0) {
                    const v = this._values[id];
                    this._values[id] = null;
                    this._ids.delete(v);
                    this._idPool.push(id);
                  }
                },
                // func stringVal(value string) ref
                "syscall/js.stringVal": (sp) => {
                  sp >>>= 0;
                  storeValue(sp + 24, loadString(sp + 8));
                },
                // func valueGet(v ref, p string) ref
                "syscall/js.valueGet": (sp) => {
                  sp >>>= 0;
                  const result = Reflect.get(loadValue(sp + 8), loadString(sp + 16));
                  sp = this._inst.exports.getsp() >>> 0;
                  storeValue(sp + 32, result);
                },
                // func valueSet(v ref, p string, x ref)
                "syscall/js.valueSet": (sp) => {
                  sp >>>= 0;
                  Reflect.set(loadValue(sp + 8), loadString(sp + 16), loadValue(sp + 32));
                },
                // func valueDelete(v ref, p string)
                "syscall/js.valueDelete": (sp) => {
                  sp >>>= 0;
                  Reflect.deleteProperty(loadValue(sp + 8), loadString(sp + 16));
                },
                // func valueIndex(v ref, i int) ref
                "syscall/js.valueIndex": (sp) => {
                  sp >>>= 0;
                  storeValue(sp + 24, Reflect.get(loadValue(sp + 8), getInt64(sp + 16)));
                },
                // valueSetIndex(v ref, i int, x ref)
                "syscall/js.valueSetIndex": (sp) => {
                  sp >>>= 0;
                  Reflect.set(loadValue(sp + 8), getInt64(sp + 16), loadValue(sp + 24));
                },
                // func valueCall(v ref, m string, args []ref) (ref, bool)
                "syscall/js.valueCall": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const m = Reflect.get(v, loadString(sp + 16));
                    const args = loadSliceOfValues(sp + 32);
                    const result = Reflect.apply(m, v, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 56, result);
                    this.mem.setUint8(sp + 64, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 56, err);
                    this.mem.setUint8(sp + 64, 0);
                  }
                },
                // func valueInvoke(v ref, args []ref) (ref, bool)
                "syscall/js.valueInvoke": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const args = loadSliceOfValues(sp + 16);
                    const result = Reflect.apply(v, void 0, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, result);
                    this.mem.setUint8(sp + 48, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, err);
                    this.mem.setUint8(sp + 48, 0);
                  }
                },
                // func valueNew(v ref, args []ref) (ref, bool)
                "syscall/js.valueNew": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const args = loadSliceOfValues(sp + 16);
                    const result = Reflect.construct(v, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, result);
                    this.mem.setUint8(sp + 48, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, err);
                    this.mem.setUint8(sp + 48, 0);
                  }
                },
                // func valueLength(v ref) int
                "syscall/js.valueLength": (sp) => {
                  sp >>>= 0;
                  setInt64(sp + 16, parseInt(loadValue(sp + 8).length));
                },
                // valuePrepareString(v ref) (ref, int)
                "syscall/js.valuePrepareString": (sp) => {
                  sp >>>= 0;
                  const str = encoder.encode(String(loadValue(sp + 8)));
                  storeValue(sp + 16, str);
                  setInt64(sp + 24, str.length);
                },
                // valueLoadString(v ref, b []byte)
                "syscall/js.valueLoadString": (sp) => {
                  sp >>>= 0;
                  const str = loadValue(sp + 8);
                  loadSlice(sp + 16).set(str);
                },
                // func valueInstanceOf(v ref, t ref) bool
                "syscall/js.valueInstanceOf": (sp) => {
                  sp >>>= 0;
                  this.mem.setUint8(sp + 24, loadValue(sp + 8) instanceof loadValue(sp + 16) ? 1 : 0);
                },
                // func copyBytesToGo(dst []byte, src ref) (int, bool)
                "syscall/js.copyBytesToGo": (sp) => {
                  sp >>>= 0;
                  const dst = loadSlice(sp + 8);
                  const src = loadValue(sp + 32);
                  if (!(src instanceof Uint8Array || src instanceof Uint8ClampedArray)) {
                    this.mem.setUint8(sp + 48, 0);
                    return;
                  }
                  const toCopy = src.subarray(0, dst.length);
                  dst.set(toCopy);
                  setInt64(sp + 40, toCopy.length);
                  this.mem.setUint8(sp + 48, 1);
                },
                // func copyBytesToJS(dst ref, src []byte) (int, bool)
                "syscall/js.copyBytesToJS": (sp) => {
                  sp >>>= 0;
                  const dst = loadValue(sp + 8);
                  const src = loadSlice(sp + 16);
                  if (!(dst instanceof Uint8Array || dst instanceof Uint8ClampedArray)) {
                    this.mem.setUint8(sp + 48, 0);
                    return;
                  }
                  const toCopy = src.subarray(0, dst.length);
                  dst.set(toCopy);
                  setInt64(sp + 40, toCopy.length);
                  this.mem.setUint8(sp + 48, 1);
                },
                "debug": (value) => {
                  console.log(value);
                }
              }
            };
          }
          run(instance) {
            return __async(this, null, function* () {
              if (!(instance instanceof WebAssembly.Instance)) {
                throw new Error("Go.run: WebAssembly.Instance expected");
              }
              this._inst = instance;
              this.mem = new DataView(this._inst.exports.mem.buffer);
              this._values = [
                // JS values that Go currently has references to, indexed by reference id
                NaN,
                0,
                null,
                true,
                false,
                globalThis,
                this
              ];
              this._goRefCounts = new Array(this._values.length).fill(Infinity);
              this._ids = /* @__PURE__ */ new Map([
                // mapping from JS values to reference ids
                [0, 1],
                [null, 2],
                [true, 3],
                [false, 4],
                [globalThis, 5],
                [this, 6]
              ]);
              this._idPool = [];
              this.exited = false;
              let offset = 4096;
              const strPtr = (str) => {
                const ptr = offset;
                const bytes = encoder.encode(str + "\\0");
                new Uint8Array(this.mem.buffer, offset, bytes.length).set(bytes);
                offset += bytes.length;
                if (offset % 8 !== 0) {
                  offset += 8 - offset % 8;
                }
                return ptr;
              };
              const argc = this.argv.length;
              const argvPtrs = [];
              this.argv.forEach((arg) => {
                argvPtrs.push(strPtr(arg));
              });
              argvPtrs.push(0);
              const keys = Object.keys(this.env).sort();
              keys.forEach((key) => {
                argvPtrs.push(strPtr(\`\${key}=\${this.env[key]}\`));
              });
              argvPtrs.push(0);
              const argv = offset;
              argvPtrs.forEach((ptr) => {
                this.mem.setUint32(offset, ptr, true);
                this.mem.setUint32(offset + 4, 0, true);
                offset += 8;
              });
              const wasmMinDataAddr = 4096 + 8192;
              if (offset >= wasmMinDataAddr) {
                throw new Error("total length of command line and environment variables exceeds limit");
              }
              this._inst.exports.run(argc, argv);
              if (this.exited) {
                this._resolveExitPromise();
              }
              yield this._exitPromise;
            });
          }
          _resume() {
            if (this.exited) {
              throw new Error("Go program has already exited");
            }
            this._inst.exports.resume();
            if (this.exited) {
              this._resolveExitPromise();
            }
          }
          _makeFuncWrapper(id) {
            const go = this;
            return function() {
              const event = { id, this: this, args: arguments };
              go._pendingEvent = event;
              go._resume();
              return event.result;
            };
          }
        };
      })();
      onmessage = ({ data: wasm }) => {
        let decoder = new TextDecoder();
        let fs = globalThis.fs;
        let stderr = "";
        fs.writeSync = (fd, buffer) => {
          if (fd === 1) {
            postMessage(buffer);
          } else if (fd === 2) {
            stderr += decoder.decode(buffer);
            let parts = stderr.split("\\n");
            if (parts.length > 1) console.log(parts.slice(0, -1).join("\\n"));
            stderr = parts[parts.length - 1];
          } else {
            throw new Error("Bad write");
          }
          return buffer.length;
        };
        let stdin = [];
        let resumeStdin;
        let stdinPos = 0;
        onmessage = ({ data }) => {
          if (data.length > 0) {
            stdin.push(data);
            if (resumeStdin) resumeStdin();
          }
          return go;
        };
        fs.read = (fd, buffer, offset, length, position, callback) => {
          if (fd !== 0 || offset !== 0 || length !== buffer.length || position !== null) {
            throw new Error("Bad read");
          }
          if (stdin.length === 0) {
            resumeStdin = () => fs.read(fd, buffer, offset, length, position, callback);
            return;
          }
          let first = stdin[0];
          let count = Math.max(0, Math.min(length, first.length - stdinPos));
          buffer.set(first.subarray(stdinPos, stdinPos + count), offset);
          stdinPos += count;
          if (stdinPos === first.length) {
            stdin.shift();
            stdinPos = 0;
          }
          callback(null, count);
        };
        let go = new globalThis.Go();
        go.argv = ["", \`--service=\${"0.28.2"}\`];
        tryToInstantiateModule(wasm, go).then(
          (instance) => {
            postMessage(null);
            go.run(instance);
          },
          (error) => {
            postMessage(error);
          }
        );
        return go;
      };
      function tryToInstantiateModule(wasm, go) {
        return __async(this, null, function* () {
          if (wasm instanceof WebAssembly.Module) {
            return WebAssembly.instantiate(wasm, go.importObject);
          }
          const res = yield fetch(wasm);
          if (!res.ok) throw new Error(\`Failed to download \${JSON.stringify(wasm)}\`);
          if ("instantiateStreaming" in WebAssembly && /^application\\/wasm($|;)/i.test(res.headers.get("Content-Type") || "")) {
            const result2 = yield WebAssembly.instantiateStreaming(res, go.importObject);
            return result2.instance;
          }
          const bytes = yield res.arrayBuffer();
          const result = yield WebAssembly.instantiate(bytes, go.importObject);
          return result.instance;
        });
      }
      return (m) => onmessage(m);
    })(postMessage)`],{type:"text/javascript"});a=new Worker(URL.createObjectURL(S))}else{let S=(I=>{var W=(P,T,w)=>new Promise((h,l)=>{var u=_=>{try{y(w.next(_))}catch(c){l(c)}},d=_=>{try{y(w.throw(_))}catch(c){l(c)}},y=_=>_.done?h(_.value):Promise.resolve(_.value).then(u,d);y((w=w.apply(P,T)).next())});let z,O={};for(let P=self;P;P=Object.getPrototypeOf(P))for(let T of Object.getOwnPropertyNames(P))T in O||Object.defineProperty(O,T,{get:()=>self[T]});(()=>{let P=()=>{let h=new Error("not implemented");return h.code="ENOSYS",h};if(!O.fs){let h="";O.fs={constants:{O_WRONLY:-1,O_RDWR:-1,O_CREAT:-1,O_TRUNC:-1,O_APPEND:-1,O_EXCL:-1,O_DIRECTORY:-1},writeSync(l,u){h+=w.decode(u);let d=h.lastIndexOf(`
`);return d!=-1&&(console.log(h.substring(0,d)),h=h.substring(d+1)),u.length},write(l,u,d,y,_,c){if(d!==0||y!==u.length||_!==null){c(P());return}let g=this.writeSync(l,u);c(null,g)},chmod(l,u,d){d(P())},chown(l,u,d,y){y(P())},close(l,u){u(P())},fchmod(l,u,d){d(P())},fchown(l,u,d,y){y(P())},fstat(l,u){u(P())},fsync(l,u){u(null)},ftruncate(l,u,d){d(P())},lchown(l,u,d,y){y(P())},link(l,u,d){d(P())},lstat(l,u){u(P())},mkdir(l,u,d){d(P())},open(l,u,d,y){y(P())},read(l,u,d,y,_,c){c(P())},readdir(l,u){u(P())},readlink(l,u){u(P())},rename(l,u,d){d(P())},rmdir(l,u){u(P())},stat(l,u){u(P())},symlink(l,u,d){d(P())},truncate(l,u,d){d(P())},unlink(l,u){u(P())},utimes(l,u,d,y){y(P())}}}if(O.process||(O.process={getuid(){return-1},getgid(){return-1},geteuid(){return-1},getegid(){return-1},getgroups(){throw P()},pid:-1,ppid:-1,umask(){throw P()},cwd(){throw P()},chdir(){throw P()}}),O.path||(O.path={resolve(...h){return h.join("/")}}),!O.crypto)throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");if(!O.performance)throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");if(!O.TextEncoder)throw new Error("globalThis.TextEncoder is not available, polyfill required");if(!O.TextDecoder)throw new Error("globalThis.TextDecoder is not available, polyfill required");let T=new TextEncoder("utf-8"),w=new TextDecoder("utf-8");O.Go=class{constructor(){this.argv=["js"],this.env={},this.exit=n=>{n!==0&&console.warn("exit code:",n)},this._exitPromise=new Promise(n=>{this._resolveExitPromise=n}),this._pendingEvent=null,this._scheduledTimeouts=new Map,this._nextCallbackTimeoutID=1;let h=(n,o)=>{this.mem.setUint32(n+0,o,!0),this.mem.setUint32(n+4,Math.floor(o/4294967296),!0)},l=(n,o)=>{this.mem.setUint32(n+0,o,!0)},u=n=>{let o=this.mem.getUint32(n+0,!0),v=this.mem.getInt32(n+4,!0);return o+v*4294967296},d=n=>{let o=this.mem.getFloat64(n,!0);if(o===0)return;if(!isNaN(o))return o;let v=this.mem.getUint32(n,!0);return this._values[v]},y=(n,o)=>{if(typeof o=="number"&&o!==0){if(isNaN(o)){this.mem.setUint32(n+4,2146959360,!0),this.mem.setUint32(n,0,!0);return}this.mem.setFloat64(n,o,!0);return}if(o===void 0){this.mem.setFloat64(n,0,!0);return}let $=this._ids.get(o);$===void 0&&($=this._idPool.pop(),$===void 0&&($=this._values.length),this._values[$]=o,this._goRefCounts[$]=0,this._ids.set(o,$)),this._goRefCounts[$]++;let M=0;switch(typeof o){case"object":o!==null&&(M=1);break;case"string":M=2;break;case"symbol":M=3;break;case"function":M=4;break}this.mem.setUint32(n+4,2146959360|M,!0),this.mem.setUint32(n,$,!0)},_=n=>{let o=u(n+0),v=u(n+8);return new Uint8Array(this._inst.exports.mem.buffer,o,v)},c=n=>{let o=u(n+0),v=u(n+8),$=new Array(v);for(let M=0;M<v;M++)$[M]=d(o+M*8);return $},g=n=>{let o=u(n+0),v=u(n+8);return w.decode(new DataView(this._inst.exports.mem.buffer,o,v))},E=(n,o)=>(this._inst.exports.testExport0(),this._inst.exports.testExport(n,o)),D=Date.now()-performance.now();this.importObject={_gotest:{add:(n,o)=>n+o,callExport:E},gojs:{"runtime.wasmExit":n=>{n>>>=0;let o=this.mem.getInt32(n+8,!0);this.exited=!0,delete this._inst,delete this._values,delete this._goRefCounts,delete this._ids,delete this._idPool,this.exit(o)},"runtime.wasmWrite":n=>{n>>>=0;let o=u(n+8),v=u(n+16),$=this.mem.getInt32(n+24,!0);O.fs.writeSync(o,new Uint8Array(this._inst.exports.mem.buffer,v,$))},"runtime.resetMemoryDataView":n=>{n>>>=0,this.mem=new DataView(this._inst.exports.mem.buffer)},"runtime.nanotime1":n=>{n>>>=0,h(n+8,(D+performance.now())*1e6)},"runtime.walltime":n=>{n>>>=0;let o=new Date().getTime();h(n+8,o/1e3),this.mem.setInt32(n+16,o%1e3*1e6,!0)},"runtime.scheduleTimeoutEvent":n=>{n>>>=0;let o=this._nextCallbackTimeoutID;this._nextCallbackTimeoutID++,this._scheduledTimeouts.set(o,setTimeout(()=>{for(this._resume();this._scheduledTimeouts.has(o);)console.warn("scheduleTimeoutEvent: missed timeout event"),this._resume()},u(n+8))),this.mem.setInt32(n+16,o,!0)},"runtime.clearTimeoutEvent":n=>{n>>>=0;let o=this.mem.getInt32(n+8,!0);clearTimeout(this._scheduledTimeouts.get(o)),this._scheduledTimeouts.delete(o)},"runtime.getRandomData":n=>{n>>>=0,crypto.getRandomValues(_(n+8))},"syscall/js.finalizeRef":n=>{n>>>=0;let o=this.mem.getUint32(n+8,!0);if(this._goRefCounts[o]--,this._goRefCounts[o]===0){let v=this._values[o];this._values[o]=null,this._ids.delete(v),this._idPool.push(o)}},"syscall/js.stringVal":n=>{n>>>=0,y(n+24,g(n+8))},"syscall/js.valueGet":n=>{n>>>=0;let o=Reflect.get(d(n+8),g(n+16));n=this._inst.exports.getsp()>>>0,y(n+32,o)},"syscall/js.valueSet":n=>{n>>>=0,Reflect.set(d(n+8),g(n+16),d(n+32))},"syscall/js.valueDelete":n=>{n>>>=0,Reflect.deleteProperty(d(n+8),g(n+16))},"syscall/js.valueIndex":n=>{n>>>=0,y(n+24,Reflect.get(d(n+8),u(n+16)))},"syscall/js.valueSetIndex":n=>{n>>>=0,Reflect.set(d(n+8),u(n+16),d(n+24))},"syscall/js.valueCall":n=>{n>>>=0;try{let o=d(n+8),v=Reflect.get(o,g(n+16)),$=c(n+32),M=Reflect.apply(v,o,$);n=this._inst.exports.getsp()>>>0,y(n+56,M),this.mem.setUint8(n+64,1)}catch(o){n=this._inst.exports.getsp()>>>0,y(n+56,o),this.mem.setUint8(n+64,0)}},"syscall/js.valueInvoke":n=>{n>>>=0;try{let o=d(n+8),v=c(n+16),$=Reflect.apply(o,void 0,v);n=this._inst.exports.getsp()>>>0,y(n+40,$),this.mem.setUint8(n+48,1)}catch(o){n=this._inst.exports.getsp()>>>0,y(n+40,o),this.mem.setUint8(n+48,0)}},"syscall/js.valueNew":n=>{n>>>=0;try{let o=d(n+8),v=c(n+16),$=Reflect.construct(o,v);n=this._inst.exports.getsp()>>>0,y(n+40,$),this.mem.setUint8(n+48,1)}catch(o){n=this._inst.exports.getsp()>>>0,y(n+40,o),this.mem.setUint8(n+48,0)}},"syscall/js.valueLength":n=>{n>>>=0,h(n+16,parseInt(d(n+8).length))},"syscall/js.valuePrepareString":n=>{n>>>=0;let o=T.encode(String(d(n+8)));y(n+16,o),h(n+24,o.length)},"syscall/js.valueLoadString":n=>{n>>>=0;let o=d(n+8);_(n+16).set(o)},"syscall/js.valueInstanceOf":n=>{n>>>=0,this.mem.setUint8(n+24,d(n+8)instanceof d(n+16)?1:0)},"syscall/js.copyBytesToGo":n=>{n>>>=0;let o=_(n+8),v=d(n+32);if(!(v instanceof Uint8Array||v instanceof Uint8ClampedArray)){this.mem.setUint8(n+48,0);return}let $=v.subarray(0,o.length);o.set($),h(n+40,$.length),this.mem.setUint8(n+48,1)},"syscall/js.copyBytesToJS":n=>{n>>>=0;let o=d(n+8),v=_(n+16);if(!(o instanceof Uint8Array||o instanceof Uint8ClampedArray)){this.mem.setUint8(n+48,0);return}let $=v.subarray(0,o.length);o.set($),h(n+40,$.length),this.mem.setUint8(n+48,1)},debug:n=>{console.log(n)}}}}run(h){return W(this,null,function*(){if(!(h instanceof WebAssembly.Instance))throw new Error("Go.run: WebAssembly.Instance expected");this._inst=h,this.mem=new DataView(this._inst.exports.mem.buffer),this._values=[NaN,0,null,!0,!1,O,this],this._goRefCounts=new Array(this._values.length).fill(1/0),this._ids=new Map([[0,1],[null,2],[!0,3],[!1,4],[O,5],[this,6]]),this._idPool=[],this.exited=!1;let l=4096,u=E=>{let D=l,n=T.encode(E+"\0");return new Uint8Array(this.mem.buffer,l,n.length).set(n),l+=n.length,l%8!==0&&(l+=8-l%8),D},d=this.argv.length,y=[];this.argv.forEach(E=>{y.push(u(E))}),y.push(0),Object.keys(this.env).sort().forEach(E=>{y.push(u(`${E}=${this.env[E]}`))}),y.push(0);let c=l;if(y.forEach(E=>{this.mem.setUint32(l,E,!0),this.mem.setUint32(l+4,0,!0),l+=8}),l>=12288)throw new Error("total length of command line and environment variables exceeds limit");this._inst.exports.run(d,c),this.exited&&this._resolveExitPromise(),yield this._exitPromise})}_resume(){if(this.exited)throw new Error("Go program has already exited");this._inst.exports.resume(),this.exited&&this._resolveExitPromise()}_makeFuncWrapper(h){let l=this;return function(){let u={id:h,this:this,args:arguments};return l._pendingEvent=u,l._resume(),u.result}}}})(),z=({data:P})=>{let T=new TextDecoder,w=O.fs,h="";w.writeSync=(_,c)=>{if(_===1)I(c);else if(_===2){h+=T.decode(c);let g=h.split(`
`);g.length>1&&console.log(g.slice(0,-1).join(`
`)),h=g[g.length-1]}else throw new Error("Bad write");return c.length};let l=[],u,d=0;z=({data:_})=>(_.length>0&&(l.push(_),u&&u()),y),w.read=(_,c,g,E,D,n)=>{if(_!==0||g!==0||E!==c.length||D!==null)throw new Error("Bad read");if(l.length===0){u=()=>w.read(_,c,g,E,D,n);return}let o=l[0],v=Math.max(0,Math.min(E,o.length-d));c.set(o.subarray(d,d+v),g),d+=v,d===o.length&&(l.shift(),d=0),n(null,v)};let y=new O.Go;return y.argv=["","--service=0.28.2"],H(P,y).then(_=>{I(null),y.run(_)},_=>{I(_)}),y};function H(P,T){return W(this,null,function*(){if(P instanceof WebAssembly.Module)return WebAssembly.instantiate(P,T.importObject);let w=yield fetch(P);if(!w.ok)throw new Error(`Failed to download ${JSON.stringify(P)}`);if("instantiateStreaming"in WebAssembly&&/^application\/wasm($|;)/i.test(w.headers.get("Content-Type")||""))return(yield WebAssembly.instantiateStreaming(w,T.importObject)).instance;let h=yield w.arrayBuffer();return(yield WebAssembly.instantiate(h,T.importObject)).instance})}return P=>z(P)})(I=>a.onmessage({data:I})),V;a={onmessage:null,postMessage:I=>setTimeout(()=>{try{V=S({data:I})}catch(W){m(W)}}),terminate(){if(V)for(let I of V._scheduledTimeouts.values())clearTimeout(I)}}}let f,x,i=new Promise((S,V)=>{f=S,x=V});a.onmessage=({data:S})=>{a.onmessage=({data:V})=>b(V),S?x(S):f()},a.postMessage(t||new URL(e,location.href).toString());let{readFromStdout:b,service:k}=yt({writeToStdin(S){a.postMessage(S)},isSync:!1,hasFS:!1,esbuild:te});yield i,Ve=()=>{a.terminate(),Se=void 0,Ve=void 0,Le=void 0},Le={build:S=>new Promise((V,I)=>{p.then(I),k.buildOrContext({callName:"build",refs:null,options:S,isTTY:!1,defaultWD:"/",callback:(W,z)=>W?I(W):V(z)})}),context:S=>new Promise((V,I)=>{p.then(I),k.buildOrContext({callName:"context",refs:null,options:S,isTTY:!1,defaultWD:"/",callback:(W,z)=>W?I(W):V(z)})}),transform:(S,V)=>new Promise((I,W)=>{p.then(W),k.transform({callName:"transform",refs:null,input:S,options:V||{},isTTY:!1,fs:{readFile(z,O){O(new Error("Internal error"),null)},writeFile(z,O){O(null)}},callback:(z,O)=>z?W(z):I(O)})}),formatMessages:(S,V)=>new Promise((I,W)=>{p.then(W),k.formatMessages({callName:"formatMessages",refs:null,messages:S,options:V,callback:(z,O)=>z?W(z):I(O)})}),analyzeMetafile:(S,V)=>new Promise((I,W)=>{p.then(W),k.analyzeMetafile({callName:"analyzeMetafile",refs:null,metafile:typeof S=="string"?S:JSON.stringify(S),options:V,callback:(z,O)=>z?W(z):I(O)})})}}),Mt=te})(typeof ze=="object"?ze:{set exports(U){(typeof self<"u"?self:this).esbuild=U}})});var qe=qt(ot(),1);var Yt=new TextDecoder;function Ee(U){let R=[];for(let q of U.split("/"))if(!(!q||q==="."))if(q===".."){if(!R.length)throw new Error("Import escapes its source root");R.pop()}else R.push(q);return R.join("/")}var Ge=U=>U.split("/").slice(0,-1).join("/"),Ht=["",".tsx",".ts",".jsx",".js",".mjs",".cjs",".json",".css","/index.tsx","/index.ts","/index.js"];function Be(U,R,q){if(typeof U=="string")return U.replaceAll("*",R??"");if(Array.isArray(U))for(let ee of U){let J=Be(ee,R,q);if(J)return J}else if(U&&typeof U=="object"){for(let[ee,J]of Object.entries(U))if(q.has(ee))return Be(J,R,q)}return null}function Qt(U,R="",q="import"){let ee=new Set(["browser",q,"default","production"]);if(U.exports!==void 0){let J=R?`./${R}`:".",K=U.exports;if(K&&typeof K=="object"&&!Array.isArray(K)&&Object.keys(K).some(F=>F.startsWith(".")))if(Object.hasOwn(K,J))K=K[J];else{let F=Object.keys(K).filter(oe=>oe.includes("*")).sort((oe,pe)=>pe.length-oe.length).find(oe=>{let[pe,re]=oe.split("*");return J.startsWith(pe)&&J.endsWith(re)});if(!F)throw new Error(`Package does not export ${J}`);let[B,te]=F.split("*"),he=Be(K[F],J.slice(B.length,J.length-te.length),ee);if(!he?.startsWith("./"))throw new Error(`Unsupported package export: ${J}`);return Ee(he)}else if(R)throw new Error(`Package does not export ${J}`);let ne=Be(K,void 0,ee);if(!ne?.startsWith("./"))throw new Error(`Unsupported package export: ${J}`);return Ee(ne)}return Ee(R||typeof U.browser=="string"&&U.browser||U.module||U.main||"index.js")}function Xt(U,R,q){let ee=new Map,J=async(ne,F)=>{if(ne==="project")return q(F);let B=F.indexOf("/");return R[F.slice(0,B)]?.get(F.slice(B+1))},K=async(ne,F)=>{for(let B of Ht)try{let te=await J(ne,F+B);if(te!==void 0)return ee.set(`${ne}:${F+B}`,te),{path:F+B,namespace:ne}}catch(te){if(ne!=="project")throw te}throw new Error(`Cannot resolve ${F}`)};return{name:"webfront-project",setup(ne){ne.onResolve({filter:/.*/},async F=>{if(F.kind==="entry-point")return K("project",Ee(F.path));let B=F.path,te=F.namespace==="npm"?U.packages[F.importer.split("/")[0]]:null,he=te?.manifest.browser;if(he&&typeof he=="object"){let ce=B.startsWith(".")?"./"+Ee(Ge(F.importer.split("/").slice(1).join("/"))+"/"+B):B,me=he[ce];if(me===!1)return{path:B,namespace:"empty"};if(typeof me=="string"){if(me.startsWith("."))return K("npm",`${F.importer.split("/")[0]}/${Ee(me)}`);B=me}}if(B.startsWith(".")){if(F.namespace==="npm"){let ce=F.importer.indexOf("/"),me=F.importer.slice(0,ce),Ue=Ee(Ge(F.importer.slice(ce+1))+"/"+B);return K("npm",`${me}/${Ue}`)}return K("project",Ee(Ge(F.importer)+"/"+B))}if(/^(?:[a-z]+:|\/|#)/i.test(B))throw new Error(`Unsupported browser import: ${B}`);let oe=B.split("/"),pe=oe.splice(0,B.startsWith("@")?2:1).join("/"),re=(te?.name===pe?F.importer.split("/")[0]:te?.dependencies[pe])??(!te&&U.roots[pe]?.id);if(!re)throw new Error(`Uninstalled browser dependency: ${B}`);return K("npm",`${re}/${Qt(U.packages[re].manifest,oe.join("/"),F.kind.startsWith("require")?"require":"import")}`)}),ne.onLoad({filter:/.*/,namespace:"empty"},()=>({contents:"",loader:"js"}));for(let F of["project","npm"])ne.onLoad({filter:/.*/,namespace:F},async B=>{let te=ee.get(`${F}:${B.path}`)??await J(F,B.path),he=B.path.split(".").pop(),oe={mjs:"js",cjs:"js",js:"js",jsx:"jsx",ts:"ts",tsx:"tsx",css:"css",json:"json"}[he];return{contents:oe?Yt.decode(te):te,loader:oe??"file"}})}}}async function at(U,{entry:R,lock:q,packages:ee,readProject:J}){let K=await U.build({entryPoints:[R],bundle:!0,write:!1,outdir:"/output",entryNames:"app",assetNames:"assets/[name]-[hash]",format:"esm",platform:"browser",target:"es2020",jsx:"automatic",minify:!0,define:{"process.env.NODE_ENV":'"production"'},legalComments:"inline",plugins:[Xt(q,ee,J)]});return new Map(K.outputFiles.map(ne=>[ne.path.replace(/^\/output\//,""),ne.contents]))}var Je=new Map,Kt=0,Zt=U=>new Promise((R,q)=>{let ee=++Kt;Je.set(ee,{resolve:R,reject:q}),self.postMessage({type:"read",id:ee,path:U})}),en=qe.initialize({wasmURL:new URL("./esbuild.wasm",import.meta.url).href,worker:!1});self.onmessage=async({data:U})=>{if(U.type==="read-result"){let R=Je.get(U.id);if(!R)return;Je.delete(U.id),U.error?R.reject(new Error(U.error)):R.resolve(U.bytes);return}if(U.type==="build")try{await en;let R=await at(qe,{...U,readProject:Zt});self.postMessage({type:"result",files:R})}catch(R){self.postMessage({type:"error",error:R.message})}};
