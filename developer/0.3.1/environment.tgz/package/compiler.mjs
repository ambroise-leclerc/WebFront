var Jt=Object.create;var ct=Object.defineProperty;var qt=Object.getOwnPropertyDescriptor;var Yt=Object.getOwnPropertyNames;var Ht=Object.getPrototypeOf,Qt=Object.prototype.hasOwnProperty;var Xt=(c,p)=>()=>{try{return p||c((p={exports:{}}).exports,p),p.exports}catch(U){throw p=0,U}};var Kt=(c,p,U,M)=>{if(p&&typeof p=="object"||typeof p=="function")for(let N of Yt(p))!Qt.call(c,N)&&N!==U&&ct(c,N,{get:()=>p[N],enumerable:!(M=qt(p,N))||M.enumerable});return c};var Zt=(c,p,U)=>(U=c!=null?Jt(Ht(c)):{},Kt(p||!c||!c.__esModule?ct(U,"default",{value:c,enumerable:!0}):U,c));var ut=Xt((_n,We)=>{(c=>{"use strict";var p=Object.defineProperty,U=Object.getOwnPropertyDescriptor,M=Object.getOwnPropertyNames,N=Object.prototype.hasOwnProperty,Y=(e,t)=>{for(var r in t)p(e,r,{get:t[r],enumerable:!0})},te=(e,t,r,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let g of M(t))!N.call(e,g)&&g!==r&&p(e,g,{get:()=>t[g],enumerable:!(a=U(t,g))||a.enumerable});return e},ee=e=>te(p({},"__esModule",{value:!0}),e),Q=(e,t,r)=>new Promise((a,g)=>{var w=i=>{try{E(r.next(i))}catch(x){g(x)}},d=i=>{try{E(r.throw(i))}catch(x){g(x)}},E=i=>i.done?a(i.value):Promise.resolve(i.value).then(w,d);E((r=r.apply(e,t)).next())}),ye={};Y(ye,{analyzeMetafile:()=>Rt,analyzeMetafileSync:()=>Ft,build:()=>Ct,buildSync:()=>It,context:()=>At,default:()=>Wt,formatMessages:()=>Dt,formatMessagesSync:()=>Nt,initialize:()=>Lt,stop:()=>Vt,transform:()=>Ut,transformSync:()=>Mt,version:()=>Ot}),c.exports=ee(ye);function $e(e){let t=a=>{if(a===null)r.write8(0);else if(typeof a=="boolean")r.write8(1),r.write8(+a);else if(typeof a=="number")r.write8(2),r.write32(a|0);else if(typeof a=="string")r.write8(3),r.write(ce(a));else if(a instanceof Uint8Array)r.write8(4),r.write(a);else if(a instanceof Array){r.write8(5),r.write32(a.length);for(let g of a)t(g)}else{let g=Object.keys(a);r.write8(6),r.write32(g.length);for(let w of g)r.write(ce(w)),t(a[w])}},r=new He;return r.write32(0),r.write32(e.id<<1|+!e.isRequest),t(e.value),Be(r.buf,r.len-4,0),r.buf.subarray(0,r.len)}function mt(e){let t=()=>{switch(r.read8()){case 0:return null;case 1:return!!r.read8();case 2:return r.read32();case 3:return be(r.read());case 4:return r.read();case 5:{let d=r.read32(),E=[];for(let i=0;i<d;i++)E.push(t());return E}case 6:{let d=r.read32(),E={};for(let i=0;i<d;i++)E[be(r.read())]=t();return E}default:throw new Error("Invalid packet")}},r=new He(e),a=r.read32(),g=(a&1)===0;a>>>=1;let w=t();if(r.ptr!==e.length)throw new Error("Invalid packet");return{id:a,isRequest:g,value:w}}var He=class{constructor(e=new Uint8Array(1024)){this.buf=e,this.len=0,this.ptr=0}_write(e){if(this.len+e>this.buf.length){let t=new Uint8Array((this.len+e)*2);t.set(this.buf),this.buf=t}return this.len+=e,this.len-e}write8(e){let t=this._write(1);this.buf[t]=e}write32(e){let t=this._write(4);Be(this.buf,e,t)}write(e){let t=this._write(4+e.length);Be(this.buf,e.length,t),this.buf.set(e,t+4)}_read(e){if(this.ptr+e>this.buf.length)throw new Error("Invalid packet");return this.ptr+=e,this.ptr-e}read8(){return this.buf[this._read(1)]}read32(){return Qe(this.buf,this._read(4))}read(){let e=this.read32(),t=new Uint8Array(e),r=this._read(t.length);return t.set(this.buf.subarray(r,r+e)),t}},ce,be,Le;if(typeof TextEncoder<"u"&&typeof TextDecoder<"u"){let e=new TextEncoder,t=new TextDecoder;ce=r=>e.encode(r),be=r=>t.decode(r),Le='new TextEncoder().encode("")'}else if(typeof Buffer<"u")ce=e=>Buffer.from(e),be=e=>{let{buffer:t,byteOffset:r,byteLength:a}=e;return Buffer.from(t,r,a).toString()},Le='Buffer.from("")';else throw new Error("No UTF-8 codec found");if(!(ce("")instanceof Uint8Array))throw new Error(`Invariant violation: "${Le} instanceof Uint8Array" is incorrectly false

This indicates that your JavaScript environment is broken. You cannot use
esbuild in this environment because esbuild relies on this invariant. This
is not a problem with esbuild. You need to fix your environment instead.
`);function Qe(e,t){return(e[t++]|e[t++]<<8|e[t++]<<16|e[t++]<<24)>>>0}function Be(e,t,r){e[r++]=t,e[r++]=t>>8,e[r++]=t>>16,e[r++]=t>>24}var fe=String.fromCharCode;function le(e,t,r){let a=e[t],g=1,w=0;for(let d=0;d<t;d++)e[d]===10?(g++,w=0):w++;throw new SyntaxError(r||(t===e.length?"Unexpected end of input while parsing JSON":a>=32&&a<=126?`Unexpected character ${fe(a)} in JSON at position ${t} (line ${g}, column ${w})`:`Unexpected byte 0x${a.toString(16)} in JSON at position ${t} (line ${g}, column ${w})`))}function pt(e){if(!(e instanceof Uint8Array))throw new Error("JSON input must be a Uint8Array");let t=[],r=[],a=[],g=e.length,w=null,d=0,E,i=0;for(;i<g;){let x=e[i++];if(x<=32)continue;let _;switch(d===2&&w===null&&x!==34&&x!==125&&le(e,--i),x){case 116:{(e[i++]!==114||e[i++]!==117||e[i++]!==101)&&le(e,--i),_=!0;break}case 102:{(e[i++]!==97||e[i++]!==108||e[i++]!==115||e[i++]!==101)&&le(e,--i),_=!1;break}case 110:{(e[i++]!==117||e[i++]!==108||e[i++]!==108)&&le(e,--i),_=null;break}case 45:case 46:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:{let P=i;for(_=fe(x),x=e[i];;){switch(x){case 43:case 45:case 46:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:case 101:case 69:{_+=fe(x),x=e[++i];continue}}break}_=+_,isNaN(_)&&le(e,--P,"Invalid number");break}case 34:{for(_="";i>=g&&le(e,g),x=e[i++],x!==34;)if(x===92)switch(e[i++]){case 34:_+='"';break;case 47:_+="/";break;case 92:_+="\\";break;case 98:_+="\b";break;case 102:_+="\f";break;case 110:_+=`
`;break;case 114:_+="\r";break;case 116:_+="	";break;case 117:{let P=0;for(let B=0;B<4;B++)x=e[i++],P<<=4,x>=48&&x<=57?P|=x-48:x>=97&&x<=102?P|=x+-87:x>=65&&x<=70?P|=x+-55:le(e,--i);_+=fe(P);break}default:le(e,--i);break}else if(x<=127)_+=fe(x);else if((x&224)===192)_+=fe((x&31)<<6|e[i++]&63);else if((x&240)===224)_+=fe((x&15)<<12|(e[i++]&63)<<6|e[i++]&63);else if((x&248)==240){let P=(x&7)<<18|(e[i++]&63)<<12|(e[i++]&63)<<6|e[i++]&63;P>65535&&(P-=65536,_+=fe(P>>10&1023|55296),P=56320|P&1023),_+=fe(P)}_[0];break}case 91:{_=[],t.push(w),r.push(E),a.push(d),w=null,E=_,d=1;continue}case 123:{_={},t.push(w),r.push(E),a.push(d),w=null,E=_,d=2;continue}case 93:{d!==1&&le(e,--i),_=E,w=t.pop(),E=r.pop(),d=a.pop();break}case 125:{d!==2&&le(e,--i),_=E,w=t.pop(),E=r.pop(),d=a.pop();break}default:le(e,--i)}for(x=e[i];x<=32;)x=e[++i];switch(d){case 0:{if(i===g)return _;break}case 1:{if(E.push(_),x===44){i++;continue}if(x===93)continue;break}case 2:{if(w===null){if(w=_,x===58){i++;continue}}else{if(E[w]=_,w=null,x===44){i++;continue}if(x===125)continue}break}}break}le(e,i)}var Z=JSON.stringify,Xe="warning",Ke="silent";function Ee(e,t){let r=[];for(let a of e){if(re(a,t),a.indexOf(",")>=0)throw new Error(`Invalid ${t}: ${a}`);r.push(a)}return r.join(",")}var Ae=()=>null,q=e=>typeof e=="boolean"?null:"a boolean",D=e=>typeof e=="string"?null:"a string",Ue=e=>e instanceof RegExp?null:"a RegExp object",ve=e=>typeof e=="number"&&e===(e|0)?null:"an integer",gt=e=>typeof e=="number"&&e===(e|0)&&e>=0&&e<=65535?null:"a valid port number",Ze=e=>typeof e=="function"?null:"a function",de=e=>Array.isArray(e)?null:"an array",ne=e=>Array.isArray(e)&&e.every(t=>typeof t=="string")?null:"an array of strings",ie=e=>typeof e=="object"&&e!==null&&!Array.isArray(e)?null:"an object",wt=e=>typeof e=="object"&&e!==null?null:"an array or an object",yt=e=>e instanceof WebAssembly.Module?null:"a WebAssembly.Module",et=e=>typeof e=="object"&&!Array.isArray(e)?null:"an object or null",tt=e=>typeof e=="string"||typeof e=="boolean"?null:"a string or a boolean",bt=e=>typeof e=="string"||typeof e=="object"&&e!==null&&!Array.isArray(e)?null:"a string or an object",nt=e=>typeof e=="string"||Array.isArray(e)&&e.every(t=>typeof t=="string")?null:"a string or an array of strings",rt=e=>typeof e=="string"||e instanceof Uint8Array?null:"a string or a Uint8Array",vt=e=>typeof e=="string"||e instanceof URL?null:"a string or a URL";function s(e,t,r,a){let g=e[r];if(t[r+""]=!0,g===void 0)return;let w=a(g);if(w!==null)throw new Error(`${Z(r)} must be ${w}`);return g}function X(e,t,r){for(let a in e)if(!(a in t))throw new Error(`Invalid option ${r}: ${Z(a)}`)}function xt(e){let t=Object.create(null),r=s(e,t,"wasmURL",vt),a=s(e,t,"wasmModule",yt),g=s(e,t,"worker",q);return X(e,t,"in initialize() call"),{wasmURL:r,wasmModule:a,worker:g}}function st(e){let t;if(e!==void 0){t=Object.create(null);for(let r in e){let a=e[r];if(typeof a=="string"||a===!1)t[r]=a;else throw new Error(`Expected ${Z(r)} in mangle cache to map to either a string or false`)}}return t}function De(e,t,r,a,g){let w=s(t,r,"color",q),d=s(t,r,"logLevel",D),E=s(t,r,"logLimit",ve),i=s(t,r,"logStyle",D);w!==void 0?e.push(`--color=${w}`):a&&e.push("--color=true"),e.push(`--log-level=${d||g}`),e.push(`--log-limit=${E||0}`),i&&e.push(`--log-style=${i}`)}function re(e,t,r){if(typeof e!="string")throw new Error(`Expected value for ${t}${r!==void 0?" "+Z(r):""} to be a string, got ${typeof e} instead`);return e}function it(e,t,r){let a=s(t,r,"legalComments",D),g=s(t,r,"sourceRoot",D),w=s(t,r,"sourcesContent",q),d=s(t,r,"target",nt),E=s(t,r,"format",D),i=s(t,r,"globalName",D),x=s(t,r,"mangleProps",Ue),_=s(t,r,"reserveProps",Ue),P=s(t,r,"mangleQuoted",q),B=s(t,r,"minify",q),F=s(t,r,"minifySyntax",q),z=s(t,r,"minifyWhitespace",q),G=s(t,r,"minifyIdentifiers",q),A=s(t,r,"lineLimit",ve),H=s(t,r,"drop",ne),C=s(t,r,"dropLabels",ne),O=s(t,r,"charset",D),b=s(t,r,"treeShaking",q),m=s(t,r,"ignoreAnnotations",q),l=s(t,r,"jsx",D),f=s(t,r,"jsxFactory",D),h=s(t,r,"jsxFragment",D),v=s(t,r,"jsxImportSource",D),S=s(t,r,"jsxDev",q),u=s(t,r,"jsxSideEffects",q),y=s(t,r,"define",ie),j=s(t,r,"logOverride",ie),I=s(t,r,"supported",ie),n=s(t,r,"pure",ne),o=s(t,r,"keepNames",q),k=s(t,r,"platform",D),T=s(t,r,"tsconfigRaw",bt),V=s(t,r,"absPaths",ne);if(a&&e.push(`--legal-comments=${a}`),g!==void 0&&e.push(`--source-root=${g}`),w!==void 0&&e.push(`--sources-content=${w}`),d&&e.push(`--target=${Ee(Array.isArray(d)?d:[d],"target")}`),E&&e.push(`--format=${E}`),i&&e.push(`--global-name=${i}`),k&&e.push(`--platform=${k}`),T&&e.push(`--tsconfig-raw=${typeof T=="string"?T:JSON.stringify(T)}`),B&&e.push("--minify"),F&&e.push("--minify-syntax"),z&&e.push("--minify-whitespace"),G&&e.push("--minify-identifiers"),A&&e.push(`--line-limit=${A}`),O&&e.push(`--charset=${O}`),b!==void 0&&e.push(`--tree-shaking=${b}`),m&&e.push("--ignore-annotations"),H)for(let $ of H)e.push(`--drop:${re($,"drop")}`);if(C&&e.push(`--drop-labels=${Ee(C,"drop label")}`),V&&e.push(`--abs-paths=${Ee(V,"abs paths")}`),x&&e.push(`--mangle-props=${Me(x)}`),_&&e.push(`--reserve-props=${Me(_)}`),P!==void 0&&e.push(`--mangle-quoted=${P}`),l&&e.push(`--jsx=${l}`),f&&e.push(`--jsx-factory=${f}`),h&&e.push(`--jsx-fragment=${h}`),v&&e.push(`--jsx-import-source=${v}`),S&&e.push("--jsx-dev"),u&&e.push("--jsx-side-effects"),y)for(let $ in y){if($.indexOf("=")>=0)throw new Error(`Invalid define: ${$}`);e.push(`--define:${$}=${re(y[$],"define",$)}`)}if(j)for(let $ in j){if($.indexOf("=")>=0)throw new Error(`Invalid log override: ${$}`);e.push(`--log-override:${$}=${re(j[$],"log override",$)}`)}if(I)for(let $ in I){if($.indexOf("=")>=0)throw new Error(`Invalid supported: ${$}`);let J=I[$];if(typeof J!="boolean")throw new Error(`Expected value for supported ${Z($)} to be a boolean, got ${typeof J} instead`);e.push(`--supported:${$}=${J}`)}if(n)for(let $ of n)e.push(`--pure:${re($,"pure")}`);o&&e.push("--keep-names")}function kt(e,t,r,a,g){var w;let d=[],E=[],i=Object.create(null),x=null,_=null;De(d,t,i,r,a),it(d,t,i);let P=s(t,i,"sourcemap",tt),B=s(t,i,"bundle",q),F=s(t,i,"splitting",q),z=s(t,i,"preserveSymlinks",q),G=s(t,i,"metafile",q),A=s(t,i,"outfile",D),H=s(t,i,"outdir",D),C=s(t,i,"outbase",D),O=s(t,i,"tsconfig",D),b=s(t,i,"resolveExtensions",ne),m=s(t,i,"nodePaths",ne),l=s(t,i,"mainFields",ne),f=s(t,i,"conditions",ne),h=s(t,i,"external",ne),v=s(t,i,"packages",D),S=s(t,i,"alias",ie),u=s(t,i,"loader",ie),y=s(t,i,"outExtension",ie),j=s(t,i,"publicPath",D),I=s(t,i,"entryNames",D),n=s(t,i,"chunkNames",D),o=s(t,i,"assetNames",D),k=s(t,i,"inject",ne),T=s(t,i,"banner",ie),V=s(t,i,"footer",ie),$=s(t,i,"entryPoints",wt),J=s(t,i,"absWorkingDir",D),W=s(t,i,"stdin",ie),L=(w=s(t,i,"write",q))!=null?w:g,se=s(t,i,"allowOverwrite",q),K=s(t,i,"mangleCache",ie);if(i.plugins=!0,X(t,i,`in ${e}() call`),P&&d.push(`--sourcemap${P===!0?"":`=${P}`}`),B&&d.push("--bundle"),se&&d.push("--allow-overwrite"),F&&d.push("--splitting"),z&&d.push("--preserve-symlinks"),G&&d.push("--metafile"),A&&d.push(`--outfile=${A}`),H&&d.push(`--outdir=${H}`),C&&d.push(`--outbase=${C}`),O&&d.push(`--tsconfig=${O}`),v&&d.push(`--packages=${v}`),b&&d.push(`--resolve-extensions=${Ee(b,"resolve extension")}`),j&&d.push(`--public-path=${j}`),I&&d.push(`--entry-names=${I}`),n&&d.push(`--chunk-names=${n}`),o&&d.push(`--asset-names=${o}`),l&&d.push(`--main-fields=${Ee(l,"main field")}`),f&&d.push(`--conditions=${Ee(f,"condition")}`),h)for(let R of h)d.push(`--external:${re(R,"external")}`);if(S)for(let R in S){if(R.indexOf("=")>=0)throw new Error(`Invalid package name in alias: ${R}`);d.push(`--alias:${R}=${re(S[R],"alias",R)}`)}if(T)for(let R in T){if(R.indexOf("=")>=0)throw new Error(`Invalid banner file type: ${R}`);d.push(`--banner:${R}=${re(T[R],"banner",R)}`)}if(V)for(let R in V){if(R.indexOf("=")>=0)throw new Error(`Invalid footer file type: ${R}`);d.push(`--footer:${R}=${re(V[R],"footer",R)}`)}if(k)for(let R of k)d.push(`--inject:${re(R,"inject")}`);if(u)for(let R in u){if(R.indexOf("=")>=0)throw new Error(`Invalid loader extension: ${R}`);d.push(`--loader:${R}=${re(u[R],"loader",R)}`)}if(y)for(let R in y){if(R.indexOf("=")>=0)throw new Error(`Invalid out extension: ${R}`);d.push(`--out-extension:${R}=${re(y[R],"out extension",R)}`)}if($)if(Array.isArray($))for(let R=0,pe=$.length;R<pe;R++){let oe=$[R];if(typeof oe=="object"&&oe!==null){let ue=Object.create(null),ge=s(oe,ue,"in",D),ae=s(oe,ue,"out",D);if(X(oe,ue,"in entry point at index "+R),ge===void 0)throw new Error('Missing property "in" for entry point at index '+R);if(ae===void 0)throw new Error('Missing property "out" for entry point at index '+R);E.push([ae,ge])}else E.push(["",re(oe,"entry point at index "+R)])}else for(let R in $)E.push([R,re($[R],"entry point",R)]);if(W){let R=Object.create(null),pe=s(W,R,"contents",rt),oe=s(W,R,"resolveDir",D),ue=s(W,R,"sourcefile",D),ge=s(W,R,"loader",D);X(W,R,'in "stdin" object'),ue&&d.push(`--sourcefile=${ue}`),ge&&d.push(`--loader=${ge}`),oe&&(_=oe),typeof pe=="string"?x=ce(pe):pe instanceof Uint8Array&&(x=pe)}let me=[];if(m)for(let R of m)R+="",me.push(R);return{entries:E,flags:d,write:L,stdinContents:x,stdinResolveDir:_,absWorkingDir:J,nodePaths:me,mangleCache:st(K)}}function Et(e,t,r,a){let g=[],w=Object.create(null);De(g,t,w,r,a),it(g,t,w);let d=s(t,w,"sourcemap",tt),E=s(t,w,"sourcefile",D),i=s(t,w,"loader",D),x=s(t,w,"banner",D),_=s(t,w,"footer",D),P=s(t,w,"mangleCache",ie);return X(t,w,`in ${e}() call`),d&&g.push(`--sourcemap=${d===!0?"external":d}`),E&&g.push(`--sourcefile=${E}`),i&&g.push(`--loader=${i}`),x&&g.push(`--banner=${x}`),_&&g.push(`--footer=${_}`),{flags:g,mangleCache:st(P)}}function _t(e){let t={},r={didClose:!1,reason:""},a={},g=0,w=0,d=new Uint8Array(16*1024),E=0,i=O=>{let b=E+O.length;if(b>d.length){let l=new Uint8Array(b*2);l.set(d),d=l}d.set(O,E),E+=O.length;let m=0;for(;m+4<=E;){let l=Qe(d,m);if(m+4+l>E)break;m+=4,z(d.subarray(m,m+l)),m+=l}m>0&&(d.copyWithin(0,m,E),E-=m)},x=O=>{r.didClose=!0,O&&(r.reason=": "+(O.message||O));let b="The service was stopped"+r.reason;for(let m in a)a[m](b,null);a={}},_=(O,b,m)=>{if(r.didClose)return m("The service is no longer running"+r.reason,null);let l=g++;a[l]=(f,h)=>{try{m(f,h)}finally{O&&O.unref()}},O&&O.ref(),e.writeToStdin($e({id:l,isRequest:!0,value:b}))},P=(O,b)=>{if(r.didClose)throw new Error("The service is no longer running"+r.reason);e.writeToStdin($e({id:O,isRequest:!1,value:b}))},B=(O,b)=>Q(null,null,function*(){try{if(b.command==="ping"){P(O,{});return}if(typeof b.key=="number"){let m=t[b.key];if(!m)return;let l=m[b.command];if(l){yield l(O,b);return}}throw new Error("Invalid command: "+b.command)}catch(m){let l=[xe(m,e,null,void 0,"")];try{P(O,{errors:l})}catch{}}}),F=!0,z=O=>{if(F){F=!1;let m=String.fromCharCode(...O);if(m!=="0.28.2")throw new Error(`Cannot start service: Host version "0.28.2" does not match binary version ${Z(m)}`);return}let b=mt(O);if(b.isRequest)B(b.id,b.value);else{let m=a[b.id];delete a[b.id],b.value.error?m(b.value.error,{}):m(null,b.value)}};return{readFromStdout:i,afterClose:x,service:{buildOrContext:({callName:O,refs:b,options:m,isTTY:l,defaultWD:f,callback:h})=>{let v=0,S=w++,u={},y={ref(){++v===1&&b&&b.ref()},unref(){--v===0&&(delete t[S],b&&b.unref())}};t[S]=u,y.ref(),jt(O,S,_,P,y,e,u,m,l,f,(j,I)=>{try{h(j,I)}finally{y.unref()}})},transform:({callName:O,refs:b,input:m,options:l,isTTY:f,fs:h,callback:v})=>{let S=lt(),u=y=>{try{if(typeof m!="string"&&!(m instanceof Uint8Array))throw new Error('The input to "transform" must be a string or a Uint8Array');let{flags:j,mangleCache:I}=Et(O,l,f,Ke),n={command:"transform",flags:j,inputFS:y!==null,input:y!==null?ce(y):typeof m=="string"?ce(m):m};I&&(n.mangleCache=I),_(b,n,(o,k)=>{if(o)return v(new Error(o),null);let T=_e(k.errors,S),V=_e(k.warnings,S),$=1,J=()=>{if(--$===0){let W={warnings:V,code:k.code,map:k.map,mangleCache:void 0,legalComments:void 0};"legalComments"in k&&(W.legalComments=k?.legalComments),k.mangleCache&&(W.mangleCache=k?.mangleCache),v(null,W)}};if(T.length>0)return v(Pe("Transform failed",T,V),null);k.codeFS&&($++,h.readFile(k.code,(W,L)=>{W!==null?v(W,null):(k.code=L,J())})),k.mapFS&&($++,h.readFile(k.map,(W,L)=>{W!==null?v(W,null):(k.map=L,J())})),J()})}catch(j){let I=[];try{De(I,l,{},f,Ke)}catch{}let n=xe(j,e,S,void 0,"");_(b,{command:"error",flags:I,error:n},()=>{n.detail=S.load(n.detail),v(Pe("Transform failed",[n],[]),null)})}};if((typeof m=="string"||m instanceof Uint8Array)&&m.length>1024*1024){let y=u;u=()=>h.writeFile(m,y)}u(null)},formatMessages:({callName:O,refs:b,messages:m,options:l,callback:f})=>{if(!l)throw new Error(`Missing second argument in ${O}() call`);let h={},v=s(l,h,"kind",D),S=s(l,h,"color",q),u=s(l,h,"terminalWidth",ve),y=s(l,h,"logStyle",D);if(X(l,h,`in ${O}() call`),v===void 0)throw new Error(`Missing "kind" in ${O}() call`);if(v!=="error"&&v!=="warning")throw new Error(`Expected "kind" to be "error" or "warning" in ${O}() call`);let j={command:"format-msgs",messages:he(m,"messages",null,"",u),isWarning:v==="warning"};S!==void 0&&(j.color=S),u!==void 0&&(j.terminalWidth=u),y!==void 0&&(j.logStyle=y),_(b,j,(I,n)=>{if(I)return f(new Error(I),null);f(null,n.messages)})},analyzeMetafile:({callName:O,refs:b,metafile:m,options:l,callback:f})=>{l===void 0&&(l={});let h={},v=s(l,h,"color",q),S=s(l,h,"verbose",q);X(l,h,`in ${O}() call`);let u={command:"analyze-metafile",metafile:m};v!==void 0&&(u.color=v),S!==void 0&&(u.verbose=S),_(b,u,(y,j)=>{if(y)return f(new Error(y),null);f(null,j.result)})}}}}function jt(e,t,r,a,g,w,d,E,i,x,_){let P=lt(),B=e==="context",F=(A,H)=>{let C=[];try{De(C,E,{},i,Xe)}catch{}let O=xe(A,w,P,void 0,H);r(g,{command:"error",flags:C,error:O},()=>{O.detail=P.load(O.detail),_(Pe(B?"Context failed":"Build failed",[O],[]),null)})},z;if(typeof E=="object"){let A=E.plugins;if(A!==void 0){if(!Array.isArray(A))return F(new Error('"plugins" must be an array'),"");z=A}}if(z&&z.length>0){if(w.isSync)return F(new Error("Cannot use plugins in synchronous API calls"),"");St(t,r,a,g,w,d,E,z,P).then(A=>{if(!A.ok)return F(A.error,A.pluginName);try{G(A.requestPlugins,A.runOnEndCallbacks,A.scheduleOnDisposeCallbacks)}catch(H){F(H,"")}},A=>F(A,""));return}try{G(null,(A,H)=>H([],[]),()=>{})}catch(A){F(A,"")}function G(A,H,C){let O=w.hasFS,{entries:b,flags:m,write:l,stdinContents:f,stdinResolveDir:h,absWorkingDir:v,nodePaths:S,mangleCache:u}=kt(e,E,i,Xe,O);if(l&&!w.hasFS)throw new Error('The "write" option is unavailable in this environment');let y={command:"build",key:t,entries:b,flags:m,write:l,stdinContents:f,stdinResolveDir:h,absWorkingDir:v||x,nodePaths:S,context:B};A&&(y.plugins=A),u&&(y.mangleCache=u);let j=(o,k)=>{let T={errors:_e(o.errors,P),warnings:_e(o.warnings,P),outputFiles:void 0,metafile:void 0,mangleCache:void 0},V=T.errors.slice(),$=T.warnings.slice();o.outputFiles&&(T.outputFiles=o.outputFiles.map(Pt)),o.metafile&&o.metafile.length&&(T.metafile=Tt(o.metafile)),o.mangleCache&&(T.mangleCache=o.mangleCache),o.writeToStdout!==void 0&&console.log(be(o.writeToStdout).replace(/\n$/,"")),H(T,(J,W)=>{if(V.length>0||J.length>0){let L=Pe("Build failed",V.concat(J),$.concat(W));return k(L,null,J,W)}k(null,T,J,W)})},I,n;B&&(d["on-end"]=(o,k)=>new Promise(T=>{j(k,(V,$,J,W)=>{let L={errors:J,warnings:W};n&&n(V,$),I=void 0,n=void 0,a(o,L),T()})})),r(g,y,(o,k)=>{if(o)return _(new Error(o),null);if(!B)return j(k,($,J)=>(C(),_($,J)));if(k.errors.length>0)return _(Pe("Context failed",k.errors,k.warnings),null);let T=!1,V={rebuild:()=>(I||(I=new Promise(($,J)=>{let W;n=(se,K)=>{W||(W=()=>se?J(se):$(K))};let L=()=>{r(g,{command:"rebuild",key:t},(K,me)=>{K?J(new Error(K)):W?W():L()})};L()})),I),watch:($={})=>new Promise((J,W)=>{if(!w.hasFS)throw new Error('Cannot use the "watch" API in this environment');let L={},se=s($,L,"delay",ve);X($,L,"in watch() call");let K={command:"watch",key:t};se&&(K.delay=se),r(g,K,me=>{me?W(new Error(me)):J(void 0)})}),serve:($={})=>new Promise((J,W)=>{if(!w.hasFS)throw new Error('Cannot use the "serve" API in this environment');let L={},se=s($,L,"port",gt),K=s($,L,"host",D),me=s($,L,"servedir",D),R=s($,L,"keyfile",D),pe=s($,L,"certfile",D),oe=s($,L,"fallback",D),ue=s($,L,"cors",ie),ge=s($,L,"onRequest",Ze);X($,L,"in serve() call");let ae={command:"serve",key:t,onRequest:!!ge};if(se!==void 0&&(ae.port=se),K!==void 0&&(ae.host=K),me!==void 0&&(ae.servedir=me),R!==void 0&&(ae.keyfile=R),pe!==void 0&&(ae.certfile=pe),oe!==void 0&&(ae.fallback=oe),ue){let Oe={},je=s(ue,Oe,"origin",nt);X(ue,Oe,'on "cors" object'),Array.isArray(je)?ae.corsOrigin=je:je!==void 0&&(ae.corsOrigin=[je])}r(g,ae,(Oe,je)=>{if(Oe)return W(new Error(Oe));ge&&(d["serve-request"]=(zt,Gt)=>{ge(Gt.args),a(zt,{})}),J(je)})}),cancel:()=>new Promise($=>{if(T)return $();r(g,{command:"cancel",key:t},()=>{$()})}),dispose:()=>new Promise($=>{if(T)return $();T=!0,r(g,{command:"dispose",key:t},()=>{$(),C(),g.unref()})})};g.ref(),_(null,V)})}}var St=(e,t,r,a,g,w,d,E,i)=>Q(null,null,function*(){let x=[],_=[],P={},B={},F=[],z=0,G=0,A=[],H=!1;E=[...E];for(let b of E){let m={};if(typeof b!="object")throw new Error(`Plugin at index ${G} must be an object`);let l=s(b,m,"name",D);if(typeof l!="string"||l==="")throw new Error(`Plugin at index ${G} is missing a name`);try{let f=s(b,m,"setup",Ze);if(typeof f!="function")throw new Error("Plugin is missing a setup function");X(b,m,`on plugin ${Z(l)}`);let h={name:l,onStart:!1,onEnd:!1,onResolve:[],onLoad:[]};G++;let S=f({initialOptions:d,resolve:(u,y={})=>{if(!H)throw new Error('Cannot call "resolve" before plugin setup has completed');if(typeof u!="string")throw new Error("The path to resolve must be a string");let j=Object.create(null),I=s(y,j,"pluginName",D),n=s(y,j,"importer",D),o=s(y,j,"namespace",D),k=s(y,j,"resolveDir",D),T=s(y,j,"kind",D),V=s(y,j,"pluginData",Ae),$=s(y,j,"with",ie);return X(y,j,"in resolve() call"),new Promise((J,W)=>{let L={command:"resolve",path:u,key:e,pluginName:l};if(I!=null&&(L.pluginName=I),n!=null&&(L.importer=n),o!=null&&(L.namespace=o),k!=null&&(L.resolveDir=k),T!=null)L.kind=T;else throw new Error('Must specify "kind" when calling "resolve"');V!=null&&(L.pluginData=i.store(V)),$!=null&&(L.with=$t($,"with")),t(a,L,(se,K)=>{se!==null?W(new Error(se)):J({errors:_e(K.errors,i),warnings:_e(K.warnings,i),path:K.path,external:K.external,sideEffects:K.sideEffects,namespace:K.namespace,suffix:K.suffix,pluginData:i.load(K.pluginData)})})})},onStart(u){let y='This error came from the "onStart" callback registered here:',j=Re(new Error(y),g,"onStart");x.push({name:l,callback:u,note:j}),h.onStart=!0},onEnd(u){let y='This error came from the "onEnd" callback registered here:',j=Re(new Error(y),g,"onEnd");_.push({name:l,callback:u,note:j}),h.onEnd=!0},onResolve(u,y){let j='This error came from the "onResolve" callback registered here:',I=Re(new Error(j),g,"onResolve"),n={},o=s(u,n,"filter",Ue),k=s(u,n,"namespace",D);if(X(u,n,`in onResolve() call for plugin ${Z(l)}`),o==null)throw new Error("onResolve() call is missing a filter");let T=z++;P[T]={name:l,callback:y,note:I},h.onResolve.push({id:T,filter:Me(o),namespace:k||""})},onLoad(u,y){let j='This error came from the "onLoad" callback registered here:',I=Re(new Error(j),g,"onLoad"),n={},o=s(u,n,"filter",Ue),k=s(u,n,"namespace",D);if(X(u,n,`in onLoad() call for plugin ${Z(l)}`),o==null)throw new Error("onLoad() call is missing a filter");let T=z++;B[T]={name:l,callback:y,note:I},h.onLoad.push({id:T,filter:Me(o),namespace:k||""})},onDispose(u){F.push(u)},esbuild:g.esbuild});S&&(yield S),A.push(h)}catch(f){return{ok:!1,error:f,pluginName:l}}}w["on-start"]=(b,m)=>Q(null,null,function*(){i.clear();let l={errors:[],warnings:[]};yield Promise.all(x.map(f=>Q(null,[f],function*({name:h,callback:v,note:S}){try{let u=yield v();if(u!=null){if(typeof u!="object")throw new Error(`Expected onStart() callback in plugin ${Z(h)} to return an object`);let y={},j=s(u,y,"errors",de),I=s(u,y,"warnings",de);X(u,y,`from onStart() callback in plugin ${Z(h)}`),j!=null&&l.errors.push(...he(j,"errors",i,h,void 0)),I!=null&&l.warnings.push(...he(I,"warnings",i,h,void 0))}}catch(u){l.errors.push(xe(u,g,i,S&&S(),h))}}))),r(b,l)}),w["on-resolve"]=(b,m)=>Q(null,null,function*(){let l={},f="",h,v;for(let S of m.ids)try{({name:f,callback:h,note:v}=P[S]);let u=yield h({path:m.path,importer:m.importer,namespace:m.namespace,resolveDir:m.resolveDir,kind:m.kind,pluginData:i.load(m.pluginData),with:m.with});if(u!=null){if(typeof u!="object")throw new Error(`Expected onResolve() callback in plugin ${Z(f)} to return an object`);let y={},j=s(u,y,"pluginName",D),I=s(u,y,"path",D),n=s(u,y,"namespace",D),o=s(u,y,"suffix",D),k=s(u,y,"external",q),T=s(u,y,"sideEffects",q),V=s(u,y,"pluginData",Ae),$=s(u,y,"errors",de),J=s(u,y,"warnings",de),W=s(u,y,"watchFiles",ne),L=s(u,y,"watchDirs",ne);X(u,y,`from onResolve() callback in plugin ${Z(f)}`),l.id=S,j!=null&&(l.pluginName=j),I!=null&&(l.path=I),n!=null&&(l.namespace=n),o!=null&&(l.suffix=o),k!=null&&(l.external=k),T!=null&&(l.sideEffects=T),V!=null&&(l.pluginData=i.store(V)),$!=null&&(l.errors=he($,"errors",i,f,void 0)),J!=null&&(l.warnings=he(J,"warnings",i,f,void 0)),W!=null&&(l.watchFiles=Ie(W,"watchFiles")),L!=null&&(l.watchDirs=Ie(L,"watchDirs"));break}}catch(u){l={id:S,errors:[xe(u,g,i,v&&v(),f)]};break}r(b,l)}),w["on-load"]=(b,m)=>Q(null,null,function*(){let l={},f="",h,v;for(let S of m.ids)try{({name:f,callback:h,note:v}=B[S]);let u=yield h({path:m.path,namespace:m.namespace,suffix:m.suffix,pluginData:i.load(m.pluginData),with:m.with});if(u!=null){if(typeof u!="object")throw new Error(`Expected onLoad() callback in plugin ${Z(f)} to return an object`);let y={},j=s(u,y,"pluginName",D),I=s(u,y,"contents",rt),n=s(u,y,"resolveDir",D),o=s(u,y,"pluginData",Ae),k=s(u,y,"loader",D),T=s(u,y,"errors",de),V=s(u,y,"warnings",de),$=s(u,y,"watchFiles",ne),J=s(u,y,"watchDirs",ne);X(u,y,`from onLoad() callback in plugin ${Z(f)}`),l.id=S,j!=null&&(l.pluginName=j),I instanceof Uint8Array?l.contents=I:I!=null&&(l.contents=ce(I)),n!=null&&(l.resolveDir=n),o!=null&&(l.pluginData=i.store(o)),k!=null&&(l.loader=k),T!=null&&(l.errors=he(T,"errors",i,f,void 0)),V!=null&&(l.warnings=he(V,"warnings",i,f,void 0)),$!=null&&(l.watchFiles=Ie($,"watchFiles")),J!=null&&(l.watchDirs=Ie(J,"watchDirs"));break}}catch(u){l={id:S,errors:[xe(u,g,i,v&&v(),f)]};break}r(b,l)});let C=(b,m)=>m([],[]);_.length>0&&(C=(b,m)=>{Q(null,null,function*(){let l=[],f=[];for(let{name:h,callback:v,note:S}of _){let u,y;try{let j=yield v(b);if(j!=null){if(typeof j!="object")throw new Error(`Expected onEnd() callback in plugin ${Z(h)} to return an object`);let I={},n=s(j,I,"errors",de),o=s(j,I,"warnings",de);X(j,I,`from onEnd() callback in plugin ${Z(h)}`),n!=null&&(u=he(n,"errors",i,h,void 0)),o!=null&&(y=he(o,"warnings",i,h,void 0))}}catch(j){u=[xe(j,g,i,S&&S(),h)]}if(u){l.push(...u);try{b.errors.push(...u)}catch{}}if(y){f.push(...y);try{b.warnings.push(...y)}catch{}}}m(l,f)})});let O=()=>{for(let b of F)setTimeout(()=>b(),0)};return H=!0,{ok:!0,requestPlugins:A,runOnEndCallbacks:C,scheduleOnDisposeCallbacks:O}});function lt(){let e=new Map,t=0;return{clear(){e.clear()},load(r){return e.get(r)},store(r){if(r===void 0)return-1;let a=t++;return e.set(a,r),a}}}function Re(e,t,r){let a,g=!1;return()=>{if(g)return a;g=!0;try{let w=(e.stack+"").split(`
`);w.splice(1,1);let d=ot(t,w,r);if(d)return a={text:e.message,location:d},a}catch{}}}function xe(e,t,r,a,g){let w="Internal error",d=null;try{w=(e&&e.message||e)+""}catch{}try{d=ot(t,(e.stack+"").split(`
`),"")}catch{}return{id:"",pluginName:g,text:w,location:d,notes:a?[a]:[],detail:r?r.store(e):-1}}function ot(e,t,r){let a="    at ";if(e.readFileSync&&!t[0].startsWith(a)&&t[1].startsWith(a))for(let g=1;g<t.length;g++){let w=t[g];if(w.startsWith(a))for(w=w.slice(a.length);;){let d=/^(?:new |async )?\S+ \((.*)\)$/.exec(w);if(d){w=d[1];continue}if(d=/^eval at \S+ \((.*)\)(?:, \S+:\d+:\d+)?$/.exec(w),d){w=d[1];continue}if(d=/^(\S+):(\d+):(\d+)$/.exec(w),d){let E;try{E=e.readFileSync(d[1],"utf8")}catch{break}let i=E.split(/\r\n|\r|\n|\u2028|\u2029/)[+d[2]-1]||"",x=+d[3]-1,_=i.slice(x,x+r.length)===r?r.length:0;return{file:d[1],namespace:"file",line:+d[2],column:ce(i.slice(0,x)).length,length:ce(i.slice(x,x+_)).length,lineText:i+`
`+t.slice(1).join(`
`),suggestion:""}}break}}return null}function Pe(e,t,r){let a=5;e+=t.length<1?"":` with ${t.length} error${t.length<2?"":"s"}:`+t.slice(0,a+1).map((w,d)=>{if(d===a)return`
...`;if(!w.location)return`
error: ${w.text}`;let{file:E,line:i,column:x}=w.location,_=w.pluginName?`[plugin: ${w.pluginName}] `:"";return`
${E}:${i}:${x}: ERROR: ${_}${w.text}`}).join("");let g=new Error(e);for(let[w,d]of[["errors",t],["warnings",r]])Object.defineProperty(g,w,{configurable:!0,enumerable:!0,get:()=>d,set:E=>Object.defineProperty(g,w,{configurable:!0,enumerable:!0,value:E})});return g}function _e(e,t){for(let r of e)r.detail=t.load(r.detail);return e}function at(e,t,r){if(e==null)return null;let a={},g=s(e,a,"file",D),w=s(e,a,"namespace",D),d=s(e,a,"line",ve),E=s(e,a,"column",ve),i=s(e,a,"length",ve),x=s(e,a,"lineText",D),_=s(e,a,"suggestion",D);if(X(e,a,t),x){let P=x.slice(0,(E&&E>0?E:0)+(i&&i>0?i:0)+(r&&r>0?r:80));!/[\x7F-\uFFFF]/.test(P)&&!/\n/.test(x)&&(x=P)}return{file:g||"",namespace:w||"",line:d||0,column:E||0,length:i||0,lineText:x||"",suggestion:_||""}}function he(e,t,r,a,g){let w=[],d=0;for(let E of e){let i={},x=s(E,i,"id",D),_=s(E,i,"pluginName",D),P=s(E,i,"text",D),B=s(E,i,"location",et),F=s(E,i,"notes",de),z=s(E,i,"detail",Ae),G=`in element ${d} of "${t}"`;X(E,i,G);let A=[];if(F)for(let H of F){let C={},O=s(H,C,"text",D),b=s(H,C,"location",et);X(H,C,G),A.push({text:O||"",location:at(b,G,g)})}w.push({id:x||"",pluginName:_||a,text:P||"",location:at(B,G,g),notes:A,detail:r?r.store(z):-1}),d++}return w}function Ie(e,t){let r=[];for(let a of e){if(typeof a!="string")throw new Error(`${Z(t)} must be an array of strings`);r.push(a)}return r}function $t(e,t){let r=Object.create(null);for(let a in e){let g=e[a];if(typeof g!="string")throw new Error(`key ${Z(a)} in object ${Z(t)} must be a string`);r[a]=g}return r}function Pt({path:e,contents:t,hash:r}){let a=null;return{path:e,contents:t,hash:r,get text(){let g=this.contents;return(a===null||g!==t)&&(t=g,a=be(g)),a}}}function Me(e){let t=e.source;return e.flags&&(t=`(?${e.flags})${t}`),t}function Tt(e){let t;try{t=be(e)}catch{return pt(e)}return JSON.parse(t)}var Ot="0.28.2",Ct=e=>Te().build(e),At=e=>Te().context(e),Ut=(e,t)=>Te().transform(e,t),Dt=(e,t)=>Te().formatMessages(e,t),Rt=(e,t)=>Te().analyzeMetafile(e,t),It=()=>{throw new Error('The "buildSync" API only works in node')},Mt=()=>{throw new Error('The "transformSync" API only works in node')},Nt=()=>{throw new Error('The "formatMessagesSync" API only works in node')},Ft=()=>{throw new Error('The "analyzeMetafileSync" API only works in node')},Vt=()=>(Ne&&Ne(),Promise.resolve()),ke,Ne,Fe,Te=()=>{if(Fe)return Fe;throw ke?new Error('You need to wait for the promise returned from "initialize" to be resolved before calling this'):new Error('You need to call "initialize" before calling this')},Lt=e=>{e=xt(e||{});let t=e.wasmURL,r=e.wasmModule,a=e.worker!==!1;if(!t&&!r)throw new Error('Must provide either the "wasmURL" option or the "wasmModule" option');if(ke)throw new Error('Cannot call "initialize" more than once');return ke=Bt(t||"",r,a),ke.catch(()=>{ke=void 0}),ke},Bt=(e,t,r)=>Q(null,null,function*(){let a,g,w=new Promise(P=>g=P);if(r){let P=new Blob([`onmessage=((postMessage) => {
      // Copyright 2018 The Go Authors. All rights reserved.
      // Use of this source code is governed by a BSD-style
      // license that can be found in the LICENSE file.
      var __async = (__this, __arguments, generator) => {
        return new Promise((resolve, reject) => {
          var fulfilled = (value) => {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          };
          var rejected = (value) => {
            try {
              step(generator.throw(value));
            } catch (e) {
              reject(e);
            }
          };
          var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
          step((generator = generator.apply(__this, __arguments)).next());
        });
      };
      let onmessage;
      let globalThis = {};
      for (let o = self; o; o = Object.getPrototypeOf(o))
        for (let k of Object.getOwnPropertyNames(o))
          if (!(k in globalThis))
            Object.defineProperty(globalThis, k, { get: () => self[k] });
      "use strict";
      (() => {
        const enosys = () => {
          const err = new Error("not implemented");
          err.code = "ENOSYS";
          return err;
        };
        if (!globalThis.fs) {
          let outputBuf = "";
          globalThis.fs = {
            constants: { O_WRONLY: -1, O_RDWR: -1, O_CREAT: -1, O_TRUNC: -1, O_APPEND: -1, O_EXCL: -1, O_DIRECTORY: -1 },
            // unused
            writeSync(fd, buf) {
              outputBuf += decoder.decode(buf);
              const nl = outputBuf.lastIndexOf("\\n");
              if (nl != -1) {
                console.log(outputBuf.substring(0, nl));
                outputBuf = outputBuf.substring(nl + 1);
              }
              return buf.length;
            },
            write(fd, buf, offset, length, position, callback) {
              if (offset !== 0 || length !== buf.length || position !== null) {
                callback(enosys());
                return;
              }
              const n = this.writeSync(fd, buf);
              callback(null, n);
            },
            chmod(path, mode, callback) {
              callback(enosys());
            },
            chown(path, uid, gid, callback) {
              callback(enosys());
            },
            close(fd, callback) {
              callback(enosys());
            },
            fchmod(fd, mode, callback) {
              callback(enosys());
            },
            fchown(fd, uid, gid, callback) {
              callback(enosys());
            },
            fstat(fd, callback) {
              callback(enosys());
            },
            fsync(fd, callback) {
              callback(null);
            },
            ftruncate(fd, length, callback) {
              callback(enosys());
            },
            lchown(path, uid, gid, callback) {
              callback(enosys());
            },
            link(path, link, callback) {
              callback(enosys());
            },
            lstat(path, callback) {
              callback(enosys());
            },
            mkdir(path, perm, callback) {
              callback(enosys());
            },
            open(path, flags, mode, callback) {
              callback(enosys());
            },
            read(fd, buffer, offset, length, position, callback) {
              callback(enosys());
            },
            readdir(path, callback) {
              callback(enosys());
            },
            readlink(path, callback) {
              callback(enosys());
            },
            rename(from, to, callback) {
              callback(enosys());
            },
            rmdir(path, callback) {
              callback(enosys());
            },
            stat(path, callback) {
              callback(enosys());
            },
            symlink(path, link, callback) {
              callback(enosys());
            },
            truncate(path, length, callback) {
              callback(enosys());
            },
            unlink(path, callback) {
              callback(enosys());
            },
            utimes(path, atime, mtime, callback) {
              callback(enosys());
            }
          };
        }
        if (!globalThis.process) {
          globalThis.process = {
            getuid() {
              return -1;
            },
            getgid() {
              return -1;
            },
            geteuid() {
              return -1;
            },
            getegid() {
              return -1;
            },
            getgroups() {
              throw enosys();
            },
            pid: -1,
            ppid: -1,
            umask() {
              throw enosys();
            },
            cwd() {
              throw enosys();
            },
            chdir() {
              throw enosys();
            }
          };
        }
        if (!globalThis.path) {
          globalThis.path = {
            resolve(...pathSegments) {
              return pathSegments.join("/");
            }
          };
        }
        if (!globalThis.crypto) {
          throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");
        }
        if (!globalThis.performance) {
          throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");
        }
        if (!globalThis.TextEncoder) {
          throw new Error("globalThis.TextEncoder is not available, polyfill required");
        }
        if (!globalThis.TextDecoder) {
          throw new Error("globalThis.TextDecoder is not available, polyfill required");
        }
        const encoder = new TextEncoder("utf-8");
        const decoder = new TextDecoder("utf-8");
        globalThis.Go = class {
          constructor() {
            this.argv = ["js"];
            this.env = {};
            this.exit = (code) => {
              if (code !== 0) {
                console.warn("exit code:", code);
              }
            };
            this._exitPromise = new Promise((resolve) => {
              this._resolveExitPromise = resolve;
            });
            this._pendingEvent = null;
            this._scheduledTimeouts = /* @__PURE__ */ new Map();
            this._nextCallbackTimeoutID = 1;
            const setInt64 = (addr, v) => {
              this.mem.setUint32(addr + 0, v, true);
              this.mem.setUint32(addr + 4, Math.floor(v / 4294967296), true);
            };
            const setInt32 = (addr, v) => {
              this.mem.setUint32(addr + 0, v, true);
            };
            const getInt64 = (addr) => {
              const low = this.mem.getUint32(addr + 0, true);
              const high = this.mem.getInt32(addr + 4, true);
              return low + high * 4294967296;
            };
            const loadValue = (addr) => {
              const f = this.mem.getFloat64(addr, true);
              if (f === 0) {
                return void 0;
              }
              if (!isNaN(f)) {
                return f;
              }
              const id = this.mem.getUint32(addr, true);
              return this._values[id];
            };
            const storeValue = (addr, v) => {
              const nanHead = 2146959360;
              if (typeof v === "number" && v !== 0) {
                if (isNaN(v)) {
                  this.mem.setUint32(addr + 4, nanHead, true);
                  this.mem.setUint32(addr, 0, true);
                  return;
                }
                this.mem.setFloat64(addr, v, true);
                return;
              }
              if (v === void 0) {
                this.mem.setFloat64(addr, 0, true);
                return;
              }
              let id = this._ids.get(v);
              if (id === void 0) {
                id = this._idPool.pop();
                if (id === void 0) {
                  id = this._values.length;
                }
                this._values[id] = v;
                this._goRefCounts[id] = 0;
                this._ids.set(v, id);
              }
              this._goRefCounts[id]++;
              let typeFlag = 0;
              switch (typeof v) {
                case "object":
                  if (v !== null) {
                    typeFlag = 1;
                  }
                  break;
                case "string":
                  typeFlag = 2;
                  break;
                case "symbol":
                  typeFlag = 3;
                  break;
                case "function":
                  typeFlag = 4;
                  break;
              }
              this.mem.setUint32(addr + 4, nanHead | typeFlag, true);
              this.mem.setUint32(addr, id, true);
            };
            const loadSlice = (addr) => {
              const array = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              return new Uint8Array(this._inst.exports.mem.buffer, array, len);
            };
            const loadSliceOfValues = (addr) => {
              const array = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              const a = new Array(len);
              for (let i = 0; i < len; i++) {
                a[i] = loadValue(array + i * 8);
              }
              return a;
            };
            const loadString = (addr) => {
              const saddr = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              return decoder.decode(new DataView(this._inst.exports.mem.buffer, saddr, len));
            };
            const testCallExport = (a, b) => {
              this._inst.exports.testExport0();
              return this._inst.exports.testExport(a, b);
            };
            const timeOrigin = Date.now() - performance.now();
            this.importObject = {
              _gotest: {
                add: (a, b) => a + b,
                callExport: testCallExport
              },
              gojs: {
                // Go's SP does not change as long as no Go code is running. Some operations (e.g. calls, getters and setters)
                // may synchronously trigger a Go event handler. This makes Go code get executed in the middle of the imported
                // function. A goroutine can switch to a new stack if the current stack is too small (see morestack function).
                // This changes the SP, thus we have to update the SP used by the imported function.
                // func wasmExit(code int32)
                "runtime.wasmExit": (sp) => {
                  sp >>>= 0;
                  const code = this.mem.getInt32(sp + 8, true);
                  this.exited = true;
                  delete this._inst;
                  delete this._values;
                  delete this._goRefCounts;
                  delete this._ids;
                  delete this._idPool;
                  this.exit(code);
                },
                // func wasmWrite(fd uintptr, p unsafe.Pointer, n int32)
                "runtime.wasmWrite": (sp) => {
                  sp >>>= 0;
                  const fd = getInt64(sp + 8);
                  const p = getInt64(sp + 16);
                  const n = this.mem.getInt32(sp + 24, true);
                  globalThis.fs.writeSync(fd, new Uint8Array(this._inst.exports.mem.buffer, p, n));
                },
                // func resetMemoryDataView()
                "runtime.resetMemoryDataView": (sp) => {
                  sp >>>= 0;
                  this.mem = new DataView(this._inst.exports.mem.buffer);
                },
                // func nanotime1() int64
                "runtime.nanotime1": (sp) => {
                  sp >>>= 0;
                  setInt64(sp + 8, (timeOrigin + performance.now()) * 1e6);
                },
                // func walltime() (sec int64, nsec int32)
                "runtime.walltime": (sp) => {
                  sp >>>= 0;
                  const msec = (/* @__PURE__ */ new Date()).getTime();
                  setInt64(sp + 8, msec / 1e3);
                  this.mem.setInt32(sp + 16, msec % 1e3 * 1e6, true);
                },
                // func scheduleTimeoutEvent(delay int64) int32
                "runtime.scheduleTimeoutEvent": (sp) => {
                  sp >>>= 0;
                  const id = this._nextCallbackTimeoutID;
                  this._nextCallbackTimeoutID++;
                  this._scheduledTimeouts.set(id, setTimeout(
                    () => {
                      this._resume();
                      while (this._scheduledTimeouts.has(id)) {
                        console.warn("scheduleTimeoutEvent: missed timeout event");
                        this._resume();
                      }
                    },
                    getInt64(sp + 8)
                  ));
                  this.mem.setInt32(sp + 16, id, true);
                },
                // func clearTimeoutEvent(id int32)
                "runtime.clearTimeoutEvent": (sp) => {
                  sp >>>= 0;
                  const id = this.mem.getInt32(sp + 8, true);
                  clearTimeout(this._scheduledTimeouts.get(id));
                  this._scheduledTimeouts.delete(id);
                },
                // func getRandomData(r []byte)
                "runtime.getRandomData": (sp) => {
                  sp >>>= 0;
                  crypto.getRandomValues(loadSlice(sp + 8));
                },
                // func finalizeRef(v ref)
                "syscall/js.finalizeRef": (sp) => {
                  sp >>>= 0;
                  const id = this.mem.getUint32(sp + 8, true);
                  this._goRefCounts[id]--;
                  if (this._goRefCounts[id] === 0) {
                    const v = this._values[id];
                    this._values[id] = null;
                    this._ids.delete(v);
                    this._idPool.push(id);
                  }
                },
                // func stringVal(value string) ref
                "syscall/js.stringVal": (sp) => {
                  sp >>>= 0;
                  storeValue(sp + 24, loadString(sp + 8));
                },
                // func valueGet(v ref, p string) ref
                "syscall/js.valueGet": (sp) => {
                  sp >>>= 0;
                  const result = Reflect.get(loadValue(sp + 8), loadString(sp + 16));
                  sp = this._inst.exports.getsp() >>> 0;
                  storeValue(sp + 32, result);
                },
                // func valueSet(v ref, p string, x ref)
                "syscall/js.valueSet": (sp) => {
                  sp >>>= 0;
                  Reflect.set(loadValue(sp + 8), loadString(sp + 16), loadValue(sp + 32));
                },
                // func valueDelete(v ref, p string)
                "syscall/js.valueDelete": (sp) => {
                  sp >>>= 0;
                  Reflect.deleteProperty(loadValue(sp + 8), loadString(sp + 16));
                },
                // func valueIndex(v ref, i int) ref
                "syscall/js.valueIndex": (sp) => {
                  sp >>>= 0;
                  storeValue(sp + 24, Reflect.get(loadValue(sp + 8), getInt64(sp + 16)));
                },
                // valueSetIndex(v ref, i int, x ref)
                "syscall/js.valueSetIndex": (sp) => {
                  sp >>>= 0;
                  Reflect.set(loadValue(sp + 8), getInt64(sp + 16), loadValue(sp + 24));
                },
                // func valueCall(v ref, m string, args []ref) (ref, bool)
                "syscall/js.valueCall": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const m = Reflect.get(v, loadString(sp + 16));
                    const args = loadSliceOfValues(sp + 32);
                    const result = Reflect.apply(m, v, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 56, result);
                    this.mem.setUint8(sp + 64, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 56, err);
                    this.mem.setUint8(sp + 64, 0);
                  }
                },
                // func valueInvoke(v ref, args []ref) (ref, bool)
                "syscall/js.valueInvoke": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const args = loadSliceOfValues(sp + 16);
                    const result = Reflect.apply(v, void 0, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, result);
                    this.mem.setUint8(sp + 48, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, err);
                    this.mem.setUint8(sp + 48, 0);
                  }
                },
                // func valueNew(v ref, args []ref) (ref, bool)
                "syscall/js.valueNew": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const args = loadSliceOfValues(sp + 16);
                    const result = Reflect.construct(v, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, result);
                    this.mem.setUint8(sp + 48, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, err);
                    this.mem.setUint8(sp + 48, 0);
                  }
                },
                // func valueLength(v ref) int
                "syscall/js.valueLength": (sp) => {
                  sp >>>= 0;
                  setInt64(sp + 16, parseInt(loadValue(sp + 8).length));
                },
                // valuePrepareString(v ref) (ref, int)
                "syscall/js.valuePrepareString": (sp) => {
                  sp >>>= 0;
                  const str = encoder.encode(String(loadValue(sp + 8)));
                  storeValue(sp + 16, str);
                  setInt64(sp + 24, str.length);
                },
                // valueLoadString(v ref, b []byte)
                "syscall/js.valueLoadString": (sp) => {
                  sp >>>= 0;
                  const str = loadValue(sp + 8);
                  loadSlice(sp + 16).set(str);
                },
                // func valueInstanceOf(v ref, t ref) bool
                "syscall/js.valueInstanceOf": (sp) => {
                  sp >>>= 0;
                  this.mem.setUint8(sp + 24, loadValue(sp + 8) instanceof loadValue(sp + 16) ? 1 : 0);
                },
                // func copyBytesToGo(dst []byte, src ref) (int, bool)
                "syscall/js.copyBytesToGo": (sp) => {
                  sp >>>= 0;
                  const dst = loadSlice(sp + 8);
                  const src = loadValue(sp + 32);
                  if (!(src instanceof Uint8Array || src instanceof Uint8ClampedArray)) {
                    this.mem.setUint8(sp + 48, 0);
                    return;
                  }
                  const toCopy = src.subarray(0, dst.length);
                  dst.set(toCopy);
                  setInt64(sp + 40, toCopy.length);
                  this.mem.setUint8(sp + 48, 1);
                },
                // func copyBytesToJS(dst ref, src []byte) (int, bool)
                "syscall/js.copyBytesToJS": (sp) => {
                  sp >>>= 0;
                  const dst = loadValue(sp + 8);
                  const src = loadSlice(sp + 16);
                  if (!(dst instanceof Uint8Array || dst instanceof Uint8ClampedArray)) {
                    this.mem.setUint8(sp + 48, 0);
                    return;
                  }
                  const toCopy = src.subarray(0, dst.length);
                  dst.set(toCopy);
                  setInt64(sp + 40, toCopy.length);
                  this.mem.setUint8(sp + 48, 1);
                },
                "debug": (value) => {
                  console.log(value);
                }
              }
            };
          }
          run(instance) {
            return __async(this, null, function* () {
              if (!(instance instanceof WebAssembly.Instance)) {
                throw new Error("Go.run: WebAssembly.Instance expected");
              }
              this._inst = instance;
              this.mem = new DataView(this._inst.exports.mem.buffer);
              this._values = [
                // JS values that Go currently has references to, indexed by reference id
                NaN,
                0,
                null,
                true,
                false,
                globalThis,
                this
              ];
              this._goRefCounts = new Array(this._values.length).fill(Infinity);
              this._ids = /* @__PURE__ */ new Map([
                // mapping from JS values to reference ids
                [0, 1],
                [null, 2],
                [true, 3],
                [false, 4],
                [globalThis, 5],
                [this, 6]
              ]);
              this._idPool = [];
              this.exited = false;
              let offset = 4096;
              const strPtr = (str) => {
                const ptr = offset;
                const bytes = encoder.encode(str + "\\0");
                new Uint8Array(this.mem.buffer, offset, bytes.length).set(bytes);
                offset += bytes.length;
                if (offset % 8 !== 0) {
                  offset += 8 - offset % 8;
                }
                return ptr;
              };
              const argc = this.argv.length;
              const argvPtrs = [];
              this.argv.forEach((arg) => {
                argvPtrs.push(strPtr(arg));
              });
              argvPtrs.push(0);
              const keys = Object.keys(this.env).sort();
              keys.forEach((key) => {
                argvPtrs.push(strPtr(\`\${key}=\${this.env[key]}\`));
              });
              argvPtrs.push(0);
              const argv = offset;
              argvPtrs.forEach((ptr) => {
                this.mem.setUint32(offset, ptr, true);
                this.mem.setUint32(offset + 4, 0, true);
                offset += 8;
              });
              const wasmMinDataAddr = 4096 + 8192;
              if (offset >= wasmMinDataAddr) {
                throw new Error("total length of command line and environment variables exceeds limit");
              }
              this._inst.exports.run(argc, argv);
              if (this.exited) {
                this._resolveExitPromise();
              }
              yield this._exitPromise;
            });
          }
          _resume() {
            if (this.exited) {
              throw new Error("Go program has already exited");
            }
            this._inst.exports.resume();
            if (this.exited) {
              this._resolveExitPromise();
            }
          }
          _makeFuncWrapper(id) {
            const go = this;
            return function() {
              const event = { id, this: this, args: arguments };
              go._pendingEvent = event;
              go._resume();
              return event.result;
            };
          }
        };
      })();
      onmessage = ({ data: wasm }) => {
        let decoder = new TextDecoder();
        let fs = globalThis.fs;
        let stderr = "";
        fs.writeSync = (fd, buffer) => {
          if (fd === 1) {
            postMessage(buffer);
          } else if (fd === 2) {
            stderr += decoder.decode(buffer);
            let parts = stderr.split("\\n");
            if (parts.length > 1) console.log(parts.slice(0, -1).join("\\n"));
            stderr = parts[parts.length - 1];
          } else {
            throw new Error("Bad write");
          }
          return buffer.length;
        };
        let stdin = [];
        let resumeStdin;
        let stdinPos = 0;
        onmessage = ({ data }) => {
          if (data.length > 0) {
            stdin.push(data);
            if (resumeStdin) resumeStdin();
          }
          return go;
        };
        fs.read = (fd, buffer, offset, length, position, callback) => {
          if (fd !== 0 || offset !== 0 || length !== buffer.length || position !== null) {
            throw new Error("Bad read");
          }
          if (stdin.length === 0) {
            resumeStdin = () => fs.read(fd, buffer, offset, length, position, callback);
            return;
          }
          let first = stdin[0];
          let count = Math.max(0, Math.min(length, first.length - stdinPos));
          buffer.set(first.subarray(stdinPos, stdinPos + count), offset);
          stdinPos += count;
          if (stdinPos === first.length) {
            stdin.shift();
            stdinPos = 0;
          }
          callback(null, count);
        };
        let go = new globalThis.Go();
        go.argv = ["", \`--service=\${"0.28.2"}\`];
        tryToInstantiateModule(wasm, go).then(
          (instance) => {
            postMessage(null);
            go.run(instance);
          },
          (error) => {
            postMessage(error);
          }
        );
        return go;
      };
      function tryToInstantiateModule(wasm, go) {
        return __async(this, null, function* () {
          if (wasm instanceof WebAssembly.Module) {
            return WebAssembly.instantiate(wasm, go.importObject);
          }
          const res = yield fetch(wasm);
          if (!res.ok) throw new Error(\`Failed to download \${JSON.stringify(wasm)}\`);
          if ("instantiateStreaming" in WebAssembly && /^application\\/wasm($|;)/i.test(res.headers.get("Content-Type") || "")) {
            const result2 = yield WebAssembly.instantiateStreaming(res, go.importObject);
            return result2.instance;
          }
          const bytes = yield res.arrayBuffer();
          const result = yield WebAssembly.instantiate(bytes, go.importObject);
          return result.instance;
        });
      }
      return (m) => onmessage(m);
    })(postMessage)`],{type:"text/javascript"});a=new Worker(URL.createObjectURL(P))}else{let P=(F=>{var z=(C,O,b)=>new Promise((m,l)=>{var f=S=>{try{v(b.next(S))}catch(u){l(u)}},h=S=>{try{v(b.throw(S))}catch(u){l(u)}},v=S=>S.done?m(S.value):Promise.resolve(S.value).then(f,h);v((b=b.apply(C,O)).next())});let G,A={};for(let C=self;C;C=Object.getPrototypeOf(C))for(let O of Object.getOwnPropertyNames(C))O in A||Object.defineProperty(A,O,{get:()=>self[O]});(()=>{let C=()=>{let m=new Error("not implemented");return m.code="ENOSYS",m};if(!A.fs){let m="";A.fs={constants:{O_WRONLY:-1,O_RDWR:-1,O_CREAT:-1,O_TRUNC:-1,O_APPEND:-1,O_EXCL:-1,O_DIRECTORY:-1},writeSync(l,f){m+=b.decode(f);let h=m.lastIndexOf(`
`);return h!=-1&&(console.log(m.substring(0,h)),m=m.substring(h+1)),f.length},write(l,f,h,v,S,u){if(h!==0||v!==f.length||S!==null){u(C());return}let y=this.writeSync(l,f);u(null,y)},chmod(l,f,h){h(C())},chown(l,f,h,v){v(C())},close(l,f){f(C())},fchmod(l,f,h){h(C())},fchown(l,f,h,v){v(C())},fstat(l,f){f(C())},fsync(l,f){f(null)},ftruncate(l,f,h){h(C())},lchown(l,f,h,v){v(C())},link(l,f,h){h(C())},lstat(l,f){f(C())},mkdir(l,f,h){h(C())},open(l,f,h,v){v(C())},read(l,f,h,v,S,u){u(C())},readdir(l,f){f(C())},readlink(l,f){f(C())},rename(l,f,h){h(C())},rmdir(l,f){f(C())},stat(l,f){f(C())},symlink(l,f,h){h(C())},truncate(l,f,h){h(C())},unlink(l,f){f(C())},utimes(l,f,h,v){v(C())}}}if(A.process||(A.process={getuid(){return-1},getgid(){return-1},geteuid(){return-1},getegid(){return-1},getgroups(){throw C()},pid:-1,ppid:-1,umask(){throw C()},cwd(){throw C()},chdir(){throw C()}}),A.path||(A.path={resolve(...m){return m.join("/")}}),!A.crypto)throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");if(!A.performance)throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");if(!A.TextEncoder)throw new Error("globalThis.TextEncoder is not available, polyfill required");if(!A.TextDecoder)throw new Error("globalThis.TextDecoder is not available, polyfill required");let O=new TextEncoder("utf-8"),b=new TextDecoder("utf-8");A.Go=class{constructor(){this.argv=["js"],this.env={},this.exit=n=>{n!==0&&console.warn("exit code:",n)},this._exitPromise=new Promise(n=>{this._resolveExitPromise=n}),this._pendingEvent=null,this._scheduledTimeouts=new Map,this._nextCallbackTimeoutID=1;let m=(n,o)=>{this.mem.setUint32(n+0,o,!0),this.mem.setUint32(n+4,Math.floor(o/4294967296),!0)},l=(n,o)=>{this.mem.setUint32(n+0,o,!0)},f=n=>{let o=this.mem.getUint32(n+0,!0),k=this.mem.getInt32(n+4,!0);return o+k*4294967296},h=n=>{let o=this.mem.getFloat64(n,!0);if(o===0)return;if(!isNaN(o))return o;let k=this.mem.getUint32(n,!0);return this._values[k]},v=(n,o)=>{if(typeof o=="number"&&o!==0){if(isNaN(o)){this.mem.setUint32(n+4,2146959360,!0),this.mem.setUint32(n,0,!0);return}this.mem.setFloat64(n,o,!0);return}if(o===void 0){this.mem.setFloat64(n,0,!0);return}let T=this._ids.get(o);T===void 0&&(T=this._idPool.pop(),T===void 0&&(T=this._values.length),this._values[T]=o,this._goRefCounts[T]=0,this._ids.set(o,T)),this._goRefCounts[T]++;let V=0;switch(typeof o){case"object":o!==null&&(V=1);break;case"string":V=2;break;case"symbol":V=3;break;case"function":V=4;break}this.mem.setUint32(n+4,2146959360|V,!0),this.mem.setUint32(n,T,!0)},S=n=>{let o=f(n+0),k=f(n+8);return new Uint8Array(this._inst.exports.mem.buffer,o,k)},u=n=>{let o=f(n+0),k=f(n+8),T=new Array(k);for(let V=0;V<k;V++)T[V]=h(o+V*8);return T},y=n=>{let o=f(n+0),k=f(n+8);return b.decode(new DataView(this._inst.exports.mem.buffer,o,k))},j=(n,o)=>(this._inst.exports.testExport0(),this._inst.exports.testExport(n,o)),I=Date.now()-performance.now();this.importObject={_gotest:{add:(n,o)=>n+o,callExport:j},gojs:{"runtime.wasmExit":n=>{n>>>=0;let o=this.mem.getInt32(n+8,!0);this.exited=!0,delete this._inst,delete this._values,delete this._goRefCounts,delete this._ids,delete this._idPool,this.exit(o)},"runtime.wasmWrite":n=>{n>>>=0;let o=f(n+8),k=f(n+16),T=this.mem.getInt32(n+24,!0);A.fs.writeSync(o,new Uint8Array(this._inst.exports.mem.buffer,k,T))},"runtime.resetMemoryDataView":n=>{n>>>=0,this.mem=new DataView(this._inst.exports.mem.buffer)},"runtime.nanotime1":n=>{n>>>=0,m(n+8,(I+performance.now())*1e6)},"runtime.walltime":n=>{n>>>=0;let o=new Date().getTime();m(n+8,o/1e3),this.mem.setInt32(n+16,o%1e3*1e6,!0)},"runtime.scheduleTimeoutEvent":n=>{n>>>=0;let o=this._nextCallbackTimeoutID;this._nextCallbackTimeoutID++,this._scheduledTimeouts.set(o,setTimeout(()=>{for(this._resume();this._scheduledTimeouts.has(o);)console.warn("scheduleTimeoutEvent: missed timeout event"),this._resume()},f(n+8))),this.mem.setInt32(n+16,o,!0)},"runtime.clearTimeoutEvent":n=>{n>>>=0;let o=this.mem.getInt32(n+8,!0);clearTimeout(this._scheduledTimeouts.get(o)),this._scheduledTimeouts.delete(o)},"runtime.getRandomData":n=>{n>>>=0,crypto.getRandomValues(S(n+8))},"syscall/js.finalizeRef":n=>{n>>>=0;let o=this.mem.getUint32(n+8,!0);if(this._goRefCounts[o]--,this._goRefCounts[o]===0){let k=this._values[o];this._values[o]=null,this._ids.delete(k),this._idPool.push(o)}},"syscall/js.stringVal":n=>{n>>>=0,v(n+24,y(n+8))},"syscall/js.valueGet":n=>{n>>>=0;let o=Reflect.get(h(n+8),y(n+16));n=this._inst.exports.getsp()>>>0,v(n+32,o)},"syscall/js.valueSet":n=>{n>>>=0,Reflect.set(h(n+8),y(n+16),h(n+32))},"syscall/js.valueDelete":n=>{n>>>=0,Reflect.deleteProperty(h(n+8),y(n+16))},"syscall/js.valueIndex":n=>{n>>>=0,v(n+24,Reflect.get(h(n+8),f(n+16)))},"syscall/js.valueSetIndex":n=>{n>>>=0,Reflect.set(h(n+8),f(n+16),h(n+24))},"syscall/js.valueCall":n=>{n>>>=0;try{let o=h(n+8),k=Reflect.get(o,y(n+16)),T=u(n+32),V=Reflect.apply(k,o,T);n=this._inst.exports.getsp()>>>0,v(n+56,V),this.mem.setUint8(n+64,1)}catch(o){n=this._inst.exports.getsp()>>>0,v(n+56,o),this.mem.setUint8(n+64,0)}},"syscall/js.valueInvoke":n=>{n>>>=0;try{let o=h(n+8),k=u(n+16),T=Reflect.apply(o,void 0,k);n=this._inst.exports.getsp()>>>0,v(n+40,T),this.mem.setUint8(n+48,1)}catch(o){n=this._inst.exports.getsp()>>>0,v(n+40,o),this.mem.setUint8(n+48,0)}},"syscall/js.valueNew":n=>{n>>>=0;try{let o=h(n+8),k=u(n+16),T=Reflect.construct(o,k);n=this._inst.exports.getsp()>>>0,v(n+40,T),this.mem.setUint8(n+48,1)}catch(o){n=this._inst.exports.getsp()>>>0,v(n+40,o),this.mem.setUint8(n+48,0)}},"syscall/js.valueLength":n=>{n>>>=0,m(n+16,parseInt(h(n+8).length))},"syscall/js.valuePrepareString":n=>{n>>>=0;let o=O.encode(String(h(n+8)));v(n+16,o),m(n+24,o.length)},"syscall/js.valueLoadString":n=>{n>>>=0;let o=h(n+8);S(n+16).set(o)},"syscall/js.valueInstanceOf":n=>{n>>>=0,this.mem.setUint8(n+24,h(n+8)instanceof h(n+16)?1:0)},"syscall/js.copyBytesToGo":n=>{n>>>=0;let o=S(n+8),k=h(n+32);if(!(k instanceof Uint8Array||k instanceof Uint8ClampedArray)){this.mem.setUint8(n+48,0);return}let T=k.subarray(0,o.length);o.set(T),m(n+40,T.length),this.mem.setUint8(n+48,1)},"syscall/js.copyBytesToJS":n=>{n>>>=0;let o=h(n+8),k=S(n+16);if(!(o instanceof Uint8Array||o instanceof Uint8ClampedArray)){this.mem.setUint8(n+48,0);return}let T=k.subarray(0,o.length);o.set(T),m(n+40,T.length),this.mem.setUint8(n+48,1)},debug:n=>{console.log(n)}}}}run(m){return z(this,null,function*(){if(!(m instanceof WebAssembly.Instance))throw new Error("Go.run: WebAssembly.Instance expected");this._inst=m,this.mem=new DataView(this._inst.exports.mem.buffer),this._values=[NaN,0,null,!0,!1,A,this],this._goRefCounts=new Array(this._values.length).fill(1/0),this._ids=new Map([[0,1],[null,2],[!0,3],[!1,4],[A,5],[this,6]]),this._idPool=[],this.exited=!1;let l=4096,f=j=>{let I=l,n=O.encode(j+"\0");return new Uint8Array(this.mem.buffer,l,n.length).set(n),l+=n.length,l%8!==0&&(l+=8-l%8),I},h=this.argv.length,v=[];this.argv.forEach(j=>{v.push(f(j))}),v.push(0),Object.keys(this.env).sort().forEach(j=>{v.push(f(`${j}=${this.env[j]}`))}),v.push(0);let u=l;if(v.forEach(j=>{this.mem.setUint32(l,j,!0),this.mem.setUint32(l+4,0,!0),l+=8}),l>=12288)throw new Error("total length of command line and environment variables exceeds limit");this._inst.exports.run(h,u),this.exited&&this._resolveExitPromise(),yield this._exitPromise})}_resume(){if(this.exited)throw new Error("Go program has already exited");this._inst.exports.resume(),this.exited&&this._resolveExitPromise()}_makeFuncWrapper(m){let l=this;return function(){let f={id:m,this:this,args:arguments};return l._pendingEvent=f,l._resume(),f.result}}}})(),G=({data:C})=>{let O=new TextDecoder,b=A.fs,m="";b.writeSync=(S,u)=>{if(S===1)F(u);else if(S===2){m+=O.decode(u);let y=m.split(`
`);y.length>1&&console.log(y.slice(0,-1).join(`
`)),m=y[y.length-1]}else throw new Error("Bad write");return u.length};let l=[],f,h=0;G=({data:S})=>(S.length>0&&(l.push(S),f&&f()),v),b.read=(S,u,y,j,I,n)=>{if(S!==0||y!==0||j!==u.length||I!==null)throw new Error("Bad read");if(l.length===0){f=()=>b.read(S,u,y,j,I,n);return}let o=l[0],k=Math.max(0,Math.min(j,o.length-h));u.set(o.subarray(h,h+k),y),h+=k,h===o.length&&(l.shift(),h=0),n(null,k)};let v=new A.Go;return v.argv=["","--service=0.28.2"],H(C,v).then(S=>{F(null),v.run(S)},S=>{F(S)}),v};function H(C,O){return z(this,null,function*(){if(C instanceof WebAssembly.Module)return WebAssembly.instantiate(C,O.importObject);let b=yield fetch(C);if(!b.ok)throw new Error(`Failed to download ${JSON.stringify(C)}`);if("instantiateStreaming"in WebAssembly&&/^application\/wasm($|;)/i.test(b.headers.get("Content-Type")||""))return(yield WebAssembly.instantiateStreaming(b,O.importObject)).instance;let m=yield b.arrayBuffer();return(yield WebAssembly.instantiate(m,O.importObject)).instance})}return C=>G(C)})(F=>a.onmessage({data:F})),B;a={onmessage:null,postMessage:F=>setTimeout(()=>{try{B=P({data:F})}catch(z){g(z)}}),terminate(){if(B)for(let F of B._scheduledTimeouts.values())clearTimeout(F)}}}let d,E,i=new Promise((P,B)=>{d=P,E=B});a.onmessage=({data:P})=>{a.onmessage=({data:B})=>x(B),P?E(P):d()},a.postMessage(t||new URL(e,location.href).toString());let{readFromStdout:x,service:_}=_t({writeToStdin(P){a.postMessage(P)},isSync:!1,hasFS:!1,esbuild:ye});yield i,Ne=()=>{a.terminate(),ke=void 0,Ne=void 0,Fe=void 0},Fe={build:P=>new Promise((B,F)=>{w.then(F),_.buildOrContext({callName:"build",refs:null,options:P,isTTY:!1,defaultWD:"/",callback:(z,G)=>z?F(z):B(G)})}),context:P=>new Promise((B,F)=>{w.then(F),_.buildOrContext({callName:"context",refs:null,options:P,isTTY:!1,defaultWD:"/",callback:(z,G)=>z?F(z):B(G)})}),transform:(P,B)=>new Promise((F,z)=>{w.then(z),_.transform({callName:"transform",refs:null,input:P,options:B||{},isTTY:!1,fs:{readFile(G,A){A(new Error("Internal error"),null)},writeFile(G,A){A(null)}},callback:(G,A)=>G?z(G):F(A)})}),formatMessages:(P,B)=>new Promise((F,z)=>{w.then(z),_.formatMessages({callName:"formatMessages",refs:null,messages:P,options:B,callback:(G,A)=>G?z(G):F(A)})}),analyzeMetafile:(P,B)=>new Promise((F,z)=>{w.then(z),_.analyzeMetafile({callName:"analyzeMetafile",refs:null,metafile:typeof P=="string"?P:JSON.stringify(P),options:B,callback:(G,A)=>G?z(G):F(A)})})}}),Wt=ye})(typeof We=="object"?We:{set exports(c){(typeof self<"u"?self:this).esbuild=c}})});var Ye=Zt(ut(),1);function Ce(c){return!c||typeof c!="object"?!1:!Array.isArray(c)}function en(c,p,U){for(let M of c){let N=Se(M,p,U);if(N)return N}return null}function tn(c,p,U){for(let[M,N]of Object.entries(c)){if(!U.has(M))continue;let Y=Se(N,p,U);if(Y)return Y}return null}function Se(c,p,U){return typeof c=="string"?c.replaceAll("*",p??""):Array.isArray(c)?en(c,p,U):Ce(c)?tn(c,p,U):null}function nn(c,p){if(!(!p||p===".")){if(p!==".."){c.push(p);return}if(!c.length)throw new Error("Import escapes its source root");c.pop()}}function we(c){let p=[];for(let U of c.split("/"))nn(p,U);return p.join("/")}function ze(c,p){if(!c?.startsWith("./"))throw new Error(`Unsupported package export: ${p}`);return we(c)}function rn(c){return Ce(c)?Object.keys(c).some(p=>p.startsWith(".")):!1}var sn=(c,p)=>{let[U,M]=c.split("*");return p.startsWith(U)&&p.endsWith(M)},ln=(c,p)=>Object.keys(c).filter(U=>U.includes("*")).sort((U,M)=>M.length-U.length).find(U=>sn(U,p));function on(c,p,U){let M=ln(c,p);if(!M)throw new Error(`Package does not export ${p}`);let[N,Y]=M.split("*");return ze(Se(c[M],p.slice(N.length,p.length-Y.length),U),p)}function an(c){return typeof c.browser=="string"&&c.browser?c.browser:c.module||c.main||"index.js"}function cn(c,p,U){return Object.hasOwn(c,p)?ze(Se(c[p],void 0,U),p):on(c,p,U)}function Ge(c,p="",U="import"){let M=new Set(["browser",U,"default","production"]),N=c.exports;if(N===void 0)return we(p||an(c));let Y=p?`./${p}`:".";if(rn(N))return cn(N,Y,M);if(p)throw new Error(`Package does not export ${Y}`);return ze(Se(N,void 0,M),Y)}var Je=c=>c.split("/").slice(0,-1).join("/"),Ve=c=>c.split("/")[0],ft=c=>c.slice(c.indexOf("/")+1);function un(c,p){let U=c?.manifest.browser;if(!Ce(U))return{specifier:p.path};let M=p.path.startsWith(".")?"./"+we(Je(ft(p.importer))+"/"+p.path):p.path,N=U[M];return N===!1?{empty:!0,specifier:p.path}:typeof N!="string"?{specifier:p.path}:N.startsWith(".")?{local:`${Ve(p.importer)}/${we(N)}`,specifier:p.path}:{specifier:N}}function fn(c,p,U){return c.namespace!=="npm"?U("project",we(Je(c.importer)+"/"+p)):U("npm",`${Ve(c.importer)}/${we(Je(ft(c.importer))+"/"+p)}`)}function dn(c,p,U,M){return U?U.name===p?Ve(c.importer):U.dependencies[p]:M.roots[p]?.id}function hn(c,p,U,{lock:M,find:N}){let Y=p.split("/"),te=Y.splice(0,p.startsWith("@")?2:1).join("/"),ee=dn(c,te,U,M);if(!ee)throw new Error(`Uninstalled browser dependency: ${p}`);let Q=c.kind.startsWith("require")?"require":"import";return N("npm",`${ee}/${Ge(M.packages[ee].manifest,Y.join("/"),Q)}`)}async function dt(c,p,U){if(c.kind==="entry-point")return U("project",we(c.path));let M=c.namespace==="npm"?p.packages[Ve(c.importer)]:null,N=un(M,c);if(N.empty)return{path:N.specifier,namespace:"empty"};if(N.local)return U("npm",N.local);if(N.specifier.startsWith("."))return fn(c,N.specifier,U);if(/^(?:[a-z]+:|\/|#)/i.test(N.specifier))throw new Error(`Unsupported browser import: ${N.specifier}`);return hn(c,N.specifier,M,{lock:p,find:U})}var mn=new TextDecoder,pn=["",".tsx",".ts",".jsx",".js",".mjs",".cjs",".json",".css","/index.tsx","/index.ts","/index.js"],gn=new Map(Object.entries({mjs:"js",cjs:"js",js:"js",jsx:"jsx",ts:"ts",tsx:"tsx",css:"css",json:"json"}));async function wn(c,p,U){try{return await c(p,U)}catch(M){if(p!=="project")throw M;return}}function yn(c,p,U){let M=async(Y,te)=>{if(Y==="project")return p(te);let ee=te.indexOf("/");return c[te.slice(0,ee)]?.get(te.slice(ee+1))};return{read:M,find:async(Y,te)=>{for(let ee of pn){let Q=await wn(M,Y,te+ee);if(Q!==void 0)return U.set(`${Y}:${te+ee}`,Q),{path:te+ee,namespace:Y}}throw new Error(`Cannot resolve ${te}`)}}}function bn(c,p,U){let M=new Map,{read:N,find:Y}=yn(p,U,M),te=ee=>async Q=>{let ye=M.get(`${ee}:${Q.path}`)??await N(ee,Q.path),$e=gn.get(Q.path.split(".").pop());return{contents:$e?mn.decode(ye):ye,loader:$e??"file"}};return{name:"webfront-project",setup(ee){ee.onResolve({filter:/.*/},Q=>dt(Q,c,Y)),ee.onLoad({filter:/.*/,namespace:"empty"},()=>({contents:"",loader:"js"}));for(let Q of["project","npm"])ee.onLoad({filter:/.*/,namespace:Q},te(Q))}}}async function ht(c,{entry:p,lock:U,packages:M,readProject:N}){let Y=await c.build({entryPoints:[p],bundle:!0,write:!1,outdir:"/output",entryNames:"app",assetNames:"assets/[name]-[hash]",format:"esm",platform:"browser",target:"es2020",jsx:"automatic",minify:!0,define:{"process.env.NODE_ENV":'"production"'},legalComments:"inline",plugins:[bn(U,M,N)]});return new Map(Y.outputFiles.map(te=>[te.path.replace(/^\/output\//,""),te.contents]))}var qe=new Map,vn=0,xn=c=>new Promise((p,U)=>{let M=++vn;qe.set(M,{resolve:p,reject:U}),self.postMessage({type:"read",id:M,path:c})}),kn=Ye.initialize({wasmURL:new URL("./esbuild.wasm",import.meta.url).href,worker:!1});self.onmessage=async({data:c})=>{if(c.type==="read-result"){let p=qe.get(c.id);if(!p)return;qe.delete(c.id),c.error?p.reject(new Error(c.error)):p.resolve(c.bytes);return}if(c.type==="build")try{await kn;let p=await ht(Ye,{...c,readProject:xn});self.postMessage({type:"result",files:p})}catch(p){self.postMessage({type:"error",error:p.message})}};
