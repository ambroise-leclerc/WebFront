var ln=Object.create;var pt=Object.defineProperty;var on=Object.getOwnPropertyDescriptor;var an=Object.getOwnPropertyNames;var cn=Object.getPrototypeOf,un=Object.prototype.hasOwnProperty;var fn=(o,c)=>()=>{try{return c||o((c={exports:{}}).exports,c),c.exports}catch(v){throw c=0,v}};var dn=(o,c,v,I)=>{if(c&&typeof c=="object"||typeof c=="function")for(let M of an(c))!un.call(o,M)&&M!==v&&pt(o,M,{get:()=>c[M],enumerable:!(I=on(c,M))||I.enumerable});return o};var hn=(o,c,v)=>(v=o!=null?ln(cn(o)):{},dn(c||!o||!o.__esModule?pt(v,"default",{value:o,enumerable:!0}):v,o));var gt=fn((Fn,Ge)=>{(o=>{"use strict";var c=Object.defineProperty,v=Object.getOwnPropertyDescriptor,I=Object.getOwnPropertyNames,M=Object.prototype.hasOwnProperty,Y=(e,t)=>{for(var r in t)c(e,r,{get:t[r],enumerable:!0})},oe=(e,t,r,u)=>{if(t&&typeof t=="object"||typeof t=="function")for(let g of I(t))!M.call(e,g)&&g!==r&&c(e,g,{get:()=>t[g],enumerable:!(u=v(t,g))||u.enumerable});return e},ne=e=>oe(c({},"__esModule",{value:!0}),e),z=(e,t,r)=>new Promise((u,g)=>{var w=i=>{try{_(r.next(i))}catch(k){g(k)}},h=i=>{try{_(r.throw(i))}catch(k){g(k)}},_=i=>i.done?u(i.value):Promise.resolve(i.value).then(w,h);_((r=r.apply(e,t)).next())}),X={};Y(X,{analyzeMetafile:()=>Yt,analyzeMetafileSync:()=>Xt,build:()=>zt,buildSync:()=>Ht,context:()=>Jt,default:()=>nn,formatMessages:()=>qt,formatMessagesSync:()=>Qt,initialize:()=>en,stop:()=>Zt,transform:()=>Gt,transformSync:()=>Kt,version:()=>Wt}),o.exports=ne(X);function H(e){let t=u=>{if(u===null)r.write8(0);else if(typeof u=="boolean")r.write8(1),r.write8(+u);else if(typeof u=="number")r.write8(2),r.write32(u|0);else if(typeof u=="string")r.write8(3),r.write(fe(u));else if(u instanceof Uint8Array)r.write8(4),r.write(u);else if(u instanceof Array){r.write8(5),r.write32(u.length);for(let g of u)t(g)}else{let g=Object.keys(u);r.write8(6),r.write32(g.length);for(let w of g)r.write(fe(w)),t(u[w])}},r=new Oe;return r.write32(0),r.write32(e.id<<1|+!e.isRequest),t(e.value),Je(r.buf,r.len-4,0),r.buf.subarray(0,r.len)}function me(e){let t=()=>{switch(r.read8()){case 0:return null;case 1:return!!r.read8();case 2:return r.read32();case 3:return xe(r.read());case 4:return r.read();case 5:{let h=r.read32(),_=[];for(let i=0;i<h;i++)_.push(t());return _}case 6:{let h=r.read32(),_={};for(let i=0;i<h;i++)_[xe(r.read())]=t();return _}default:throw new Error("Invalid packet")}},r=new Oe(e),u=r.read32(),g=(u&1)===0;u>>>=1;let w=t();if(r.ptr!==e.length)throw new Error("Invalid packet");return{id:u,isRequest:g,value:w}}var Oe=class{constructor(e=new Uint8Array(1024)){this.buf=e,this.len=0,this.ptr=0}_write(e){if(this.len+e>this.buf.length){let t=new Uint8Array((this.len+e)*2);t.set(this.buf),this.buf=t}return this.len+=e,this.len-e}write8(e){let t=this._write(1);this.buf[t]=e}write32(e){let t=this._write(4);Je(this.buf,e,t)}write(e){let t=this._write(4+e.length);Je(this.buf,e.length,t),this.buf.set(e,t+4)}_read(e){if(this.ptr+e>this.buf.length)throw new Error("Invalid packet");return this.ptr+=e,this.ptr-e}read8(){return this.buf[this._read(1)]}read32(){return nt(this.buf,this._read(4))}read(){let e=this.read32(),t=new Uint8Array(e),r=this._read(t.length);return t.set(this.buf.subarray(r,r+e)),t}},fe,xe,ze;if(typeof TextEncoder<"u"&&typeof TextDecoder<"u"){let e=new TextEncoder,t=new TextDecoder;fe=r=>e.encode(r),xe=r=>t.decode(r),ze='new TextEncoder().encode("")'}else if(typeof Buffer<"u")fe=e=>Buffer.from(e),xe=e=>{let{buffer:t,byteOffset:r,byteLength:u}=e;return Buffer.from(t,r,u).toString()},ze='Buffer.from("")';else throw new Error("No UTF-8 codec found");if(!(fe("")instanceof Uint8Array))throw new Error(`Invariant violation: "${ze} instanceof Uint8Array" is incorrectly false

This indicates that your JavaScript environment is broken. You cannot use
esbuild in this environment because esbuild relies on this invariant. This
is not a problem with esbuild. You need to fix your environment instead.
`);function nt(e,t){return(e[t++]|e[t++]<<8|e[t++]<<16|e[t++]<<24)>>>0}function Je(e,t,r){e[r++]=t,e[r++]=t>>8,e[r++]=t>>16,e[r++]=t>>24}var pe=String.fromCharCode;function ae(e,t,r){let u=e[t],g=1,w=0;for(let h=0;h<t;h++)e[h]===10?(g++,w=0):w++;throw new SyntaxError(r||(t===e.length?"Unexpected end of input while parsing JSON":u>=32&&u<=126?`Unexpected character ${pe(u)} in JSON at position ${t} (line ${g}, column ${w})`:`Unexpected byte 0x${u.toString(16)} in JSON at position ${t} (line ${g}, column ${w})`))}function Pt(e){if(!(e instanceof Uint8Array))throw new Error("JSON input must be a Uint8Array");let t=[],r=[],u=[],g=e.length,w=null,h=0,_,i=0;for(;i<g;){let k=e[i++];if(k<=32)continue;let j;switch(h===2&&w===null&&k!==34&&k!==125&&ae(e,--i),k){case 116:{(e[i++]!==114||e[i++]!==117||e[i++]!==101)&&ae(e,--i),j=!0;break}case 102:{(e[i++]!==97||e[i++]!==108||e[i++]!==115||e[i++]!==101)&&ae(e,--i),j=!1;break}case 110:{(e[i++]!==117||e[i++]!==108||e[i++]!==108)&&ae(e,--i),j=null;break}case 45:case 46:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:{let O=i;for(j=pe(k),k=e[i];;){switch(k){case 43:case 45:case 46:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:case 101:case 69:{j+=pe(k),k=e[++i];continue}}break}j=+j,isNaN(j)&&ae(e,--O,"Invalid number");break}case 34:{for(j="";i>=g&&ae(e,g),k=e[i++],k!==34;)if(k===92)switch(e[i++]){case 34:j+='"';break;case 47:j+="/";break;case 92:j+="\\";break;case 98:j+="\b";break;case 102:j+="\f";break;case 110:j+=`
`;break;case 114:j+="\r";break;case 116:j+="	";break;case 117:{let O=0;for(let B=0;B<4;B++)k=e[i++],O<<=4,k>=48&&k<=57?O|=k-48:k>=97&&k<=102?O|=k+-87:k>=65&&k<=70?O|=k+-55:ae(e,--i);j+=pe(O);break}default:ae(e,--i);break}else if(k<=127)j+=pe(k);else if((k&224)===192)j+=pe((k&31)<<6|e[i++]&63);else if((k&240)===224)j+=pe((k&15)<<12|(e[i++]&63)<<6|e[i++]&63);else if((k&248)==240){let O=(k&7)<<18|(e[i++]&63)<<12|(e[i++]&63)<<6|e[i++]&63;O>65535&&(O-=65536,j+=pe(O>>10&1023|55296),O=56320|O&1023),j+=pe(O)}j[0];break}case 91:{j=[],t.push(w),r.push(_),u.push(h),w=null,_=j,h=1;continue}case 123:{j={},t.push(w),r.push(_),u.push(h),w=null,_=j,h=2;continue}case 93:{h!==1&&ae(e,--i),j=_,w=t.pop(),_=r.pop(),h=u.pop();break}case 125:{h!==2&&ae(e,--i),j=_,w=t.pop(),_=r.pop(),h=u.pop();break}default:ae(e,--i)}for(k=e[i];k<=32;)k=e[++i];switch(h){case 0:{if(i===g)return j;break}case 1:{if(_.push(j),k===44){i++;continue}if(k===93)continue;break}case 2:{if(w===null){if(w=j,k===58){i++;continue}}else{if(_[w]=j,w=null,k===44){i++;continue}if(k===125)continue}break}}break}ae(e,i)}var te=JSON.stringify,rt="warning",st="silent";function je(e,t){let r=[];for(let u of e){if(se(u,t),u.indexOf(",")>=0)throw new Error(`Invalid ${t}: ${u}`);r.push(u)}return r.join(",")}var Ue=()=>null,K=e=>typeof e=="boolean"?null:"a boolean",U=e=>typeof e=="string"?null:"a string",De=e=>e instanceof RegExp?null:"a RegExp object",ke=e=>typeof e=="number"&&e===(e|0)?null:"an integer",Ot=e=>typeof e=="number"&&e===(e|0)&&e>=0&&e<=65535?null:"a valid port number",it=e=>typeof e=="function"?null:"a function",ge=e=>Array.isArray(e)?null:"an array",re=e=>Array.isArray(e)&&e.every(t=>typeof t=="string")?null:"an array of strings",le=e=>typeof e=="object"&&e!==null&&!Array.isArray(e)?null:"an object",Tt=e=>typeof e=="object"&&e!==null?null:"an array or an object",Ct=e=>e instanceof WebAssembly.Module?null:"a WebAssembly.Module",lt=e=>typeof e=="object"&&!Array.isArray(e)?null:"an object or null",ot=e=>typeof e=="string"||typeof e=="boolean"?null:"a string or a boolean",At=e=>typeof e=="string"||typeof e=="object"&&e!==null&&!Array.isArray(e)?null:"a string or an object",at=e=>typeof e=="string"||Array.isArray(e)&&e.every(t=>typeof t=="string")?null:"a string or an array of strings",ct=e=>typeof e=="string"||e instanceof Uint8Array?null:"a string or a Uint8Array",Rt=e=>typeof e=="string"||e instanceof URL?null:"a string or a URL";function s(e,t,r,u){let g=e[r];if(t[r+""]=!0,g===void 0)return;let w=u(g);if(w!==null)throw new Error(`${te(r)} must be ${w}`);return g}function Z(e,t,r){for(let u in e)if(!(u in t))throw new Error(`Invalid option ${r}: ${te(u)}`)}function Ut(e){let t=Object.create(null),r=s(e,t,"wasmURL",Rt),u=s(e,t,"wasmModule",Ct),g=s(e,t,"worker",K);return Z(e,t,"in initialize() call"),{wasmURL:r,wasmModule:u,worker:g}}function ut(e){let t;if(e!==void 0){t=Object.create(null);for(let r in e){let u=e[r];if(typeof u=="string"||u===!1)t[r]=u;else throw new Error(`Expected ${te(r)} in mangle cache to map to either a string or false`)}}return t}function Ie(e,t,r,u,g){let w=s(t,r,"color",K),h=s(t,r,"logLevel",U),_=s(t,r,"logLimit",ke),i=s(t,r,"logStyle",U);w!==void 0?e.push(`--color=${w}`):u&&e.push("--color=true"),e.push(`--log-level=${h||g}`),e.push(`--log-limit=${_||0}`),i&&e.push(`--log-style=${i}`)}function se(e,t,r){if(typeof e!="string")throw new Error(`Expected value for ${t}${r!==void 0?" "+te(r):""} to be a string, got ${typeof e} instead`);return e}function ft(e,t,r){let u=s(t,r,"legalComments",U),g=s(t,r,"sourceRoot",U),w=s(t,r,"sourcesContent",K),h=s(t,r,"target",at),_=s(t,r,"format",U),i=s(t,r,"globalName",U),k=s(t,r,"mangleProps",De),j=s(t,r,"reserveProps",De),O=s(t,r,"mangleQuoted",K),B=s(t,r,"minify",K),F=s(t,r,"minifySyntax",K),J=s(t,r,"minifyWhitespace",K),G=s(t,r,"minifyIdentifiers",K),R=s(t,r,"lineLimit",ke),Q=s(t,r,"drop",re),A=s(t,r,"dropLabels",re),C=s(t,r,"charset",U),b=s(t,r,"treeShaking",K),p=s(t,r,"ignoreAnnotations",K),l=s(t,r,"jsx",U),d=s(t,r,"jsxFactory",U),m=s(t,r,"jsxFragment",U),x=s(t,r,"jsxImportSource",U),$=s(t,r,"jsxDev",K),f=s(t,r,"jsxSideEffects",K),y=s(t,r,"define",le),S=s(t,r,"logOverride",le),N=s(t,r,"supported",le),n=s(t,r,"pure",re),a=s(t,r,"keepNames",K),E=s(t,r,"platform",U),T=s(t,r,"tsconfigRaw",At),V=s(t,r,"absPaths",re);if(u&&e.push(`--legal-comments=${u}`),g!==void 0&&e.push(`--source-root=${g}`),w!==void 0&&e.push(`--sources-content=${w}`),h&&e.push(`--target=${je(Array.isArray(h)?h:[h],"target")}`),_&&e.push(`--format=${_}`),i&&e.push(`--global-name=${i}`),E&&e.push(`--platform=${E}`),T&&e.push(`--tsconfig-raw=${typeof T=="string"?T:JSON.stringify(T)}`),B&&e.push("--minify"),F&&e.push("--minify-syntax"),J&&e.push("--minify-whitespace"),G&&e.push("--minify-identifiers"),R&&e.push(`--line-limit=${R}`),C&&e.push(`--charset=${C}`),b!==void 0&&e.push(`--tree-shaking=${b}`),p&&e.push("--ignore-annotations"),Q)for(let P of Q)e.push(`--drop:${se(P,"drop")}`);if(A&&e.push(`--drop-labels=${je(A,"drop label")}`),V&&e.push(`--abs-paths=${je(V,"abs paths")}`),k&&e.push(`--mangle-props=${Fe(k)}`),j&&e.push(`--reserve-props=${Fe(j)}`),O!==void 0&&e.push(`--mangle-quoted=${O}`),l&&e.push(`--jsx=${l}`),d&&e.push(`--jsx-factory=${d}`),m&&e.push(`--jsx-fragment=${m}`),x&&e.push(`--jsx-import-source=${x}`),$&&e.push("--jsx-dev"),f&&e.push("--jsx-side-effects"),y)for(let P in y){if(P.indexOf("=")>=0)throw new Error(`Invalid define: ${P}`);e.push(`--define:${P}=${se(y[P],"define",P)}`)}if(S)for(let P in S){if(P.indexOf("=")>=0)throw new Error(`Invalid log override: ${P}`);e.push(`--log-override:${P}=${se(S[P],"log override",P)}`)}if(N)for(let P in N){if(P.indexOf("=")>=0)throw new Error(`Invalid supported: ${P}`);let q=N[P];if(typeof q!="boolean")throw new Error(`Expected value for supported ${te(P)} to be a boolean, got ${typeof q} instead`);e.push(`--supported:${P}=${q}`)}if(n)for(let P of n)e.push(`--pure:${se(P,"pure")}`);a&&e.push("--keep-names")}function Dt(e,t,r,u,g){var w;let h=[],_=[],i=Object.create(null),k=null,j=null;Ie(h,t,i,r,u),ft(h,t,i);let O=s(t,i,"sourcemap",ot),B=s(t,i,"bundle",K),F=s(t,i,"splitting",K),J=s(t,i,"preserveSymlinks",K),G=s(t,i,"metafile",K),R=s(t,i,"outfile",U),Q=s(t,i,"outdir",U),A=s(t,i,"outbase",U),C=s(t,i,"tsconfig",U),b=s(t,i,"resolveExtensions",re),p=s(t,i,"nodePaths",re),l=s(t,i,"mainFields",re),d=s(t,i,"conditions",re),m=s(t,i,"external",re),x=s(t,i,"packages",U),$=s(t,i,"alias",le),f=s(t,i,"loader",le),y=s(t,i,"outExtension",le),S=s(t,i,"publicPath",U),N=s(t,i,"entryNames",U),n=s(t,i,"chunkNames",U),a=s(t,i,"assetNames",U),E=s(t,i,"inject",re),T=s(t,i,"banner",le),V=s(t,i,"footer",le),P=s(t,i,"entryPoints",Tt),q=s(t,i,"absWorkingDir",U),W=s(t,i,"stdin",le),L=(w=s(t,i,"write",K))!=null?w:g,ie=s(t,i,"allowOverwrite",K),ee=s(t,i,"mangleCache",le);if(i.plugins=!0,Z(t,i,`in ${e}() call`),O&&h.push(`--sourcemap${O===!0?"":`=${O}`}`),B&&h.push("--bundle"),ie&&h.push("--allow-overwrite"),F&&h.push("--splitting"),J&&h.push("--preserve-symlinks"),G&&h.push("--metafile"),R&&h.push(`--outfile=${R}`),Q&&h.push(`--outdir=${Q}`),A&&h.push(`--outbase=${A}`),C&&h.push(`--tsconfig=${C}`),x&&h.push(`--packages=${x}`),b&&h.push(`--resolve-extensions=${je(b,"resolve extension")}`),S&&h.push(`--public-path=${S}`),N&&h.push(`--entry-names=${N}`),n&&h.push(`--chunk-names=${n}`),a&&h.push(`--asset-names=${a}`),l&&h.push(`--main-fields=${je(l,"main field")}`),d&&h.push(`--conditions=${je(d,"condition")}`),m)for(let D of m)h.push(`--external:${se(D,"external")}`);if($)for(let D in $){if(D.indexOf("=")>=0)throw new Error(`Invalid package name in alias: ${D}`);h.push(`--alias:${D}=${se($[D],"alias",D)}`)}if(T)for(let D in T){if(D.indexOf("=")>=0)throw new Error(`Invalid banner file type: ${D}`);h.push(`--banner:${D}=${se(T[D],"banner",D)}`)}if(V)for(let D in V){if(D.indexOf("=")>=0)throw new Error(`Invalid footer file type: ${D}`);h.push(`--footer:${D}=${se(V[D],"footer",D)}`)}if(E)for(let D of E)h.push(`--inject:${se(D,"inject")}`);if(f)for(let D in f){if(D.indexOf("=")>=0)throw new Error(`Invalid loader extension: ${D}`);h.push(`--loader:${D}=${se(f[D],"loader",D)}`)}if(y)for(let D in y){if(D.indexOf("=")>=0)throw new Error(`Invalid out extension: ${D}`);h.push(`--out-extension:${D}=${se(y[D],"out extension",D)}`)}if(P)if(Array.isArray(P))for(let D=0,be=P.length;D<be;D++){let ce=P[D];if(typeof ce=="object"&&ce!==null){let de=Object.create(null),ve=s(ce,de,"in",U),ue=s(ce,de,"out",U);if(Z(ce,de,"in entry point at index "+D),ve===void 0)throw new Error('Missing property "in" for entry point at index '+D);if(ue===void 0)throw new Error('Missing property "out" for entry point at index '+D);_.push([ue,ve])}else _.push(["",se(ce,"entry point at index "+D)])}else for(let D in P)_.push([D,se(P[D],"entry point",D)]);if(W){let D=Object.create(null),be=s(W,D,"contents",ct),ce=s(W,D,"resolveDir",U),de=s(W,D,"sourcefile",U),ve=s(W,D,"loader",U);Z(W,D,'in "stdin" object'),de&&h.push(`--sourcefile=${de}`),ve&&h.push(`--loader=${ve}`),ce&&(j=ce),typeof be=="string"?k=fe(be):be instanceof Uint8Array&&(k=be)}let ye=[];if(p)for(let D of p)D+="",ye.push(D);return{entries:_,flags:h,write:L,stdinContents:k,stdinResolveDir:j,absWorkingDir:q,nodePaths:ye,mangleCache:ut(ee)}}function It(e,t,r,u){let g=[],w=Object.create(null);Ie(g,t,w,r,u),ft(g,t,w);let h=s(t,w,"sourcemap",ot),_=s(t,w,"sourcefile",U),i=s(t,w,"loader",U),k=s(t,w,"banner",U),j=s(t,w,"footer",U),O=s(t,w,"mangleCache",le);return Z(t,w,`in ${e}() call`),h&&g.push(`--sourcemap=${h===!0?"external":h}`),_&&g.push(`--sourcefile=${_}`),i&&g.push(`--loader=${i}`),k&&g.push(`--banner=${k}`),j&&g.push(`--footer=${j}`),{flags:g,mangleCache:ut(O)}}function Mt(e){let t={},r={didClose:!1,reason:""},u={},g=0,w=0,h=new Uint8Array(16*1024),_=0,i=C=>{let b=_+C.length;if(b>h.length){let l=new Uint8Array(b*2);l.set(h),h=l}h.set(C,_),_+=C.length;let p=0;for(;p+4<=_;){let l=nt(h,p);if(p+4+l>_)break;p+=4,J(h.subarray(p,p+l)),p+=l}p>0&&(h.copyWithin(0,p,_),_-=p)},k=C=>{r.didClose=!0,C&&(r.reason=": "+(C.message||C));let b="The service was stopped"+r.reason;for(let p in u)u[p](b,null);u={}},j=(C,b,p)=>{if(r.didClose)return p("The service is no longer running"+r.reason,null);let l=g++;u[l]=(d,m)=>{try{p(d,m)}finally{C&&C.unref()}},C&&C.ref(),e.writeToStdin(H({id:l,isRequest:!0,value:b}))},O=(C,b)=>{if(r.didClose)throw new Error("The service is no longer running"+r.reason);e.writeToStdin(H({id:C,isRequest:!1,value:b}))},B=(C,b)=>z(null,null,function*(){try{if(b.command==="ping"){O(C,{});return}if(typeof b.key=="number"){let p=t[b.key];if(!p)return;let l=p[b.command];if(l){yield l(C,b);return}}throw new Error("Invalid command: "+b.command)}catch(p){let l=[Ee(p,e,null,void 0,"")];try{O(C,{errors:l})}catch{}}}),F=!0,J=C=>{if(F){F=!1;let p=String.fromCharCode(...C);if(p!=="0.28.2")throw new Error(`Cannot start service: Host version "0.28.2" does not match binary version ${te(p)}`);return}let b=me(C);if(b.isRequest)B(b.id,b.value);else{let p=u[b.id];delete u[b.id],b.value.error?p(b.value.error,{}):p(null,b.value)}};return{readFromStdout:i,afterClose:k,service:{buildOrContext:({callName:C,refs:b,options:p,isTTY:l,defaultWD:d,callback:m})=>{let x=0,$=w++,f={},y={ref(){++x===1&&b&&b.ref()},unref(){--x===0&&(delete t[$],b&&b.unref())}};t[$]=f,y.ref(),Nt(C,$,j,O,y,e,f,p,l,d,(S,N)=>{try{m(S,N)}finally{y.unref()}})},transform:({callName:C,refs:b,input:p,options:l,isTTY:d,fs:m,callback:x})=>{let $=dt(),f=y=>{try{if(typeof p!="string"&&!(p instanceof Uint8Array))throw new Error('The input to "transform" must be a string or a Uint8Array');let{flags:S,mangleCache:N}=It(C,l,d,st),n={command:"transform",flags:S,inputFS:y!==null,input:y!==null?fe(y):typeof p=="string"?fe(p):p};N&&(n.mangleCache=N),j(b,n,(a,E)=>{if(a)return x(new Error(a),null);let T=Se(E.errors,$),V=Se(E.warnings,$),P=1,q=()=>{if(--P===0){let W={warnings:V,code:E.code,map:E.map,mangleCache:void 0,legalComments:void 0};"legalComments"in E&&(W.legalComments=E?.legalComments),E.mangleCache&&(W.mangleCache=E?.mangleCache),x(null,W)}};if(T.length>0)return x(Te("Transform failed",T,V),null);E.codeFS&&(P++,m.readFile(E.code,(W,L)=>{W!==null?x(W,null):(E.code=L,q())})),E.mapFS&&(P++,m.readFile(E.map,(W,L)=>{W!==null?x(W,null):(E.map=L,q())})),q()})}catch(S){let N=[];try{Ie(N,l,{},d,st)}catch{}let n=Ee(S,e,$,void 0,"");j(b,{command:"error",flags:N,error:n},()=>{n.detail=$.load(n.detail),x(Te("Transform failed",[n],[]),null)})}};if((typeof p=="string"||p instanceof Uint8Array)&&p.length>1024*1024){let y=f;f=()=>m.writeFile(p,y)}f(null)},formatMessages:({callName:C,refs:b,messages:p,options:l,callback:d})=>{if(!l)throw new Error(`Missing second argument in ${C}() call`);let m={},x=s(l,m,"kind",U),$=s(l,m,"color",K),f=s(l,m,"terminalWidth",ke),y=s(l,m,"logStyle",U);if(Z(l,m,`in ${C}() call`),x===void 0)throw new Error(`Missing "kind" in ${C}() call`);if(x!=="error"&&x!=="warning")throw new Error(`Expected "kind" to be "error" or "warning" in ${C}() call`);let S={command:"format-msgs",messages:we(p,"messages",null,"",f),isWarning:x==="warning"};$!==void 0&&(S.color=$),f!==void 0&&(S.terminalWidth=f),y!==void 0&&(S.logStyle=y),j(b,S,(N,n)=>{if(N)return d(new Error(N),null);d(null,n.messages)})},analyzeMetafile:({callName:C,refs:b,metafile:p,options:l,callback:d})=>{l===void 0&&(l={});let m={},x=s(l,m,"color",K),$=s(l,m,"verbose",K);Z(l,m,`in ${C}() call`);let f={command:"analyze-metafile",metafile:p};x!==void 0&&(f.color=x),$!==void 0&&(f.verbose=$),j(b,f,(y,S)=>{if(y)return d(new Error(y),null);d(null,S.result)})}}}}function Nt(e,t,r,u,g,w,h,_,i,k,j){let O=dt(),B=e==="context",F=(R,Q)=>{let A=[];try{Ie(A,_,{},i,rt)}catch{}let C=Ee(R,w,O,void 0,Q);r(g,{command:"error",flags:A,error:C},()=>{C.detail=O.load(C.detail),j(Te(B?"Context failed":"Build failed",[C],[]),null)})},J;if(typeof _=="object"){let R=_.plugins;if(R!==void 0){if(!Array.isArray(R))return F(new Error('"plugins" must be an array'),"");J=R}}if(J&&J.length>0){if(w.isSync)return F(new Error("Cannot use plugins in synchronous API calls"),"");Ft(t,r,u,g,w,h,_,J,O).then(R=>{if(!R.ok)return F(R.error,R.pluginName);try{G(R.requestPlugins,R.runOnEndCallbacks,R.scheduleOnDisposeCallbacks)}catch(Q){F(Q,"")}},R=>F(R,""));return}try{G(null,(R,Q)=>Q([],[]),()=>{})}catch(R){F(R,"")}function G(R,Q,A){let C=w.hasFS,{entries:b,flags:p,write:l,stdinContents:d,stdinResolveDir:m,absWorkingDir:x,nodePaths:$,mangleCache:f}=Dt(e,_,i,rt,C);if(l&&!w.hasFS)throw new Error('The "write" option is unavailable in this environment');let y={command:"build",key:t,entries:b,flags:p,write:l,stdinContents:d,stdinResolveDir:m,absWorkingDir:x||k,nodePaths:$,context:B};R&&(y.plugins=R),f&&(y.mangleCache=f);let S=(a,E)=>{let T={errors:Se(a.errors,O),warnings:Se(a.warnings,O),outputFiles:void 0,metafile:void 0,mangleCache:void 0},V=T.errors.slice(),P=T.warnings.slice();a.outputFiles&&(T.outputFiles=a.outputFiles.map(Lt)),a.metafile&&a.metafile.length&&(T.metafile=Bt(a.metafile)),a.mangleCache&&(T.mangleCache=a.mangleCache),a.writeToStdout!==void 0&&console.log(xe(a.writeToStdout).replace(/\n$/,"")),Q(T,(q,W)=>{if(V.length>0||q.length>0){let L=Te("Build failed",V.concat(q),P.concat(W));return E(L,null,q,W)}E(null,T,q,W)})},N,n;B&&(h["on-end"]=(a,E)=>new Promise(T=>{S(E,(V,P,q,W)=>{let L={errors:q,warnings:W};n&&n(V,P),N=void 0,n=void 0,u(a,L),T()})})),r(g,y,(a,E)=>{if(a)return j(new Error(a),null);if(!B)return S(E,(P,q)=>(A(),j(P,q)));if(E.errors.length>0)return j(Te("Context failed",E.errors,E.warnings),null);let T=!1,V={rebuild:()=>(N||(N=new Promise((P,q)=>{let W;n=(ie,ee)=>{W||(W=()=>ie?q(ie):P(ee))};let L=()=>{r(g,{command:"rebuild",key:t},(ee,ye)=>{ee?q(new Error(ee)):W?W():L()})};L()})),N),watch:(P={})=>new Promise((q,W)=>{if(!w.hasFS)throw new Error('Cannot use the "watch" API in this environment');let L={},ie=s(P,L,"delay",ke);Z(P,L,"in watch() call");let ee={command:"watch",key:t};ie&&(ee.delay=ie),r(g,ee,ye=>{ye?W(new Error(ye)):q(void 0)})}),serve:(P={})=>new Promise((q,W)=>{if(!w.hasFS)throw new Error('Cannot use the "serve" API in this environment');let L={},ie=s(P,L,"port",Ot),ee=s(P,L,"host",U),ye=s(P,L,"servedir",U),D=s(P,L,"keyfile",U),be=s(P,L,"certfile",U),ce=s(P,L,"fallback",U),de=s(P,L,"cors",le),ve=s(P,L,"onRequest",it);Z(P,L,"in serve() call");let ue={command:"serve",key:t,onRequest:!!ve};if(ie!==void 0&&(ue.port=ie),ee!==void 0&&(ue.host=ee),ye!==void 0&&(ue.servedir=ye),D!==void 0&&(ue.keyfile=D),be!==void 0&&(ue.certfile=be),ce!==void 0&&(ue.fallback=ce),de){let Ae={},$e=s(de,Ae,"origin",at);Z(de,Ae,'on "cors" object'),Array.isArray($e)?ue.corsOrigin=$e:$e!==void 0&&(ue.corsOrigin=[$e])}r(g,ue,(Ae,$e)=>{if(Ae)return W(new Error(Ae));ve&&(h["serve-request"]=(rn,sn)=>{ve(sn.args),u(rn,{})}),q($e)})}),cancel:()=>new Promise(P=>{if(T)return P();r(g,{command:"cancel",key:t},()=>{P()})}),dispose:()=>new Promise(P=>{if(T)return P();T=!0,r(g,{command:"dispose",key:t},()=>{P(),A(),g.unref()})})};g.ref(),j(null,V)})}}var Ft=(e,t,r,u,g,w,h,_,i)=>z(null,null,function*(){let k=[],j=[],O={},B={},F=[],J=0,G=0,R=[],Q=!1;_=[..._];for(let b of _){let p={};if(typeof b!="object")throw new Error(`Plugin at index ${G} must be an object`);let l=s(b,p,"name",U);if(typeof l!="string"||l==="")throw new Error(`Plugin at index ${G} is missing a name`);try{let d=s(b,p,"setup",it);if(typeof d!="function")throw new Error("Plugin is missing a setup function");Z(b,p,`on plugin ${te(l)}`);let m={name:l,onStart:!1,onEnd:!1,onResolve:[],onLoad:[]};G++;let $=d({initialOptions:h,resolve:(f,y={})=>{if(!Q)throw new Error('Cannot call "resolve" before plugin setup has completed');if(typeof f!="string")throw new Error("The path to resolve must be a string");let S=Object.create(null),N=s(y,S,"pluginName",U),n=s(y,S,"importer",U),a=s(y,S,"namespace",U),E=s(y,S,"resolveDir",U),T=s(y,S,"kind",U),V=s(y,S,"pluginData",Ue),P=s(y,S,"with",le);return Z(y,S,"in resolve() call"),new Promise((q,W)=>{let L={command:"resolve",path:f,key:e,pluginName:l};if(N!=null&&(L.pluginName=N),n!=null&&(L.importer=n),a!=null&&(L.namespace=a),E!=null&&(L.resolveDir=E),T!=null)L.kind=T;else throw new Error('Must specify "kind" when calling "resolve"');V!=null&&(L.pluginData=i.store(V)),P!=null&&(L.with=Vt(P,"with")),t(u,L,(ie,ee)=>{ie!==null?W(new Error(ie)):q({errors:Se(ee.errors,i),warnings:Se(ee.warnings,i),path:ee.path,external:ee.external,sideEffects:ee.sideEffects,namespace:ee.namespace,suffix:ee.suffix,pluginData:i.load(ee.pluginData)})})})},onStart(f){let y='This error came from the "onStart" callback registered here:',S=Me(new Error(y),g,"onStart");k.push({name:l,callback:f,note:S}),m.onStart=!0},onEnd(f){let y='This error came from the "onEnd" callback registered here:',S=Me(new Error(y),g,"onEnd");j.push({name:l,callback:f,note:S}),m.onEnd=!0},onResolve(f,y){let S='This error came from the "onResolve" callback registered here:',N=Me(new Error(S),g,"onResolve"),n={},a=s(f,n,"filter",De),E=s(f,n,"namespace",U);if(Z(f,n,`in onResolve() call for plugin ${te(l)}`),a==null)throw new Error("onResolve() call is missing a filter");let T=J++;O[T]={name:l,callback:y,note:N},m.onResolve.push({id:T,filter:Fe(a),namespace:E||""})},onLoad(f,y){let S='This error came from the "onLoad" callback registered here:',N=Me(new Error(S),g,"onLoad"),n={},a=s(f,n,"filter",De),E=s(f,n,"namespace",U);if(Z(f,n,`in onLoad() call for plugin ${te(l)}`),a==null)throw new Error("onLoad() call is missing a filter");let T=J++;B[T]={name:l,callback:y,note:N},m.onLoad.push({id:T,filter:Fe(a),namespace:E||""})},onDispose(f){F.push(f)},esbuild:g.esbuild});$&&(yield $),R.push(m)}catch(d){return{ok:!1,error:d,pluginName:l}}}w["on-start"]=(b,p)=>z(null,null,function*(){i.clear();let l={errors:[],warnings:[]};yield Promise.all(k.map(d=>z(null,[d],function*({name:m,callback:x,note:$}){try{let f=yield x();if(f!=null){if(typeof f!="object")throw new Error(`Expected onStart() callback in plugin ${te(m)} to return an object`);let y={},S=s(f,y,"errors",ge),N=s(f,y,"warnings",ge);Z(f,y,`from onStart() callback in plugin ${te(m)}`),S!=null&&l.errors.push(...we(S,"errors",i,m,void 0)),N!=null&&l.warnings.push(...we(N,"warnings",i,m,void 0))}}catch(f){l.errors.push(Ee(f,g,i,$&&$(),m))}}))),r(b,l)}),w["on-resolve"]=(b,p)=>z(null,null,function*(){let l={},d="",m,x;for(let $ of p.ids)try{({name:d,callback:m,note:x}=O[$]);let f=yield m({path:p.path,importer:p.importer,namespace:p.namespace,resolveDir:p.resolveDir,kind:p.kind,pluginData:i.load(p.pluginData),with:p.with});if(f!=null){if(typeof f!="object")throw new Error(`Expected onResolve() callback in plugin ${te(d)} to return an object`);let y={},S=s(f,y,"pluginName",U),N=s(f,y,"path",U),n=s(f,y,"namespace",U),a=s(f,y,"suffix",U),E=s(f,y,"external",K),T=s(f,y,"sideEffects",K),V=s(f,y,"pluginData",Ue),P=s(f,y,"errors",ge),q=s(f,y,"warnings",ge),W=s(f,y,"watchFiles",re),L=s(f,y,"watchDirs",re);Z(f,y,`from onResolve() callback in plugin ${te(d)}`),l.id=$,S!=null&&(l.pluginName=S),N!=null&&(l.path=N),n!=null&&(l.namespace=n),a!=null&&(l.suffix=a),E!=null&&(l.external=E),T!=null&&(l.sideEffects=T),V!=null&&(l.pluginData=i.store(V)),P!=null&&(l.errors=we(P,"errors",i,d,void 0)),q!=null&&(l.warnings=we(q,"warnings",i,d,void 0)),W!=null&&(l.watchFiles=Ne(W,"watchFiles")),L!=null&&(l.watchDirs=Ne(L,"watchDirs"));break}}catch(f){l={id:$,errors:[Ee(f,g,i,x&&x(),d)]};break}r(b,l)}),w["on-load"]=(b,p)=>z(null,null,function*(){let l={},d="",m,x;for(let $ of p.ids)try{({name:d,callback:m,note:x}=B[$]);let f=yield m({path:p.path,namespace:p.namespace,suffix:p.suffix,pluginData:i.load(p.pluginData),with:p.with});if(f!=null){if(typeof f!="object")throw new Error(`Expected onLoad() callback in plugin ${te(d)} to return an object`);let y={},S=s(f,y,"pluginName",U),N=s(f,y,"contents",ct),n=s(f,y,"resolveDir",U),a=s(f,y,"pluginData",Ue),E=s(f,y,"loader",U),T=s(f,y,"errors",ge),V=s(f,y,"warnings",ge),P=s(f,y,"watchFiles",re),q=s(f,y,"watchDirs",re);Z(f,y,`from onLoad() callback in plugin ${te(d)}`),l.id=$,S!=null&&(l.pluginName=S),N instanceof Uint8Array?l.contents=N:N!=null&&(l.contents=fe(N)),n!=null&&(l.resolveDir=n),a!=null&&(l.pluginData=i.store(a)),E!=null&&(l.loader=E),T!=null&&(l.errors=we(T,"errors",i,d,void 0)),V!=null&&(l.warnings=we(V,"warnings",i,d,void 0)),P!=null&&(l.watchFiles=Ne(P,"watchFiles")),q!=null&&(l.watchDirs=Ne(q,"watchDirs"));break}}catch(f){l={id:$,errors:[Ee(f,g,i,x&&x(),d)]};break}r(b,l)});let A=(b,p)=>p([],[]);j.length>0&&(A=(b,p)=>{z(null,null,function*(){let l=[],d=[];for(let{name:m,callback:x,note:$}of j){let f,y;try{let S=yield x(b);if(S!=null){if(typeof S!="object")throw new Error(`Expected onEnd() callback in plugin ${te(m)} to return an object`);let N={},n=s(S,N,"errors",ge),a=s(S,N,"warnings",ge);Z(S,N,`from onEnd() callback in plugin ${te(m)}`),n!=null&&(f=we(n,"errors",i,m,void 0)),a!=null&&(y=we(a,"warnings",i,m,void 0))}}catch(S){f=[Ee(S,g,i,$&&$(),m)]}if(f){l.push(...f);try{b.errors.push(...f)}catch{}}if(y){d.push(...y);try{b.warnings.push(...y)}catch{}}}p(l,d)})});let C=()=>{for(let b of F)setTimeout(()=>b(),0)};return Q=!0,{ok:!0,requestPlugins:R,runOnEndCallbacks:A,scheduleOnDisposeCallbacks:C}});function dt(){let e=new Map,t=0;return{clear(){e.clear()},load(r){return e.get(r)},store(r){if(r===void 0)return-1;let u=t++;return e.set(u,r),u}}}function Me(e,t,r){let u,g=!1;return()=>{if(g)return u;g=!0;try{let w=(e.stack+"").split(`
`);w.splice(1,1);let h=ht(t,w,r);if(h)return u={text:e.message,location:h},u}catch{}}}function Ee(e,t,r,u,g){let w="Internal error",h=null;try{w=(e&&e.message||e)+""}catch{}try{h=ht(t,(e.stack+"").split(`
`),"")}catch{}return{id:"",pluginName:g,text:w,location:h,notes:u?[u]:[],detail:r?r.store(e):-1}}function ht(e,t,r){let u="    at ";if(e.readFileSync&&!t[0].startsWith(u)&&t[1].startsWith(u))for(let g=1;g<t.length;g++){let w=t[g];if(w.startsWith(u))for(w=w.slice(u.length);;){let h=/^(?:new |async )?\S+ \((.*)\)$/.exec(w);if(h){w=h[1];continue}if(h=/^eval at \S+ \((.*)\)(?:, \S+:\d+:\d+)?$/.exec(w),h){w=h[1];continue}if(h=/^(\S+):(\d+):(\d+)$/.exec(w),h){let _;try{_=e.readFileSync(h[1],"utf8")}catch{break}let i=_.split(/\r\n|\r|\n|\u2028|\u2029/)[+h[2]-1]||"",k=+h[3]-1,j=i.slice(k,k+r.length)===r?r.length:0;return{file:h[1],namespace:"file",line:+h[2],column:fe(i.slice(0,k)).length,length:fe(i.slice(k,k+j)).length,lineText:i+`
`+t.slice(1).join(`
`),suggestion:""}}break}}return null}function Te(e,t,r){let u=5;e+=t.length<1?"":` with ${t.length} error${t.length<2?"":"s"}:`+t.slice(0,u+1).map((w,h)=>{if(h===u)return`
...`;if(!w.location)return`
error: ${w.text}`;let{file:_,line:i,column:k}=w.location,j=w.pluginName?`[plugin: ${w.pluginName}] `:"";return`
${_}:${i}:${k}: ERROR: ${j}${w.text}`}).join("");let g=new Error(e);for(let[w,h]of[["errors",t],["warnings",r]])Object.defineProperty(g,w,{configurable:!0,enumerable:!0,get:()=>h,set:_=>Object.defineProperty(g,w,{configurable:!0,enumerable:!0,value:_})});return g}function Se(e,t){for(let r of e)r.detail=t.load(r.detail);return e}function mt(e,t,r){if(e==null)return null;let u={},g=s(e,u,"file",U),w=s(e,u,"namespace",U),h=s(e,u,"line",ke),_=s(e,u,"column",ke),i=s(e,u,"length",ke),k=s(e,u,"lineText",U),j=s(e,u,"suggestion",U);if(Z(e,u,t),k){let O=k.slice(0,(_&&_>0?_:0)+(i&&i>0?i:0)+(r&&r>0?r:80));!/[\x7F-\uFFFF]/.test(O)&&!/\n/.test(k)&&(k=O)}return{file:g||"",namespace:w||"",line:h||0,column:_||0,length:i||0,lineText:k||"",suggestion:j||""}}function we(e,t,r,u,g){let w=[],h=0;for(let _ of e){let i={},k=s(_,i,"id",U),j=s(_,i,"pluginName",U),O=s(_,i,"text",U),B=s(_,i,"location",lt),F=s(_,i,"notes",ge),J=s(_,i,"detail",Ue),G=`in element ${h} of "${t}"`;Z(_,i,G);let R=[];if(F)for(let Q of F){let A={},C=s(Q,A,"text",U),b=s(Q,A,"location",lt);Z(Q,A,G),R.push({text:C||"",location:mt(b,G,g)})}w.push({id:k||"",pluginName:j||u,text:O||"",location:mt(B,G,g),notes:R,detail:r?r.store(J):-1}),h++}return w}function Ne(e,t){let r=[];for(let u of e){if(typeof u!="string")throw new Error(`${te(t)} must be an array of strings`);r.push(u)}return r}function Vt(e,t){let r=Object.create(null);for(let u in e){let g=e[u];if(typeof g!="string")throw new Error(`key ${te(u)} in object ${te(t)} must be a string`);r[u]=g}return r}function Lt({path:e,contents:t,hash:r}){let u=null;return{path:e,contents:t,hash:r,get text(){let g=this.contents;return(u===null||g!==t)&&(t=g,u=xe(g)),u}}}function Fe(e){let t=e.source;return e.flags&&(t=`(?${e.flags})${t}`),t}function Bt(e){let t;try{t=xe(e)}catch{return Pt(e)}return JSON.parse(t)}var Wt="0.28.2",zt=e=>Ce().build(e),Jt=e=>Ce().context(e),Gt=(e,t)=>Ce().transform(e,t),qt=(e,t)=>Ce().formatMessages(e,t),Yt=(e,t)=>Ce().analyzeMetafile(e,t),Ht=()=>{throw new Error('The "buildSync" API only works in node')},Kt=()=>{throw new Error('The "transformSync" API only works in node')},Qt=()=>{throw new Error('The "formatMessagesSync" API only works in node')},Xt=()=>{throw new Error('The "analyzeMetafileSync" API only works in node')},Zt=()=>(Ve&&Ve(),Promise.resolve()),_e,Ve,Le,Ce=()=>{if(Le)return Le;throw _e?new Error('You need to wait for the promise returned from "initialize" to be resolved before calling this'):new Error('You need to call "initialize" before calling this')},en=e=>{e=Ut(e||{});let t=e.wasmURL,r=e.wasmModule,u=e.worker!==!1;if(!t&&!r)throw new Error('Must provide either the "wasmURL" option or the "wasmModule" option');if(_e)throw new Error('Cannot call "initialize" more than once');return _e=tn(t||"",r,u),_e.catch(()=>{_e=void 0}),_e},tn=(e,t,r)=>z(null,null,function*(){let u,g,w=new Promise(O=>g=O);if(r){let O=new Blob([`onmessage=((postMessage) => {
      // Copyright 2018 The Go Authors. All rights reserved.
      // Use of this source code is governed by a BSD-style
      // license that can be found in the LICENSE file.
      var __async = (__this, __arguments, generator) => {
        return new Promise((resolve, reject) => {
          var fulfilled = (value) => {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          };
          var rejected = (value) => {
            try {
              step(generator.throw(value));
            } catch (e) {
              reject(e);
            }
          };
          var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
          step((generator = generator.apply(__this, __arguments)).next());
        });
      };
      let onmessage;
      let globalThis = {};
      for (let o = self; o; o = Object.getPrototypeOf(o))
        for (let k of Object.getOwnPropertyNames(o))
          if (!(k in globalThis))
            Object.defineProperty(globalThis, k, { get: () => self[k] });
      "use strict";
      (() => {
        const enosys = () => {
          const err = new Error("not implemented");
          err.code = "ENOSYS";
          return err;
        };
        if (!globalThis.fs) {
          let outputBuf = "";
          globalThis.fs = {
            constants: { O_WRONLY: -1, O_RDWR: -1, O_CREAT: -1, O_TRUNC: -1, O_APPEND: -1, O_EXCL: -1, O_DIRECTORY: -1 },
            // unused
            writeSync(fd, buf) {
              outputBuf += decoder.decode(buf);
              const nl = outputBuf.lastIndexOf("\\n");
              if (nl != -1) {
                console.log(outputBuf.substring(0, nl));
                outputBuf = outputBuf.substring(nl + 1);
              }
              return buf.length;
            },
            write(fd, buf, offset, length, position, callback) {
              if (offset !== 0 || length !== buf.length || position !== null) {
                callback(enosys());
                return;
              }
              const n = this.writeSync(fd, buf);
              callback(null, n);
            },
            chmod(path, mode, callback) {
              callback(enosys());
            },
            chown(path, uid, gid, callback) {
              callback(enosys());
            },
            close(fd, callback) {
              callback(enosys());
            },
            fchmod(fd, mode, callback) {
              callback(enosys());
            },
            fchown(fd, uid, gid, callback) {
              callback(enosys());
            },
            fstat(fd, callback) {
              callback(enosys());
            },
            fsync(fd, callback) {
              callback(null);
            },
            ftruncate(fd, length, callback) {
              callback(enosys());
            },
            lchown(path, uid, gid, callback) {
              callback(enosys());
            },
            link(path, link, callback) {
              callback(enosys());
            },
            lstat(path, callback) {
              callback(enosys());
            },
            mkdir(path, perm, callback) {
              callback(enosys());
            },
            open(path, flags, mode, callback) {
              callback(enosys());
            },
            read(fd, buffer, offset, length, position, callback) {
              callback(enosys());
            },
            readdir(path, callback) {
              callback(enosys());
            },
            readlink(path, callback) {
              callback(enosys());
            },
            rename(from, to, callback) {
              callback(enosys());
            },
            rmdir(path, callback) {
              callback(enosys());
            },
            stat(path, callback) {
              callback(enosys());
            },
            symlink(path, link, callback) {
              callback(enosys());
            },
            truncate(path, length, callback) {
              callback(enosys());
            },
            unlink(path, callback) {
              callback(enosys());
            },
            utimes(path, atime, mtime, callback) {
              callback(enosys());
            }
          };
        }
        if (!globalThis.process) {
          globalThis.process = {
            getuid() {
              return -1;
            },
            getgid() {
              return -1;
            },
            geteuid() {
              return -1;
            },
            getegid() {
              return -1;
            },
            getgroups() {
              throw enosys();
            },
            pid: -1,
            ppid: -1,
            umask() {
              throw enosys();
            },
            cwd() {
              throw enosys();
            },
            chdir() {
              throw enosys();
            }
          };
        }
        if (!globalThis.path) {
          globalThis.path = {
            resolve(...pathSegments) {
              return pathSegments.join("/");
            }
          };
        }
        if (!globalThis.crypto) {
          throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");
        }
        if (!globalThis.performance) {
          throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");
        }
        if (!globalThis.TextEncoder) {
          throw new Error("globalThis.TextEncoder is not available, polyfill required");
        }
        if (!globalThis.TextDecoder) {
          throw new Error("globalThis.TextDecoder is not available, polyfill required");
        }
        const encoder = new TextEncoder("utf-8");
        const decoder = new TextDecoder("utf-8");
        globalThis.Go = class {
          constructor() {
            this.argv = ["js"];
            this.env = {};
            this.exit = (code) => {
              if (code !== 0) {
                console.warn("exit code:", code);
              }
            };
            this._exitPromise = new Promise((resolve) => {
              this._resolveExitPromise = resolve;
            });
            this._pendingEvent = null;
            this._scheduledTimeouts = /* @__PURE__ */ new Map();
            this._nextCallbackTimeoutID = 1;
            const setInt64 = (addr, v) => {
              this.mem.setUint32(addr + 0, v, true);
              this.mem.setUint32(addr + 4, Math.floor(v / 4294967296), true);
            };
            const setInt32 = (addr, v) => {
              this.mem.setUint32(addr + 0, v, true);
            };
            const getInt64 = (addr) => {
              const low = this.mem.getUint32(addr + 0, true);
              const high = this.mem.getInt32(addr + 4, true);
              return low + high * 4294967296;
            };
            const loadValue = (addr) => {
              const f = this.mem.getFloat64(addr, true);
              if (f === 0) {
                return void 0;
              }
              if (!isNaN(f)) {
                return f;
              }
              const id = this.mem.getUint32(addr, true);
              return this._values[id];
            };
            const storeValue = (addr, v) => {
              const nanHead = 2146959360;
              if (typeof v === "number" && v !== 0) {
                if (isNaN(v)) {
                  this.mem.setUint32(addr + 4, nanHead, true);
                  this.mem.setUint32(addr, 0, true);
                  return;
                }
                this.mem.setFloat64(addr, v, true);
                return;
              }
              if (v === void 0) {
                this.mem.setFloat64(addr, 0, true);
                return;
              }
              let id = this._ids.get(v);
              if (id === void 0) {
                id = this._idPool.pop();
                if (id === void 0) {
                  id = this._values.length;
                }
                this._values[id] = v;
                this._goRefCounts[id] = 0;
                this._ids.set(v, id);
              }
              this._goRefCounts[id]++;
              let typeFlag = 0;
              switch (typeof v) {
                case "object":
                  if (v !== null) {
                    typeFlag = 1;
                  }
                  break;
                case "string":
                  typeFlag = 2;
                  break;
                case "symbol":
                  typeFlag = 3;
                  break;
                case "function":
                  typeFlag = 4;
                  break;
              }
              this.mem.setUint32(addr + 4, nanHead | typeFlag, true);
              this.mem.setUint32(addr, id, true);
            };
            const loadSlice = (addr) => {
              const array = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              return new Uint8Array(this._inst.exports.mem.buffer, array, len);
            };
            const loadSliceOfValues = (addr) => {
              const array = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              const a = new Array(len);
              for (let i = 0; i < len; i++) {
                a[i] = loadValue(array + i * 8);
              }
              return a;
            };
            const loadString = (addr) => {
              const saddr = getInt64(addr + 0);
              const len = getInt64(addr + 8);
              return decoder.decode(new DataView(this._inst.exports.mem.buffer, saddr, len));
            };
            const testCallExport = (a, b) => {
              this._inst.exports.testExport0();
              return this._inst.exports.testExport(a, b);
            };
            const timeOrigin = Date.now() - performance.now();
            this.importObject = {
              _gotest: {
                add: (a, b) => a + b,
                callExport: testCallExport
              },
              gojs: {
                // Go's SP does not change as long as no Go code is running. Some operations (e.g. calls, getters and setters)
                // may synchronously trigger a Go event handler. This makes Go code get executed in the middle of the imported
                // function. A goroutine can switch to a new stack if the current stack is too small (see morestack function).
                // This changes the SP, thus we have to update the SP used by the imported function.
                // func wasmExit(code int32)
                "runtime.wasmExit": (sp) => {
                  sp >>>= 0;
                  const code = this.mem.getInt32(sp + 8, true);
                  this.exited = true;
                  delete this._inst;
                  delete this._values;
                  delete this._goRefCounts;
                  delete this._ids;
                  delete this._idPool;
                  this.exit(code);
                },
                // func wasmWrite(fd uintptr, p unsafe.Pointer, n int32)
                "runtime.wasmWrite": (sp) => {
                  sp >>>= 0;
                  const fd = getInt64(sp + 8);
                  const p = getInt64(sp + 16);
                  const n = this.mem.getInt32(sp + 24, true);
                  globalThis.fs.writeSync(fd, new Uint8Array(this._inst.exports.mem.buffer, p, n));
                },
                // func resetMemoryDataView()
                "runtime.resetMemoryDataView": (sp) => {
                  sp >>>= 0;
                  this.mem = new DataView(this._inst.exports.mem.buffer);
                },
                // func nanotime1() int64
                "runtime.nanotime1": (sp) => {
                  sp >>>= 0;
                  setInt64(sp + 8, (timeOrigin + performance.now()) * 1e6);
                },
                // func walltime() (sec int64, nsec int32)
                "runtime.walltime": (sp) => {
                  sp >>>= 0;
                  const msec = (/* @__PURE__ */ new Date()).getTime();
                  setInt64(sp + 8, msec / 1e3);
                  this.mem.setInt32(sp + 16, msec % 1e3 * 1e6, true);
                },
                // func scheduleTimeoutEvent(delay int64) int32
                "runtime.scheduleTimeoutEvent": (sp) => {
                  sp >>>= 0;
                  const id = this._nextCallbackTimeoutID;
                  this._nextCallbackTimeoutID++;
                  this._scheduledTimeouts.set(id, setTimeout(
                    () => {
                      this._resume();
                      while (this._scheduledTimeouts.has(id)) {
                        console.warn("scheduleTimeoutEvent: missed timeout event");
                        this._resume();
                      }
                    },
                    getInt64(sp + 8)
                  ));
                  this.mem.setInt32(sp + 16, id, true);
                },
                // func clearTimeoutEvent(id int32)
                "runtime.clearTimeoutEvent": (sp) => {
                  sp >>>= 0;
                  const id = this.mem.getInt32(sp + 8, true);
                  clearTimeout(this._scheduledTimeouts.get(id));
                  this._scheduledTimeouts.delete(id);
                },
                // func getRandomData(r []byte)
                "runtime.getRandomData": (sp) => {
                  sp >>>= 0;
                  crypto.getRandomValues(loadSlice(sp + 8));
                },
                // func finalizeRef(v ref)
                "syscall/js.finalizeRef": (sp) => {
                  sp >>>= 0;
                  const id = this.mem.getUint32(sp + 8, true);
                  this._goRefCounts[id]--;
                  if (this._goRefCounts[id] === 0) {
                    const v = this._values[id];
                    this._values[id] = null;
                    this._ids.delete(v);
                    this._idPool.push(id);
                  }
                },
                // func stringVal(value string) ref
                "syscall/js.stringVal": (sp) => {
                  sp >>>= 0;
                  storeValue(sp + 24, loadString(sp + 8));
                },
                // func valueGet(v ref, p string) ref
                "syscall/js.valueGet": (sp) => {
                  sp >>>= 0;
                  const result = Reflect.get(loadValue(sp + 8), loadString(sp + 16));
                  sp = this._inst.exports.getsp() >>> 0;
                  storeValue(sp + 32, result);
                },
                // func valueSet(v ref, p string, x ref)
                "syscall/js.valueSet": (sp) => {
                  sp >>>= 0;
                  Reflect.set(loadValue(sp + 8), loadString(sp + 16), loadValue(sp + 32));
                },
                // func valueDelete(v ref, p string)
                "syscall/js.valueDelete": (sp) => {
                  sp >>>= 0;
                  Reflect.deleteProperty(loadValue(sp + 8), loadString(sp + 16));
                },
                // func valueIndex(v ref, i int) ref
                "syscall/js.valueIndex": (sp) => {
                  sp >>>= 0;
                  storeValue(sp + 24, Reflect.get(loadValue(sp + 8), getInt64(sp + 16)));
                },
                // valueSetIndex(v ref, i int, x ref)
                "syscall/js.valueSetIndex": (sp) => {
                  sp >>>= 0;
                  Reflect.set(loadValue(sp + 8), getInt64(sp + 16), loadValue(sp + 24));
                },
                // func valueCall(v ref, m string, args []ref) (ref, bool)
                "syscall/js.valueCall": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const m = Reflect.get(v, loadString(sp + 16));
                    const args = loadSliceOfValues(sp + 32);
                    const result = Reflect.apply(m, v, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 56, result);
                    this.mem.setUint8(sp + 64, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 56, err);
                    this.mem.setUint8(sp + 64, 0);
                  }
                },
                // func valueInvoke(v ref, args []ref) (ref, bool)
                "syscall/js.valueInvoke": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const args = loadSliceOfValues(sp + 16);
                    const result = Reflect.apply(v, void 0, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, result);
                    this.mem.setUint8(sp + 48, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, err);
                    this.mem.setUint8(sp + 48, 0);
                  }
                },
                // func valueNew(v ref, args []ref) (ref, bool)
                "syscall/js.valueNew": (sp) => {
                  sp >>>= 0;
                  try {
                    const v = loadValue(sp + 8);
                    const args = loadSliceOfValues(sp + 16);
                    const result = Reflect.construct(v, args);
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, result);
                    this.mem.setUint8(sp + 48, 1);
                  } catch (err) {
                    sp = this._inst.exports.getsp() >>> 0;
                    storeValue(sp + 40, err);
                    this.mem.setUint8(sp + 48, 0);
                  }
                },
                // func valueLength(v ref) int
                "syscall/js.valueLength": (sp) => {
                  sp >>>= 0;
                  setInt64(sp + 16, parseInt(loadValue(sp + 8).length));
                },
                // valuePrepareString(v ref) (ref, int)
                "syscall/js.valuePrepareString": (sp) => {
                  sp >>>= 0;
                  const str = encoder.encode(String(loadValue(sp + 8)));
                  storeValue(sp + 16, str);
                  setInt64(sp + 24, str.length);
                },
                // valueLoadString(v ref, b []byte)
                "syscall/js.valueLoadString": (sp) => {
                  sp >>>= 0;
                  const str = loadValue(sp + 8);
                  loadSlice(sp + 16).set(str);
                },
                // func valueInstanceOf(v ref, t ref) bool
                "syscall/js.valueInstanceOf": (sp) => {
                  sp >>>= 0;
                  this.mem.setUint8(sp + 24, loadValue(sp + 8) instanceof loadValue(sp + 16) ? 1 : 0);
                },
                // func copyBytesToGo(dst []byte, src ref) (int, bool)
                "syscall/js.copyBytesToGo": (sp) => {
                  sp >>>= 0;
                  const dst = loadSlice(sp + 8);
                  const src = loadValue(sp + 32);
                  if (!(src instanceof Uint8Array || src instanceof Uint8ClampedArray)) {
                    this.mem.setUint8(sp + 48, 0);
                    return;
                  }
                  const toCopy = src.subarray(0, dst.length);
                  dst.set(toCopy);
                  setInt64(sp + 40, toCopy.length);
                  this.mem.setUint8(sp + 48, 1);
                },
                // func copyBytesToJS(dst ref, src []byte) (int, bool)
                "syscall/js.copyBytesToJS": (sp) => {
                  sp >>>= 0;
                  const dst = loadValue(sp + 8);
                  const src = loadSlice(sp + 16);
                  if (!(dst instanceof Uint8Array || dst instanceof Uint8ClampedArray)) {
                    this.mem.setUint8(sp + 48, 0);
                    return;
                  }
                  const toCopy = src.subarray(0, dst.length);
                  dst.set(toCopy);
                  setInt64(sp + 40, toCopy.length);
                  this.mem.setUint8(sp + 48, 1);
                },
                "debug": (value) => {
                  console.log(value);
                }
              }
            };
          }
          run(instance) {
            return __async(this, null, function* () {
              if (!(instance instanceof WebAssembly.Instance)) {
                throw new Error("Go.run: WebAssembly.Instance expected");
              }
              this._inst = instance;
              this.mem = new DataView(this._inst.exports.mem.buffer);
              this._values = [
                // JS values that Go currently has references to, indexed by reference id
                NaN,
                0,
                null,
                true,
                false,
                globalThis,
                this
              ];
              this._goRefCounts = new Array(this._values.length).fill(Infinity);
              this._ids = /* @__PURE__ */ new Map([
                // mapping from JS values to reference ids
                [0, 1],
                [null, 2],
                [true, 3],
                [false, 4],
                [globalThis, 5],
                [this, 6]
              ]);
              this._idPool = [];
              this.exited = false;
              let offset = 4096;
              const strPtr = (str) => {
                const ptr = offset;
                const bytes = encoder.encode(str + "\\0");
                new Uint8Array(this.mem.buffer, offset, bytes.length).set(bytes);
                offset += bytes.length;
                if (offset % 8 !== 0) {
                  offset += 8 - offset % 8;
                }
                return ptr;
              };
              const argc = this.argv.length;
              const argvPtrs = [];
              this.argv.forEach((arg) => {
                argvPtrs.push(strPtr(arg));
              });
              argvPtrs.push(0);
              const keys = Object.keys(this.env).sort();
              keys.forEach((key) => {
                argvPtrs.push(strPtr(\`\${key}=\${this.env[key]}\`));
              });
              argvPtrs.push(0);
              const argv = offset;
              argvPtrs.forEach((ptr) => {
                this.mem.setUint32(offset, ptr, true);
                this.mem.setUint32(offset + 4, 0, true);
                offset += 8;
              });
              const wasmMinDataAddr = 4096 + 8192;
              if (offset >= wasmMinDataAddr) {
                throw new Error("total length of command line and environment variables exceeds limit");
              }
              this._inst.exports.run(argc, argv);
              if (this.exited) {
                this._resolveExitPromise();
              }
              yield this._exitPromise;
            });
          }
          _resume() {
            if (this.exited) {
              throw new Error("Go program has already exited");
            }
            this._inst.exports.resume();
            if (this.exited) {
              this._resolveExitPromise();
            }
          }
          _makeFuncWrapper(id) {
            const go = this;
            return function() {
              const event = { id, this: this, args: arguments };
              go._pendingEvent = event;
              go._resume();
              return event.result;
            };
          }
        };
      })();
      onmessage = ({ data: wasm }) => {
        let decoder = new TextDecoder();
        let fs = globalThis.fs;
        let stderr = "";
        fs.writeSync = (fd, buffer) => {
          if (fd === 1) {
            postMessage(buffer);
          } else if (fd === 2) {
            stderr += decoder.decode(buffer);
            let parts = stderr.split("\\n");
            if (parts.length > 1) console.log(parts.slice(0, -1).join("\\n"));
            stderr = parts[parts.length - 1];
          } else {
            throw new Error("Bad write");
          }
          return buffer.length;
        };
        let stdin = [];
        let resumeStdin;
        let stdinPos = 0;
        onmessage = ({ data }) => {
          if (data.length > 0) {
            stdin.push(data);
            if (resumeStdin) resumeStdin();
          }
          return go;
        };
        fs.read = (fd, buffer, offset, length, position, callback) => {
          if (fd !== 0 || offset !== 0 || length !== buffer.length || position !== null) {
            throw new Error("Bad read");
          }
          if (stdin.length === 0) {
            resumeStdin = () => fs.read(fd, buffer, offset, length, position, callback);
            return;
          }
          let first = stdin[0];
          let count = Math.max(0, Math.min(length, first.length - stdinPos));
          buffer.set(first.subarray(stdinPos, stdinPos + count), offset);
          stdinPos += count;
          if (stdinPos === first.length) {
            stdin.shift();
            stdinPos = 0;
          }
          callback(null, count);
        };
        let go = new globalThis.Go();
        go.argv = ["", \`--service=\${"0.28.2"}\`];
        tryToInstantiateModule(wasm, go).then(
          (instance) => {
            postMessage(null);
            go.run(instance);
          },
          (error) => {
            postMessage(error);
          }
        );
        return go;
      };
      function tryToInstantiateModule(wasm, go) {
        return __async(this, null, function* () {
          if (wasm instanceof WebAssembly.Module) {
            return WebAssembly.instantiate(wasm, go.importObject);
          }
          const res = yield fetch(wasm);
          if (!res.ok) throw new Error(\`Failed to download \${JSON.stringify(wasm)}\`);
          if ("instantiateStreaming" in WebAssembly && /^application\\/wasm($|;)/i.test(res.headers.get("Content-Type") || "")) {
            const result2 = yield WebAssembly.instantiateStreaming(res, go.importObject);
            return result2.instance;
          }
          const bytes = yield res.arrayBuffer();
          const result = yield WebAssembly.instantiate(bytes, go.importObject);
          return result.instance;
        });
      }
      return (m) => onmessage(m);
    })(postMessage)`],{type:"text/javascript"});u=new Worker(URL.createObjectURL(O))}else{let O=(F=>{var J=(A,C,b)=>new Promise((p,l)=>{var d=$=>{try{x(b.next($))}catch(f){l(f)}},m=$=>{try{x(b.throw($))}catch(f){l(f)}},x=$=>$.done?p($.value):Promise.resolve($.value).then(d,m);x((b=b.apply(A,C)).next())});let G,R={};for(let A=self;A;A=Object.getPrototypeOf(A))for(let C of Object.getOwnPropertyNames(A))C in R||Object.defineProperty(R,C,{get:()=>self[C]});(()=>{let A=()=>{let p=new Error("not implemented");return p.code="ENOSYS",p};if(!R.fs){let p="";R.fs={constants:{O_WRONLY:-1,O_RDWR:-1,O_CREAT:-1,O_TRUNC:-1,O_APPEND:-1,O_EXCL:-1,O_DIRECTORY:-1},writeSync(l,d){p+=b.decode(d);let m=p.lastIndexOf(`
`);return m!=-1&&(console.log(p.substring(0,m)),p=p.substring(m+1)),d.length},write(l,d,m,x,$,f){if(m!==0||x!==d.length||$!==null){f(A());return}let y=this.writeSync(l,d);f(null,y)},chmod(l,d,m){m(A())},chown(l,d,m,x){x(A())},close(l,d){d(A())},fchmod(l,d,m){m(A())},fchown(l,d,m,x){x(A())},fstat(l,d){d(A())},fsync(l,d){d(null)},ftruncate(l,d,m){m(A())},lchown(l,d,m,x){x(A())},link(l,d,m){m(A())},lstat(l,d){d(A())},mkdir(l,d,m){m(A())},open(l,d,m,x){x(A())},read(l,d,m,x,$,f){f(A())},readdir(l,d){d(A())},readlink(l,d){d(A())},rename(l,d,m){m(A())},rmdir(l,d){d(A())},stat(l,d){d(A())},symlink(l,d,m){m(A())},truncate(l,d,m){m(A())},unlink(l,d){d(A())},utimes(l,d,m,x){x(A())}}}if(R.process||(R.process={getuid(){return-1},getgid(){return-1},geteuid(){return-1},getegid(){return-1},getgroups(){throw A()},pid:-1,ppid:-1,umask(){throw A()},cwd(){throw A()},chdir(){throw A()}}),R.path||(R.path={resolve(...p){return p.join("/")}}),!R.crypto)throw new Error("globalThis.crypto is not available, polyfill required (crypto.getRandomValues only)");if(!R.performance)throw new Error("globalThis.performance is not available, polyfill required (performance.now only)");if(!R.TextEncoder)throw new Error("globalThis.TextEncoder is not available, polyfill required");if(!R.TextDecoder)throw new Error("globalThis.TextDecoder is not available, polyfill required");let C=new TextEncoder("utf-8"),b=new TextDecoder("utf-8");R.Go=class{constructor(){this.argv=["js"],this.env={},this.exit=n=>{n!==0&&console.warn("exit code:",n)},this._exitPromise=new Promise(n=>{this._resolveExitPromise=n}),this._pendingEvent=null,this._scheduledTimeouts=new Map,this._nextCallbackTimeoutID=1;let p=(n,a)=>{this.mem.setUint32(n+0,a,!0),this.mem.setUint32(n+4,Math.floor(a/4294967296),!0)},l=(n,a)=>{this.mem.setUint32(n+0,a,!0)},d=n=>{let a=this.mem.getUint32(n+0,!0),E=this.mem.getInt32(n+4,!0);return a+E*4294967296},m=n=>{let a=this.mem.getFloat64(n,!0);if(a===0)return;if(!isNaN(a))return a;let E=this.mem.getUint32(n,!0);return this._values[E]},x=(n,a)=>{if(typeof a=="number"&&a!==0){if(isNaN(a)){this.mem.setUint32(n+4,2146959360,!0),this.mem.setUint32(n,0,!0);return}this.mem.setFloat64(n,a,!0);return}if(a===void 0){this.mem.setFloat64(n,0,!0);return}let T=this._ids.get(a);T===void 0&&(T=this._idPool.pop(),T===void 0&&(T=this._values.length),this._values[T]=a,this._goRefCounts[T]=0,this._ids.set(a,T)),this._goRefCounts[T]++;let V=0;switch(typeof a){case"object":a!==null&&(V=1);break;case"string":V=2;break;case"symbol":V=3;break;case"function":V=4;break}this.mem.setUint32(n+4,2146959360|V,!0),this.mem.setUint32(n,T,!0)},$=n=>{let a=d(n+0),E=d(n+8);return new Uint8Array(this._inst.exports.mem.buffer,a,E)},f=n=>{let a=d(n+0),E=d(n+8),T=new Array(E);for(let V=0;V<E;V++)T[V]=m(a+V*8);return T},y=n=>{let a=d(n+0),E=d(n+8);return b.decode(new DataView(this._inst.exports.mem.buffer,a,E))},S=(n,a)=>(this._inst.exports.testExport0(),this._inst.exports.testExport(n,a)),N=Date.now()-performance.now();this.importObject={_gotest:{add:(n,a)=>n+a,callExport:S},gojs:{"runtime.wasmExit":n=>{n>>>=0;let a=this.mem.getInt32(n+8,!0);this.exited=!0,delete this._inst,delete this._values,delete this._goRefCounts,delete this._ids,delete this._idPool,this.exit(a)},"runtime.wasmWrite":n=>{n>>>=0;let a=d(n+8),E=d(n+16),T=this.mem.getInt32(n+24,!0);R.fs.writeSync(a,new Uint8Array(this._inst.exports.mem.buffer,E,T))},"runtime.resetMemoryDataView":n=>{n>>>=0,this.mem=new DataView(this._inst.exports.mem.buffer)},"runtime.nanotime1":n=>{n>>>=0,p(n+8,(N+performance.now())*1e6)},"runtime.walltime":n=>{n>>>=0;let a=new Date().getTime();p(n+8,a/1e3),this.mem.setInt32(n+16,a%1e3*1e6,!0)},"runtime.scheduleTimeoutEvent":n=>{n>>>=0;let a=this._nextCallbackTimeoutID;this._nextCallbackTimeoutID++,this._scheduledTimeouts.set(a,setTimeout(()=>{for(this._resume();this._scheduledTimeouts.has(a);)console.warn("scheduleTimeoutEvent: missed timeout event"),this._resume()},d(n+8))),this.mem.setInt32(n+16,a,!0)},"runtime.clearTimeoutEvent":n=>{n>>>=0;let a=this.mem.getInt32(n+8,!0);clearTimeout(this._scheduledTimeouts.get(a)),this._scheduledTimeouts.delete(a)},"runtime.getRandomData":n=>{n>>>=0,crypto.getRandomValues($(n+8))},"syscall/js.finalizeRef":n=>{n>>>=0;let a=this.mem.getUint32(n+8,!0);if(this._goRefCounts[a]--,this._goRefCounts[a]===0){let E=this._values[a];this._values[a]=null,this._ids.delete(E),this._idPool.push(a)}},"syscall/js.stringVal":n=>{n>>>=0,x(n+24,y(n+8))},"syscall/js.valueGet":n=>{n>>>=0;let a=Reflect.get(m(n+8),y(n+16));n=this._inst.exports.getsp()>>>0,x(n+32,a)},"syscall/js.valueSet":n=>{n>>>=0,Reflect.set(m(n+8),y(n+16),m(n+32))},"syscall/js.valueDelete":n=>{n>>>=0,Reflect.deleteProperty(m(n+8),y(n+16))},"syscall/js.valueIndex":n=>{n>>>=0,x(n+24,Reflect.get(m(n+8),d(n+16)))},"syscall/js.valueSetIndex":n=>{n>>>=0,Reflect.set(m(n+8),d(n+16),m(n+24))},"syscall/js.valueCall":n=>{n>>>=0;try{let a=m(n+8),E=Reflect.get(a,y(n+16)),T=f(n+32),V=Reflect.apply(E,a,T);n=this._inst.exports.getsp()>>>0,x(n+56,V),this.mem.setUint8(n+64,1)}catch(a){n=this._inst.exports.getsp()>>>0,x(n+56,a),this.mem.setUint8(n+64,0)}},"syscall/js.valueInvoke":n=>{n>>>=0;try{let a=m(n+8),E=f(n+16),T=Reflect.apply(a,void 0,E);n=this._inst.exports.getsp()>>>0,x(n+40,T),this.mem.setUint8(n+48,1)}catch(a){n=this._inst.exports.getsp()>>>0,x(n+40,a),this.mem.setUint8(n+48,0)}},"syscall/js.valueNew":n=>{n>>>=0;try{let a=m(n+8),E=f(n+16),T=Reflect.construct(a,E);n=this._inst.exports.getsp()>>>0,x(n+40,T),this.mem.setUint8(n+48,1)}catch(a){n=this._inst.exports.getsp()>>>0,x(n+40,a),this.mem.setUint8(n+48,0)}},"syscall/js.valueLength":n=>{n>>>=0,p(n+16,parseInt(m(n+8).length))},"syscall/js.valuePrepareString":n=>{n>>>=0;let a=C.encode(String(m(n+8)));x(n+16,a),p(n+24,a.length)},"syscall/js.valueLoadString":n=>{n>>>=0;let a=m(n+8);$(n+16).set(a)},"syscall/js.valueInstanceOf":n=>{n>>>=0,this.mem.setUint8(n+24,m(n+8)instanceof m(n+16)?1:0)},"syscall/js.copyBytesToGo":n=>{n>>>=0;let a=$(n+8),E=m(n+32);if(!(E instanceof Uint8Array||E instanceof Uint8ClampedArray)){this.mem.setUint8(n+48,0);return}let T=E.subarray(0,a.length);a.set(T),p(n+40,T.length),this.mem.setUint8(n+48,1)},"syscall/js.copyBytesToJS":n=>{n>>>=0;let a=m(n+8),E=$(n+16);if(!(a instanceof Uint8Array||a instanceof Uint8ClampedArray)){this.mem.setUint8(n+48,0);return}let T=E.subarray(0,a.length);a.set(T),p(n+40,T.length),this.mem.setUint8(n+48,1)},debug:n=>{console.log(n)}}}}run(p){return J(this,null,function*(){if(!(p instanceof WebAssembly.Instance))throw new Error("Go.run: WebAssembly.Instance expected");this._inst=p,this.mem=new DataView(this._inst.exports.mem.buffer),this._values=[NaN,0,null,!0,!1,R,this],this._goRefCounts=new Array(this._values.length).fill(1/0),this._ids=new Map([[0,1],[null,2],[!0,3],[!1,4],[R,5],[this,6]]),this._idPool=[],this.exited=!1;let l=4096,d=S=>{let N=l,n=C.encode(S+"\0");return new Uint8Array(this.mem.buffer,l,n.length).set(n),l+=n.length,l%8!==0&&(l+=8-l%8),N},m=this.argv.length,x=[];this.argv.forEach(S=>{x.push(d(S))}),x.push(0),Object.keys(this.env).sort().forEach(S=>{x.push(d(`${S}=${this.env[S]}`))}),x.push(0);let f=l;if(x.forEach(S=>{this.mem.setUint32(l,S,!0),this.mem.setUint32(l+4,0,!0),l+=8}),l>=12288)throw new Error("total length of command line and environment variables exceeds limit");this._inst.exports.run(m,f),this.exited&&this._resolveExitPromise(),yield this._exitPromise})}_resume(){if(this.exited)throw new Error("Go program has already exited");this._inst.exports.resume(),this.exited&&this._resolveExitPromise()}_makeFuncWrapper(p){let l=this;return function(){let d={id:p,this:this,args:arguments};return l._pendingEvent=d,l._resume(),d.result}}}})(),G=({data:A})=>{let C=new TextDecoder,b=R.fs,p="";b.writeSync=($,f)=>{if($===1)F(f);else if($===2){p+=C.decode(f);let y=p.split(`
`);y.length>1&&console.log(y.slice(0,-1).join(`
`)),p=y[y.length-1]}else throw new Error("Bad write");return f.length};let l=[],d,m=0;G=({data:$})=>($.length>0&&(l.push($),d&&d()),x),b.read=($,f,y,S,N,n)=>{if($!==0||y!==0||S!==f.length||N!==null)throw new Error("Bad read");if(l.length===0){d=()=>b.read($,f,y,S,N,n);return}let a=l[0],E=Math.max(0,Math.min(S,a.length-m));f.set(a.subarray(m,m+E),y),m+=E,m===a.length&&(l.shift(),m=0),n(null,E)};let x=new R.Go;return x.argv=["","--service=0.28.2"],Q(A,x).then($=>{F(null),x.run($)},$=>{F($)}),x};function Q(A,C){return J(this,null,function*(){if(A instanceof WebAssembly.Module)return WebAssembly.instantiate(A,C.importObject);let b=yield fetch(A);if(!b.ok)throw new Error(`Failed to download ${JSON.stringify(A)}`);if("instantiateStreaming"in WebAssembly&&/^application\/wasm($|;)/i.test(b.headers.get("Content-Type")||""))return(yield WebAssembly.instantiateStreaming(b,C.importObject)).instance;let p=yield b.arrayBuffer();return(yield WebAssembly.instantiate(p,C.importObject)).instance})}return A=>G(A)})(F=>u.onmessage({data:F})),B;u={onmessage:null,postMessage:F=>setTimeout(()=>{try{B=O({data:F})}catch(J){g(J)}}),terminate(){if(B)for(let F of B._scheduledTimeouts.values())clearTimeout(F)}}}let h,_,i=new Promise((O,B)=>{h=O,_=B});u.onmessage=({data:O})=>{u.onmessage=({data:B})=>k(B),O?_(O):h()},u.postMessage(t||new URL(e,location.href).toString());let{readFromStdout:k,service:j}=Mt({writeToStdin(O){u.postMessage(O)},isSync:!1,hasFS:!1,esbuild:X});yield i,Ve=()=>{u.terminate(),_e=void 0,Ve=void 0,Le=void 0},Le={build:O=>new Promise((B,F)=>{w.then(F),j.buildOrContext({callName:"build",refs:null,options:O,isTTY:!1,defaultWD:"/",callback:(J,G)=>J?F(J):B(G)})}),context:O=>new Promise((B,F)=>{w.then(F),j.buildOrContext({callName:"context",refs:null,options:O,isTTY:!1,defaultWD:"/",callback:(J,G)=>J?F(J):B(G)})}),transform:(O,B)=>new Promise((F,J)=>{w.then(J),j.transform({callName:"transform",refs:null,input:O,options:B||{},isTTY:!1,fs:{readFile(G,R){R(new Error("Internal error"),null)},writeFile(G,R){R(null)}},callback:(G,R)=>G?J(G):F(R)})}),formatMessages:(O,B)=>new Promise((F,J)=>{w.then(J),j.formatMessages({callName:"formatMessages",refs:null,messages:O,options:B,callback:(G,R)=>G?J(G):F(R)})}),analyzeMetafile:(O,B)=>new Promise((F,J)=>{w.then(J),j.analyzeMetafile({callName:"analyzeMetafile",refs:null,metafile:typeof O=="string"?O:JSON.stringify(O),options:B,callback:(G,R)=>G?J(G):F(R)})})}}),nn=X})(typeof Ge=="object"?Ge:{set exports(o){(typeof self<"u"?self:this).esbuild=o}})});var We=hn(gt(),1);function Re(o){return!o||typeof o!="object"?!1:!Array.isArray(o)}function mn(o,c,v){for(let I of o){let M=Pe(I,c,v);if(M)return M}return null}function pn(o,c,v){for(let[I,M]of Object.entries(o)){if(!v.has(I))continue;let Y=Pe(M,c,v);if(Y)return Y}return null}function Pe(o,c,v){return typeof o=="string"?o.replaceAll("*",c??""):Array.isArray(o)?mn(o,c,v):Re(o)?pn(o,c,v):null}function gn(o,c){if(!(!c||c===".")){if(c!==".."){o.push(c);return}if(!o.length)throw new Error("Import escapes its source root");o.pop()}}function he(o){let c=[];for(let v of o.split("/"))gn(c,v);return c.join("/")}function qe(o,c){if(!o?.startsWith("./"))throw new Error(`Unsupported package export: ${c}`);return he(o)}function wn(o){return Re(o)?Object.keys(o).some(c=>c.startsWith(".")):!1}var yn=(o,c)=>{let[v,I]=o.split("*");return c.startsWith(v)&&c.endsWith(I)},bn=(o,c)=>Object.keys(o).filter(v=>v.includes("*")).sort((v,I)=>I.length-v.length).find(v=>yn(v,c));function vn(o,c,v){let I=bn(o,c);if(!I)throw new Error(`Package does not export ${c}`);let[M,Y]=I.split("*");return qe(Pe(o[I],c.slice(M.length,c.length-Y.length),v),c)}function xn(o){return typeof o.browser=="string"&&o.browser?o.browser:o.module||o.main||"index.js"}function kn(o,c,v){return Object.hasOwn(o,c)?qe(Pe(o[c],void 0,v),c):vn(o,c,v)}function Ye(o,c="",v="import"){let I=new Set(["browser",v,"default","production"]),M=o.exports;if(M===void 0)return he(c||xn(o));let Y=c?`./${c}`:".";if(wn(M))return kn(M,Y,I);if(c)throw new Error(`Package does not export ${Y}`);return qe(Pe(M,void 0,I),Y)}var He=o=>o.split("/").slice(0,-1).join("/"),Be=o=>o.split("/")[0],wt=o=>o.slice(o.indexOf("/")+1);function En(o,c){let v=o?.manifest.browser;if(!Re(v))return{specifier:c.path};let I=c.path.startsWith(".")?"./"+he(He(wt(c.importer))+"/"+c.path):c.path,M=v[I];return M===!1?{empty:!0,specifier:c.path}:typeof M!="string"?{specifier:c.path}:M.startsWith(".")?{local:`${Be(c.importer)}/${he(M)}`,specifier:c.path}:{specifier:M}}function _n(o,c,v){return o.namespace!=="npm"?v("project",he(He(o.importer)+"/"+c)):v("npm",`${Be(o.importer)}/${he(He(wt(o.importer))+"/"+c)}`)}function jn(o,c,v,I){return v?v.name===c?Be(o.importer):v.dependencies[c]:I.roots[c]?.id}function Sn(o,c,v,{lock:I,find:M}){let Y=c.split("/"),oe=Y.splice(0,c.startsWith("@")?2:1).join("/"),ne=jn(o,oe,v,I);if(!ne)throw new Error(`Uninstalled browser dependency: ${c}`);let z=o.kind.startsWith("require")?"require":"import";return M("npm",`${ne}/${Ye(I.packages[ne].manifest,Y.join("/"),z)}`)}async function Ke(o,c,v){if(o.kind==="entry-point")return v("project",he(o.path));let I=o.namespace==="npm"?c.packages[Be(o.importer)]:null,M=En(I,o);if(M.empty)return{path:M.specifier,namespace:"empty"};if(M.local)return v("npm",M.local);if(M.specifier.startsWith("."))return _n(o,M.specifier,v);if(/^(?:[a-z]+:|\/|#)/i.test(M.specifier))throw new Error(`Unsupported browser import: ${M.specifier}`);return Sn(o,M.specifier,I,{lock:c,find:v})}var yt=".webfront/developer/packages";var $n=new TextDecoder,Pn=["",".tsx",".ts",".jsx",".js",".mjs",".cjs",".json",".css","/index.tsx","/index.ts","/index.js"],On=new Map(Object.entries({mjs:"js",cjs:"js",js:"js",jsx:"jsx",ts:"ts",tsx:"tsx",css:"css",json:"json"}));async function Tn(o,c,v){try{return await o(c,v)}catch(I){if(c!=="project")throw I;return}}function Qe(o,c,v,I){let M=new Map,Y=(z,X)=>{let H=I?.packages?.[z];if(H)return M.has(z)||M.set(z,new Set(H.files)),M.get(z).has(X)?c(`${yt}/${H.key}/${X}`):void 0},oe=async(z,X)=>{if(z==="project")return c(X);let H=X.indexOf("/"),[me,Oe]=[X.slice(0,H),X.slice(H+1)];return o?o[me]?.get(Oe):Y(me,Oe)};return{read:oe,find:async(z,X)=>{for(let H of Pn){let me=await Tn(oe,z,X+H);if(me!==void 0)return v.set(`${z}:${X+H}`,me),{path:X+H,namespace:z}}throw new Error(`Cannot resolve ${X}`)}}}function Cn(o,c,v){return Xe(o,c,v,new Map)}function Xe(o,c,v,I){let{read:M,find:Y}=Qe(c,v,I,o),oe=ne=>async z=>{let X=I.get(`${ne}:${z.path}`)??await M(ne,z.path),H=On.get(z.path.split(".").pop());return{contents:H?$n.decode(X):X,loader:H??"file"}};return{name:"webfront-project",setup(ne){ne.onStart?.(()=>I.clear()),ne.onResolve({filter:/.*/},z=>Ke(z,o,Y)),ne.onLoad({filter:/.*/,namespace:"empty"},()=>({contents:"",loader:"js"}));for(let z of["project","npm"])ne.onLoad({filter:/.*/,namespace:z},oe(z))}}}function vt({entry:o,lock:c,packages:v,readProject:I}){return{entryPoints:[o],bundle:!0,write:!1,outdir:"/output",entryNames:"app",assetNames:"assets/[name]-[hash]",format:"esm",platform:"browser",target:"es2020",jsx:"automatic",minify:!0,define:{"process.env.NODE_ENV":'"production"'},legalComments:"inline",plugins:[Cn(c,v,I)]}}var xt=o=>new Map(o.outputFiles.map(c=>[c.path.replace(/^\/output\//,""),c.contents]));async function kt(o,c){return xt(await o.build(vt(c)))}async function Et(o,c){let v=await o.context(vt(c));return{rebuild:async()=>xt(await v.rebuild()),dispose:()=>v.dispose()}}var An=new Set(["assert","async_hooks","buffer","child_process","cluster","console","constants","crypto","dgram","diagnostics_channel","dns","domain","events","fs","http","http2","https","inspector","module","net","os","path","perf_hooks","process","punycode","querystring","readline","repl","stream","string_decoder","sys","timers","tls","trace_events","tty","url","util","v8","vm","wasi","worker_threads","zlib"]),Rn=/^(?:node:|[a-z_][a-z0-9_]*(?:\/|$))/;function Un(o){if(o.startsWith("node:"))return o.slice(5).split("/")[0];let c=o.split("/")[0];return An.has(c)?c:null}var bt=o=>`"${o}" is a Node.js API, which WebFront scripts do not provide (no fs, child_process or process; use the context API)`;function Dn(o,c,v){return{name:"webfront-script",setup(I){I.onResolve({filter:/^webfront-script-entry$/},()=>v(o.namespace,o.path)),I.onResolve({filter:Rn},async M=>{let Y=Un(M.path);if(Y){if(M.path.startsWith("node:"))return{errors:[{text:bt(Y)}]};try{return await Ke(M,c,v)}catch{return{errors:[{text:bt(Y)}]}}}})}}}async function _t(o,{entry:c,lock:v,packages:I,readProject:M}){let Y=new Map,{find:oe}=Qe(I,M,Y,v),ne=await o.build({entryPoints:["webfront-script-entry"],bundle:!0,write:!1,outfile:"/output/script.js",format:"esm",platform:"browser",target:"es2022",jsx:"automatic",legalComments:"inline",define:{"process.env.NODE_ENV":'"production"'},plugins:[Dn(c,v,oe),Xe(v,I,M,Y)]});return new Map(ne.outputFiles.map(z=>[z.path.replace(/^\/output\//,""),z.contents]))}async function jt(o,{specs:c,lock:v,packages:I,readProject:M}){let Y=new Map,{find:oe}=Qe(I,M,Y,v),ne=c.map(H=>`import ${JSON.stringify(`webfront-spec:${H}`)};`).join(`
`),z={name:"webfront-tests",setup(H){H.onResolve({filter:/^webfront-test-entry$/},()=>({path:"entry",namespace:"webfront-tests"})),H.onLoad({filter:/.*/,namespace:"webfront-tests"},()=>({contents:ne,loader:"js"})),H.onResolve({filter:/^webfront-spec:/},me=>oe("project",he(me.path.slice(14))))}},X=await o.build({entryPoints:["webfront-test-entry"],bundle:!0,write:!1,outdir:"/output",entryNames:"specs",assetNames:"assets/[name]-[hash]",format:"esm",platform:"browser",target:"es2022",jsx:"automatic",define:{"process.env.NODE_ENV":'"test"'},legalComments:"inline",plugins:[z,Xe(v,I,M,Y)]});return new Map(X.outputFiles.map(H=>[H.path.replace(/^\/output\//,""),H.contents]))}var tt=new Map,In=0,St=o=>new Promise((c,v)=>{let I=++In;tt.set(I,{resolve:c,reject:v}),self.postMessage({type:"read",id:I,path:o})}),Mn=We.initialize({wasmURL:new URL("./esbuild.wasm",import.meta.url).href,worker:!1}),Ze,et,$t={build:kt,script:_t,tests:jt};self.onmessage=async({data:o})=>{if(o.type==="read-result"){let c=tt.get(o.id);if(!c)return;tt.delete(o.id),o.error?c.reject(new Error(o.error)):c.resolve(o.bytes);return}if(Object.hasOwn($t,o.type))try{await Mn;let c;if(o.incremental){let v=JSON.stringify([o.entry,o.lock]);v!==et&&(await Ze?.dispose(),et=void 0,Ze=await Et(We,{...o,readProject:St}),et=v),c=await Ze.rebuild()}else c=await $t[o.type](We,{...o,readProject:St});self.postMessage({type:"result",files:c})}catch(c){self.postMessage({type:"error",error:c.message,diagnostics:c.errors?.map(({text:v,location:I})=>({text:v,location:I}))})}};
